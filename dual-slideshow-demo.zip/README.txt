A Pen created at CodePen.io. You can find this one at http://codepen.io/Reklino/pen/wawopV.

 Just playing around with a dual pane slideshow concept.