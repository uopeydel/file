A Pen created at CodePen.io. You can find this one at http://codepen.io/enterthegrave/pen/NNNeoN.

 Navigate using the up and down arrow keys.