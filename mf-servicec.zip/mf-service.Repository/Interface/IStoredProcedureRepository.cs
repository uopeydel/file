using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using Oracle.ManagedDataAccess.Client;

namespace mf_service.Repository.Interface
{
    public interface IStoredProcedureRepository
    {
        Task<PandaResults<List<T>>> GetQueryStore<T>(
            string commandText,
            List<OracleParameter> parameters
        ) where T : class, new();

        Task<PandaResults<List<T>>> QueryList<T>(
            string commandText,
            List<List<OracleParameter>> queryParams
        ) where T : class, new();
    }
}