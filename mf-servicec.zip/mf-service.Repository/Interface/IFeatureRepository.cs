using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.Models.MSSQL;

namespace mf_service.Repository.Interface
{
    public interface IFeatureRepository
    {
        Task<PandaResults<List<FeatureContract>>> GetFeatures();
        Task<PandaResults<FeatureContract>> AddFeatures(Feature feature);
    }
}