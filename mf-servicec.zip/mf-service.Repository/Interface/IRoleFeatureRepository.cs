using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Body;
using mf_service.SharedService.Contract.UserManagement.Result;

namespace mf_service.Repository.Interface
{
    public interface IRoleFeatureRepository
    {
        Task<PandaResults<List<RoleFeaturesContract>>> GetFeaturesByRole(string roleCode);
        Task<PandaResults<List<CodeNameContract>>> AddRole(List<RoleCreateContract> role);
        Task<PandaResults<List<RoleFeaturesContract>>> GetAllFeaturesRoles();
    }
}