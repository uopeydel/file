using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Models.MSSQL;

namespace mf_service.Repository.Interface
{
    public interface ITokenRepository
    {
        Task<PandaResults<bool>> CreateToken(Token tokens);
        Task<PandaResults<Token>> ReadToken(string userId);
        Task<PandaResults<bool>> Logout(string userId);

    }
    
}