using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Result;

namespace mf_service.Repository.Interface
{
    public interface IRoleRepository
    {
        Task<PandaResults<bool>> IsRoleActiveAndHaveFeature(string roleCode);
        Task<PandaResults<List<RoleContract>>> GetRoles();
        Task<PandaResults<bool>> InactiveRole(RoleContract roleCode);
    }
}