using System;
using System.Collections.Generic;
using mf_service.Repository.Interface;
using mf_service.SharedService.Models.MSSQL;
using System.Linq;
using System.Threading.Tasks;
using mf_service.Repository.DataAccess;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.UserManagement;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace mf_service.Repository.Implement
{
    public class RoleRepositoryImpl : IRoleRepository
    {
        private readonly IGenericEFRepository<MFDbContext> _repo;
        private readonly IMFLoggerService _logger;

        public RoleRepositoryImpl(IGenericEFRepository<MFDbContext> repo, IMFLoggerService logger)
        {
            _logger = logger;
            _repo = repo;
        }

        public async Task<PandaResults<bool>> IsRoleActiveAndHaveFeature(string roleCode)
        {
            try
            {
                roleCode = roleCode.ToUpper();
                var result = await _repo.GetQueryAble<Role>()
                    .Where(w => w.code.Contains(roleCode) && w.is_active && w.RoleFeatures.Any(a => a.Feature != null))
                    .AnyAsync();
                return PandaResponse.CreateSuccessResponse(result);
            }
            catch
            {
                return PandaResponse.CreateSuccessResponse(false);
            }
        }

        public async Task<PandaResults<List<RoleContract>>> GetRoles()
        {
            try
            {
                var result = await _repo.GetQueryAble<Role>()
                    /*.Where(w => w.is_active)*/
                    .Select(s => new RoleContract
                    {
                        code = s.code,
                        created = s.created,
                        id = s.id,
                        modified = s.modified,
                        name = s.name,
                        isActive = s.is_active
                    })
                    .ToListAsync();
                return PandaResponse.CreateSuccessResponse(result);
            }
            catch (Exception e)
            {
                return PandaResponse.CreateErrorResponse<List<RoleContract>>("GetRoles", e);
            }
        }


        public async Task<PandaResults<bool>> InactiveRole(RoleContract role)
        {
            try
            {
                #region DELETE ROLE

                /*var transactionResult = await _repo.ExecuteWithTransactionAsync(async () =>
                {
                    var result = await _repo.GetQueryAble<RoleFeature>()
                        .Where(w => roleCode.Contains(w.Role.code.ToUpper()))
                        .ToListAsync();
                    var removeResult = await _repo.RemoveRange(result);
                    if (removeResult.IsError())
                    {
                        throw new Exception(removeResult.Message);
                    }

                    var roles = await _repo.GetQueryAble<Role>()
                        .Where(w => roleCode.Contains(w.code.ToUpper()))
                        .ToListAsync();
                    var removeRolesResult = await _repo.RemoveRange(roles);
                    if (removeRolesResult.IsError())
                    {
                        throw new Exception(removeRolesResult.Message);
                    }

                    return removeResult;
                });
                return transactionResult.Data;*/

                #endregion

                var roleUpdate = await _repo.GetQueryAble<Role>()
                    .Where(w => role.code.ToUpper().Equals(w.code))
                    .FirstOrDefaultAsync();
                roleUpdate.is_active = role.isActive;
                _repo.UpdateSpecficProperty(roleUpdate, data => data.is_active);
                var saveResult = await _repo.SaveAsync();

                if (saveResult.Data)
                {
                    try
                    {
                        var logDesc = _logger.GetLogDesc();
                        var activity = new AdministrationActivityAuditLog
                        {
                            Activity = role.isActive ? MFEnums.ActivityType.Active : MFEnums.ActivityType.InActive,
                            UserId = logDesc.UserId, 
                            RoleCode = role.code
                        };

                        var logAddFeature = new Log
                        {
                            created = DateTime.Now,
                            logType = MFEnums.LogType.AdministrationActivityAuditLog,
                            message = JsonConvert.SerializeObject(activity),
                            rquid = logDesc.Uuid,
                            userid = logDesc.UserId
                            
                        };
                        await _repo.AddAsync(logAddFeature);
                        await _repo.SaveAsync();
                    }
                    catch
                    {
                        // ignored
                    }
                }


                return saveResult;
            }
            catch (Exception e)
            {
                return PandaResponse.CreateErrorResponse<bool>("Error while inactive role feature", e);
            }
        }
    }
}