using System;
using System.Collections.Generic;
using mf_service.Repository.Interface;
using mf_service.SharedService.Models.MSSQL;
using System.Linq;
using System.Threading.Tasks;
using mf_service.Repository.DataAccess;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.UserManagement;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace mf_service.Repository.Implement
{
    public class LogRepositoryImpl : ILogRepository
    {
        private readonly IGenericEFRepository<MFDbContext> _repo;
        private readonly IMFLoggerService _logger;

        public LogRepositoryImpl(IGenericEFRepository<MFDbContext> repo, IMFLoggerService logger)
        {
            _logger = logger;
            _repo = repo;
        }


        public async Task<PandaResults<List<Log>>> ExportLog(string userid, MFEnums.LogType? logType, DateTime? from,
            DateTime? to)
        {
            try
            {
                var query = _repo.GetQueryAble<Log>();

                if (!string.IsNullOrEmpty(userid))
                {
                    query = query.Where(w => w.userid.ToUpper().Equals(userid.ToUpper()));
                }

                if (logType != null)
                {
                    query = query.Where(w => w.logType == logType);
                }

                if (from != null)
                {
                    var dateFrom = from.Value.Date;
                    query = query.Where(w => w.created.Date >= dateFrom);
                }

                if (to != null)
                {
                    var dateTo = to.Value.Date;
                    query = query.Where(w => w.created.Date <= dateTo);
                }


                var result = PandaResponse.CreateSuccessResponse(await query.ToListAsync());
                return result;
            }
            catch (Exception e)
            {
                var result = PandaResponse.CreateErrorResponse<List<Log>>("Error while query log data.", e);
                return result;
            }
        }

        public async Task<PandaResults<bool>> LogAccess(string access)
        {
            try
            {
                Console.WriteLine("access " + access);
                var logDesc = _logger.GetLogDesc();
                var logAddFeature = new Log
                {
                    created = DateTime.Now,
                    logType = MFEnums.LogType.AccessActivity,
                    message = access,
                    rquid = logDesc.Uuid,
                    userid = logDesc.UserId,
                };
                await _repo.AddAsync(logAddFeature);

                var result = await _repo.SaveAsync();
                Console.WriteLine("access done " + access);
                return result;
            }
            catch (Exception e)
            {
                Console.WriteLine("access err " + access + e.ToString());
                return PandaResponse.CreateErrorResponse<bool>($"Error while log {access} data.", e);
            }
        }
    }
}