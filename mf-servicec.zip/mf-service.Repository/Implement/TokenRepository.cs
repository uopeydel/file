using System.Linq;
using System.Threading.Tasks;
using mf_service.Repository.DataAccess;
using mf_service.Repository.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Models.MSSQL;
using Microsoft.EntityFrameworkCore;

namespace mf_service.Repository.Implement
{
    public class TokenRepository : ITokenRepository
    {
        private readonly IGenericEFRepository<MFDbContext> _repo;

        public TokenRepository(IGenericEFRepository<MFDbContext> repo)
        {
            _repo = repo;
        }

        public async Task<PandaResults<bool>> CreateToken(Token tokens)
        {
            var tokensData = await _repo.GetQueryAble<Token>().Where(w => w.UserId == tokens.UserId).ToListAsync();
            var removeResult = await _repo.RemoveRange(tokensData);
            if (removeResult.IsError())
            {
                return removeResult;
            }

            await _repo.AddAsync(tokens);
            var saveResult = await _repo.SaveAsync();
            return saveResult;
        }

        public async Task<PandaResults<Token>> ReadToken(string userId)
        {
            try
            {
                var tokensData = await _repo.GetQueryAble<Token>().Where(w => w.UserId == userId).FirstOrDefaultAsync();
                return PandaResponse.CreateSuccessResponse<Token>(tokensData);
            }
            catch
            {
                return PandaResponse.CreateErrorResponse<Token>("Error while read token");
            }
        }

        public async Task<PandaResults<bool>> Logout(string userId)
        {
            try
            {
                var tokensData = await _repo.GetQueryAble<Token>().Where(w => w.UserId == userId).ToListAsync();
                var removeResult = await _repo.RemoveRange(tokensData);
                if (!removeResult.IsError())
                {
                    return PandaResponse.CreateSuccessResponse<bool>(true);
                }
            }
            finally
            {
            }

            return PandaResponse.CreateErrorResponse<bool>("Error while logout");
        }
    }
}