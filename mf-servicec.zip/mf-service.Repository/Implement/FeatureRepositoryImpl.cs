using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.Repository.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Models.MSSQL;
using System.Linq;
using System.Linq.Expressions;
using mf_service.Repository.DataAccess;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.UserManagement;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace mf_service.Repository.Implement
{
    public class FeatureRepositoryImpl : IFeatureRepository
    {
        private readonly IGenericEFRepository<MFDbContext> _repo;
        private readonly IMFLoggerService _logger;

        public FeatureRepositoryImpl(IGenericEFRepository<MFDbContext> repo, IMFLoggerService logger)
        {
            _logger = logger;
            _repo = repo;
        }

        public async Task<PandaResults<List<FeatureContract>>> GetFeatures()
        {
            try
            {
                var result = await _repo.GetQueryAble<Feature>()
                    .Select(s => new FeatureContract
                    {
                        code = s.code,
                        id = s.id,
                        name = s.name,
                        isActive = s.is_active
                    })
                    .ToListAsync();
                return PandaResponse.CreateSuccessResponse(result);
            }
            catch (Exception e)
            {
                return PandaResponse.CreateErrorResponse<List<FeatureContract>>("Get Features", e);
            }
        }

        public async Task<PandaResults<FeatureContract>> AddFeatures(Feature feature)
        {
            try
            {
                var isAny = await _repo.GetQueryAble<Feature>()
                    .Where(w => w.code.ToLower().Equals(feature.code.ToLower()))
                    .AnyAsync();

                if (isAny)
                {
                    return PandaResponse.CreateErrorResponse<FeatureContract>("Feature is exist.");
                }

                var addResult = await _repo.AddAsync(feature);
                var saveResult = await _repo.SaveAsync();
                if (!saveResult.IsError())
                {
                    var result = new FeatureContract
                    {
                        code = feature.code,
                        id = feature.id,
                        name = feature.name,
                        isActive = feature.is_active,
                    };
                    
                    try
                    {
                        var logDesc = _logger.GetLogDesc();
                        var activity = new AdministrationActivityAuditLog
                        {
                            Activity = MFEnums.ActivityType.Add,
                            UserId = logDesc.UserId, 
                            FeatureCode = feature.code
                        };

                        var logAddFeature = new Log
                        {
                            created = DateTime.Now,
                            logType = MFEnums.LogType.AdministrationActivityAuditLog,
                            message = JsonConvert.SerializeObject(activity),
                            rquid = logDesc.Uuid, 
                            userid = logDesc.UserId
                        };
                        await _repo.AddAsync(logAddFeature);
                        await _repo.SaveAsync();
                    }
                    catch
                    {
                        // ignored
                    }

                    return PandaResponse.CreateSuccessResponse(result);
                }

                return PandaResponse.CreateErrorResponse<FeatureContract>(saveResult.Errors.ToArray());
            }
            catch (Exception e)
            {
                return PandaResponse.CreateErrorResponse<FeatureContract>("Add Features", e);
            }
        }
    }
}