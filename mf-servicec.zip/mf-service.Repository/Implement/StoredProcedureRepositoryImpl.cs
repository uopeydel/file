using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using mf_service.Repository.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Text;
using Oracle.ManagedDataAccess.Client;

namespace mf_service.Repository.Implement
{
    public class StoredProcedureRepositoryImpl : IStoredProcedureRepository
    {
        private readonly IMFLoggerService _logger;
        private readonly IConfiguration _configuration;

        public StoredProcedureRepositoryImpl(IConfiguration configuration, IMFLoggerService logger)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public async Task<PandaResults<List<T>>> GetQueryStore<T>(
            string commandText,
            List<OracleParameter> parameters
        ) where T : class, new()
        {
            var paramName = " PARAM ";
            var connString = BuildConnectionString();

            var responseObject = new List<T>();
            try
            {
                _logger.LogInfo(" GETQUERYSTORE ", " Start call stored procedure",
                    typeof(StoredProcedureRepositoryImpl).Name);

                using (var objConn = new OracleConnection())
                {
                    using (var objCmd = new OracleCommand())
                    {
                        using (var dtAdapter = new OracleDataAdapter())
                        {
                            var ds = new DataSet();

                            objConn.ConnectionString = connString;
                            objConn.Open();


                            parameters.ForEach(f =>
                            {
                                paramName += $" {f.ParameterName}:{f.Value} ";
                                objCmd.Parameters.Add(f.Clone());
                            });

                            objCmd.Connection = objConn;
                            objCmd.CommandText = commandText;
                            objCmd.CommandType = CommandType.StoredProcedure;

                            var results = await objCmd.ExecuteReaderAsync();

                            dtAdapter.SelectCommand = objCmd;

                            try
                            {
                                dtAdapter.Fill(ds);
                            }
                            catch
                            {
                                goto EndQuery;
                            }


                            for (var i = 0; i < ds.Tables.Count; i++)
                            { 
                                _logger.LogInfo(" GETQUERYSTORE ", " Read data table " + i,
                                    typeof(StoredProcedureRepositoryImpl).Name);

                                var dt = ds.Tables[i];

                                for (var j = 0; j <= dt.Rows.Count - 1; j++)
                                {
                                    var mapResult = Helper.DataRowTo<T>(dt.Rows[j]);
                                    if (mapResult != null)
                                    {
                                        responseObject.Add(mapResult);
                                    }
                                }
                            }

                            dtAdapter.Dispose();
                            objCmd.Dispose();
                            objConn.Close();
                            objConn.Dispose();
                        }
                    }
                }


                EndQuery:

                _logger.LogInfo(" GETQUERYSTORE ",
                    " Done : with stored procedure " + paramName + " RESPONSE " + JsonConvert
                        .SerializeObject(responseObject).Replace(Environment.NewLine, " "),
                    typeof(StoredProcedureRepositoryImpl).Name);
                return PandaResponse.CreateSuccessResponse(responseObject);
            }
            catch (Exception e)
            {
                _logger.LogInfo(" GETQUERYSTORE ", "Error while get data from store procedure." + e.ToString(),
                    typeof(StoredProcedureRepositoryImpl).Name ,LogLevel.Error);
                return PandaResponse.CreateErrorResponse<List<T>>("Error while get data from store procedure.", e);
            }
        }


        public async Task<PandaResults<List<T>>> QueryList<T>(
            string commandText,
            List<List<OracleParameter>> queryParams
        ) where T : class, new()
        {
            var paramName = " PARAM ";
            var connString = BuildConnectionString();

            var responseObject = new List<T>();
            try
            {
                using (var objConn = new OracleConnection())
                {
                    objConn.ConnectionString = connString;
                    objConn.Open();
                    foreach (var parameters in queryParams)
                    {
                        using (var objCmd = new OracleCommand())
                        {
                            using (var dtAdapter = new OracleDataAdapter())
                            {
                                var ds = new DataSet();

                                parameters.ForEach(f =>
                                {
                                    paramName += $" {f.ParameterName}:{f.Value} ";
                                    objCmd.Parameters.Add(f.Clone());
                                });

                                objCmd.Connection = objConn;
                                objCmd.CommandText = commandText;
                                objCmd.CommandType = CommandType.StoredProcedure;

                                var results = await objCmd.ExecuteReaderAsync();

                                dtAdapter.SelectCommand = objCmd;
                                try
                                {
                                    dtAdapter.Fill(ds);
                                }
                                catch
                                {
                                    continue;
                                }

                                for (var i = 0; i < ds.Tables.Count; i++)
                                {
                                    var dt = ds.Tables[i];
                                    for (var j = 0; j <= dt.Rows.Count - 1; j++)
                                    {
                                        var mapResult = Helper.DataRowTo<T>(dt.Rows[j]);
                                        if (mapResult != null)
                                        {
                                            responseObject.Add(mapResult);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    objConn.Close();
                }
                _logger.LogInfo("GETQueryList",
                    " Done with stored procedure " + paramName + " RESPONSE " + JsonConvert
                        .SerializeObject(responseObject).Replace(Environment.NewLine, " "),
                    typeof(StoredProcedureRepositoryImpl).Name);
                return PandaResponse.CreateSuccessResponse(responseObject);
            }
            catch (Exception e)
            {
                return PandaResponse.CreateErrorResponse<List<T>>("Error while query data from store procedure.", e);
            }
        }

        private string BuildConnectionString()
        {
            var user = _configuration["OracleConnection:User"];

            /*var password = AesMf.DecryptStringFromBytes_Aes(
                Convert.FromBase64String(_configuration["OracleConnection:Password"]),
                Convert.FromBase64String(mf_service.SharedService.Contract.Constants.Constant.AesKey),
                Convert.FromBase64String(mf_service.SharedService.Contract.Constants.Constant.AesVi)
            );*/
            var password = AesMf.DecryptAES(
                 _configuration["OracleConnection:Password"],
                 Encoding.UTF8.GetBytes(mf_service.SharedService.Contract.Constants.Constant.AesKey),
                 Encoding.UTF8.GetBytes(mf_service.SharedService.Contract.Constants.Constant.AesIV)
            );
            var host = _configuration["OracleConnection:Host"];
            var port = _configuration["OracleConnection:Port"];
            var sid = _configuration["OracleConnection:SID"];

            var connString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=" +
                             host
                             + ")(PORT=" +
                             port
                             + "))  (CONNECT_DATA=(SID=" +
                             sid
                             + ")));User Id=" +
                             user
                             + ";Password=" +
                             password;
            return connString;
        }
    }
}