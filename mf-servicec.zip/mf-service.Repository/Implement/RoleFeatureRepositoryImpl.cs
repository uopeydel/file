using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Diagnostics;
using mf_service.Repository.Interface;
using mf_service.SharedService.Models.MSSQL;
using System.Linq;
using System.Threading.Tasks;
using mf_service.Repository.DataAccess;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.UserManagement;
using mf_service.SharedService.Contract.UserManagement.Body;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Newtonsoft.Json;
using Remotion.Linq.Clauses.ResultOperators;

namespace mf_service.Repository.Implement
{
    public class RoleFeatureRepositoryImpl : IRoleFeatureRepository
    {
        private readonly IGenericEFRepository<MFDbContext> _repo;
        private readonly IMFLoggerService _logger;

        public RoleFeatureRepositoryImpl(IGenericEFRepository<MFDbContext> repo, IMFLoggerService logger)
        {
            _logger = logger;
            _repo = repo;
        }

        public async Task<PandaResults<List<RoleFeaturesContract>>> GetFeaturesByRole(string roleCode)
        {
            try
            {
                var result = await _repo.GetQueryAble<Role>()
                    //.Where(w => w.is_active)
                    .Where(w => w.code.ToUpper().Equals(roleCode.ToUpper()))
                    .Select(s => new RoleFeaturesContract
                    {
                        code = s.code,
                        id = s.id,
                        name = s.name,
                        isActive = s.is_active,
                        features = s.RoleFeatures.Where(w => w.is_active && w.Feature.is_active).Select(ss =>
                            new CodeNameContract
                            {
                                name = ss.Feature.name,
                                code = ss.Feature.code
                            }).ToList()
                    })
                    .ToListAsync();

                return PandaResponse.CreateSuccessResponse(result);
            }
            catch (Exception e)
            {
                return PandaResponse.CreateErrorResponse<List<RoleFeaturesContract>>("GetFeaturesByRole", e);
            }
        }

        public async Task<PandaResults<List<RoleFeaturesContract>>> GetAllFeaturesRoles()
        {
            try
            {
                var result = await _repo.GetQueryAble<Role>()
                    //.Where(w => w.is_active)
                    .Select(s => new RoleFeaturesContract
                    {
                        code = s.code,
                        id = s.id,
                        name = s.name,
                        isActive = s.is_active,
                        features = s.RoleFeatures /*.Where(w => w.is_active && w.Feature.is_active)*/.Select(ss =>
                            new CodeNameContract
                            {
                                name = ss.Feature.name,
                                code = ss.Feature.code
                            }).ToList()
                    })
                    .ToListAsync();

                return PandaResponse.CreateSuccessResponse(result);
            }
            catch (Exception e)
            {
                return PandaResponse.CreateErrorResponse<List<RoleFeaturesContract>>("GetAllFeatureRole", e);
            }
        }


        public async Task<PandaResults<List<CodeNameContract>>> AddRole(List<RoleCreateContract> roles)
        {
            var userId = _logger.GetLogDesc().UserId;
            var uuid = _logger.GetLogDesc().Uuid;


            var now = DateTime.Now.ToLocalTime();
            var newRoles = new List<Role>();
            var allRoleCodes = roles
                .Where(w => !string.IsNullOrEmpty(w.roleCode))
                .Select(s => Helper.LimitLength(s.roleCode))
                .Distinct()
                .ToList();

            var oldRoleCode = await _repo.GetQueryAble<Role>()
                .Where(w => allRoleCodes.Contains(w.code.ToUpper()))
                .Select(s => s.code.ToUpper())
                .ToListAsync();

            var newRoleCodes = allRoleCodes.Where(w => !oldRoleCode.Contains(w)).ToList();

            foreach (var role in newRoleCodes)
            {
                var newRole = new Role
                {
                    code = role,
                    created = now,
                    modified = now,
                    is_active = roles.Where(w => w.roleCode.ToUpper().Equals(role.ToUpper())).Select(s => s.roleStatus)
                        .FirstOrDefault(),
                };
                newRoles.Add(newRole);
            }

            await _repo.AddRangeAsync(newRoles);
            var saveResult = await _repo.SaveAsync();
            if (saveResult.IsError())
            {
                saveResult.Errors.Insert(0, "Error while save to database.");
                return PandaResponse.CreateErrorResponse<List<CodeNameContract>>(saveResult.Errors.ToArray());
            }
            else
            {
                var logAddRole = newRoles.Select(s => new AdministrationActivityAuditLog
                {
                    Activity = MFEnums.ActivityType.Add,
                    RoleCode = s.code,
                    UserId = userId,
                }).ToList();
                // Log
                await SetLogActivity(logAddRole, uuid, userId);
            }

            var allFeatureCodes = roles.SelectMany(sm => sm.feature.Select(s => Helper.LimitLength(s.code))).Distinct()
                .ToList();

            var oldFeatureCodes = await _repo.GetQueryAble<Feature>()
                .Where(w => allFeatureCodes.Contains(w.code.ToUpper()))
                .Select(s => s.code)
                .ToListAsync();

            var newFeatureCodes = allFeatureCodes.Where(w => !oldFeatureCodes.Contains(w)).ToList();

            var newFeatures = new List<Feature>();

            foreach (var featureCode in newFeatureCodes)
            {
                var newFeature = new Feature
                {
                    code = featureCode,
                    created = now,
                    modified = now,
                    is_active = true,
                };
                newFeatures.Add(newFeature);
            }

            await _repo.AddRangeAsync(newFeatures);
            saveResult = await _repo.SaveAsync();
            if (saveResult.IsError())
            {
                saveResult.Errors.Insert(0, "Error while save feature to database.");
                return PandaResponse.CreateErrorResponse<List<CodeNameContract>>(saveResult.Errors.ToArray());
            }
            else
            {
                var logAddFeature = newFeatures.Select(s => new AdministrationActivityAuditLog
                {
                    Activity = MFEnums.ActivityType.Add,
                    FeatureCode = s.code,
                    UserId = userId,
                }).ToList();
                // Log
                await SetLogActivity(logAddFeature, uuid, userId);
            }

            var roleCodeIds = await _repo.GetQueryAble<Role>()
                .Where(w => allRoleCodes.Contains(w.code))
                .Select(s => new
                {
                    code = s.code,
                    id = s.id,
                    roleFeatures = s.RoleFeatures.Select(ss => ss).ToList()
                })
                .AsNoTracking()
                .ToListAsync();

            var featureCodeIds = await _repo.GetQueryAble<Feature>()
                .Where(w => allFeatureCodes.Contains(w.code))
                .Select(s => new
                {
                    code = s.code,
                    id = s.id
                })
                .ToListAsync();

            var addRoleFeature = new List<RoleFeature>();
            var linkLog = new List<AdministrationActivityAuditLog>();
            foreach (var role in roles)
            {
                var thisRole = roleCodeIds.Where(w => w.code.Equals(role.roleCode)).Select(s => new {s.id, s.code})
                    .FirstOrDefault();

                var newRoleFeature = featureCodeIds.Select(s =>
                {
                    linkLog.Add(
                        new AdministrationActivityAuditLog()
                        {
                            Activity = MFEnums.ActivityType.Link,
                            RoleCode = thisRole.code,
                            FeatureCode = s.code,
                            UserId = userId,
                        });

                    return new RoleFeature
                    {
                        created = now,
                        is_active = true,
                        modified = now,
                        feature_id = s.id,
                        role_id = thisRole.id
                    };
                });
                addRoleFeature.AddRange(newRoleFeature);
            }

            using (var transaction = _repo.Context().Database.BeginTransaction())
            {
                try
                {
                    var features = roleCodeIds.SelectMany(s => s.roleFeatures).ToList();
                    await _repo.RemoveRange(features);
                    await _repo.SaveAsync();

                    await _repo.AddRangeAsync(addRoleFeature);
                    await _repo.SaveAsync();
                    // Commit transaction if all commands succeed, transaction will auto-rollback
                    // when disposed if either commands fails
                    transaction.Commit();

                    // Log add 2 id with change [linkLog]
                    await SetLogActivity(linkLog, uuid, userId);
                }
                catch (Exception e)
                {
                    return PandaResponse.CreateErrorResponse<List<CodeNameContract>>("Error while update RoleFeature.",
                        e);
                }
            }


            #region todo  

            //todo make it list 

            var roleCode = roles.Select(s => s.roleCode).FirstOrDefault();
            var roleis_active = roles.Select(s => s.roleStatus).FirstOrDefault();
            var roleForUpdateBool = await _repo.GetQueryAble<Role>()
                .Where(w => w.code.Equals(roleCode))
                .FirstOrDefaultAsync();
            roleForUpdateBool.is_active = roleis_active;

            _repo.UpdateSpecficProperty(roleForUpdateBool, o => o.is_active);
            await _repo.SaveAsync();
            // Log roleis_active

            var logActive = new AdministrationActivityAuditLog()
            {
                Activity = roleis_active ? MFEnums.ActivityType.Active : MFEnums.ActivityType.InActive,
                RoleCode = roleCode,
                UserId = userId,
            };
            await SetLogActivity(new List<AdministrationActivityAuditLog> {logActive}, uuid , userId);


            //todo make it support array
            var newRoleCode = roles.Where(w => !string.IsNullOrEmpty(w.newRoleCode)).FirstOrDefault();
            if (newRoleCode != null)
            {
                var newRoleIsExist = await _repo.GetQueryAble<Role>()
                    .Where(w => w.code.Equals(newRoleCode.newRoleCode))
                    .AnyAsync();
                if (!newRoleIsExist)
                {
                    var roleForUpdate = await _repo.GetQueryAble<Role>()
                        .Where(w => w.code.Equals(newRoleCode.roleCode))
                        .FirstOrDefaultAsync();
                    roleForUpdate.code = newRoleCode.newRoleCode;

                    _repo.UpdateSpecficProperty(roleForUpdate, o => o.code);
                    await _repo.SaveAsync();

                    // Log newRoleCode.newRoleCode
                    var logChange = new AdministrationActivityAuditLog()
                    {
                        Activity = MFEnums.ActivityType.Change,
                        RoleCode = newRoleCode.roleCode + " => " + newRoleCode.newRoleCode,
                        UserId = userId,
                    };
                    await SetLogActivity(new List<AdministrationActivityAuditLog> {logChange}, uuid, userId);
                }
            }

            #endregion


            var result = roleCodeIds.Select(s => new CodeNameContract
            {
                code = s.code,
            }).ToList();
            return PandaResponse.CreateSuccessResponse(result);
        }


        private async Task SetLogActivity(
            List<AdministrationActivityAuditLog> activityAuditLogs,
            string uuid , string userId)
        {
            try
            {
                var newLogs = activityAuditLogs.Select(act => new Log()
                {
                    logType = MFEnums.LogType.AdministrationActivityAuditLog,
                    created = DateTime.Now,
                    rquid = uuid,
                    userid = userId,
                    message = JsonConvert.SerializeObject(act),
                }).ToList();

                await _repo.AddRangeAsync(newLogs);
                await _repo.SaveAsync();
            }
            catch
            {
                //
            }
        }
    }
}