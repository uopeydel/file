using System;
using System.Diagnostics;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.Extensions.Logging;

namespace mf_service.Repository.DataAccess
{
    public class SqlLoggerProvider : ILoggerProvider
    {
        public SqlLoggerProvider()
        {
        }

        public ILogger CreateLogger(string categoryName)
        {
            return new QueryLogger();
        }

        public void Dispose()
        {
        }

        private class QueryLogger : ILogger
        {
            public QueryLogger()
            {
            }

            public bool IsEnabled(LogLevel logLevel)
            {
                return true;
            }

            public void Log<TState>(
                LogLevel logLevel,
                EventId eventId,
                TState state,
                Exception exception,
                Func<TState, Exception, string> formatter)
            {
                if (eventId.Id == 20101 || exception != null)
                {
                    Debug.WriteLine(" #!*#######*!# start #!*#######*!# ");
                    Debug.WriteLine("   ");
                    Debug.WriteLine(formatter(state, exception));
                    Debug.WriteLine("   ");
                    Debug.WriteLine(" #!*#######*!# end #!*#######*!# ");
                }
            }

            public IDisposable BeginScope<TState>(TState state)
            {
                return null;
            }
        }
    }
}