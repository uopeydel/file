using System;
using mf_service.SharedService.Models.MSSQL;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer.Infrastructure.Internal;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace mf_service.Repository.DataAccess
{
    public class MFDbContext : DbContext
    { 
        private readonly string _connectionString;

        public MFDbContext(string connectionString)
        { 
            _connectionString =  connectionString;
        }
        public MFDbContext(IServiceProvider serviceProvider)
        {
            var options = serviceProvider.GetRequiredService<DbContextOptions<MFDbContext>>();
            _connectionString = options.FindExtension<SqlServerOptionsExtension>().ConnectionString;
        }

        public virtual DbSet<Token> Tokens { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<RoleFeature> RoleFeatures { get; set; }
        public virtual DbSet<Feature> Features { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Token>()
                .ToTable("token");
            modelBuilder.Entity<Role>()
                .ToTable("role");
            modelBuilder.Entity<RoleFeature>()
                .ToTable("role_feature");
            modelBuilder.Entity<Feature>()
                .ToTable("feature");
            
            modelBuilder.Entity<Log>()
                .ToTable("log");

            modelBuilder.Entity<RoleFeature>()
                .HasKey(c => new { c.role_id, c.feature_id });

            modelBuilder.Entity<Role>()
                .HasMany(e => e.RoleFeatures)
                .WithOne(e => e.Role)
                .HasForeignKey(e => e.role_id)
                .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder.Entity<Feature>()
                .HasMany(e => e.RoleFeatures)
                .WithOne(e => e.Feature)
                .HasForeignKey(e => e.feature_id)
                .OnDelete(DeleteBehavior.ClientSetNull);
            
            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
#if DEBUG
            var logEntitySql = new LoggerFactory();
            logEntitySql.AddProvider(new SqlLoggerProvider());
            optionsBuilder.UseLoggerFactory(logEntitySql).UseSqlServer(_connectionString);
#else
            if (optionsBuilder.IsConfigured)
            {
                return;
            }
            optionsBuilder.UseSqlServer(_connectionString  );
#endif
        }
    }
}