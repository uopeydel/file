﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace mfservice.Repository.Migrations
{
    public partial class AddcolumnuserId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "userid",
                table: "log",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "userid",
                table: "log");
        }
    }
}
