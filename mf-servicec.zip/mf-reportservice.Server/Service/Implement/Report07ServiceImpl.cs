using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using Microsoft.EntityFrameworkCore.Internal;

namespace mf_reportservice.Server.Service.Implement
{
    public class Report07ServiceImpl : IReport07Service
    {
        private readonly IETEService _eteService;

        public Report07ServiceImpl(IETEService eteService)
        {
            _eteService = eteService;
        }


        public async Task<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_LTF_RMF_BALContract>>>>
            MapTable
            (PortfolioSearchContract portList, List<MFAPI_GET_LTF_RMF_BALContract> ports)
        {
            var resultMap = new List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_LTF_RMF_BALContract>>>();
            var customers =
                await _eteService.GetCustomersList(portList.PortfolioList.Select(s => s.RMID).ToList());

            if (ports.Any())
            {
                var portCodes = ports.Select(s => s.PORTFOLIO).ToList();
                var rmids = portList.PortfolioList.Where(w => portCodes.Contains(w.PORTFOLIOCODE))
                    .Select(s => s.RMID)
                    .ToList();
                var showNames =
                    _eteService.FindShowNames(rmids, customers);
                var values = ports.Where(w => portCodes.Contains(w.PORTFOLIO)).ToList();
                var result = new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_LTF_RMF_BALContract>>
                {
                    Values = values,
                    Headers =
                        new PDFHeaderContract
                        {
                            FullNames = showNames.Distinct().ToList(),
                            FromDate = portList.FromDate,
                            ToDate = portList.ToDate,
                        }
                };
                resultMap.Add(result);
            }

            if (!resultMap.Any())
            {
                var showNames =
                    _eteService.FindShowNames(portList.PortfolioList.Select(s => s.RMID).ToList(), customers);
                var result = new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_LTF_RMF_BALContract>>
                {
                    Values = new List<MFAPI_GET_LTF_RMF_BALContract>(),
                    Headers =
                        new PDFHeaderContract
                        {
                            FullNames = showNames.Distinct().ToList(),
                            FromDate = portList.FromDate,
                            ToDate = portList.ToDate,
                        }
                };
                resultMap.Add(result);
            }

            return resultMap;
        }
    }
}