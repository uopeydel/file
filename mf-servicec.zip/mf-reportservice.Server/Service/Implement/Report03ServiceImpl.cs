using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;

namespace mf_reportservice.Server.Service.Implement
{
    public class Report03ServiceImpl : IReport03Service
    {
        private readonly IETEService _eteService;

        public Report03ServiceImpl(IETEService eteService)
        {
            _eteService = eteService;
        }

        public async Task<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>>
            MapTable(PortfolioSearchContract searchBody, List<MFAPI_GET_TRANSACTIONContract> dataMapped)
        {
            var resultMap =
                new List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>();
            var customers =
                await _eteService.GetCustomersList(searchBody.PortfolioList.Select(s => s.RMID).ToList());

            var portCodes = dataMapped.Select(s => s.PORTFOLIOCODE).Distinct().OrderBy(o => o).ToList();
            portCodes = portCodes.Where(w =>
                searchBody.PortfolioList.Select(s => s.PORTFOLIOCODE).Distinct().OrderBy(o => o).Contains(w)).ToList();
            foreach (var portCode in portCodes)
            {
                var rmids = searchBody.PortfolioList.Where(w => w.PORTFOLIOCODE.Equals(portCode)).Select(s => s.RMID)
                    .ToList();
                var fullNames = _eteService.FindShowNames(rmids, customers);
                resultMap.Add(new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>()
                {
                    Headers = new PDFHeaderContract
                    {
                        FromDate = searchBody.FromDate,
                        ToDate = searchBody.ToDate,
                        FullNames = fullNames,
                        PortfolioCode = new List<string> {portCode}
                    },
                    //Keys = searchBody.PortfolioList,
                    Values = dataMapped.Where(w => w.PORTFOLIOCODE.Equals(portCode))
                        .ToList(),
                });
            }

            if (!resultMap.Any())
            {
                var rmids = searchBody.PortfolioList.Select(s => s.RMID)
                    .ToList();
                var portCode = searchBody.PortfolioList.Select(s => s.PORTFOLIOCODE)
                    .ToList();
                var fullNames = _eteService.FindShowNames(rmids, customers);
                resultMap.Add(new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>()
                {
                    Headers = new PDFHeaderContract
                    {
                        FromDate = searchBody.FromDate,
                        ToDate = searchBody.ToDate,
                        FullNames = fullNames,
                        PortfolioCode = portCode
                    },
                    //Keys = searchBody.PortfolioList,
                    Values = new List<MFAPI_GET_TRANSACTIONContract>(),
                });
            }

            return resultMap;
        }
    }
}