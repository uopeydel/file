using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Configuration;

namespace mf_reportservice.Server.Service.Implement
{
    public class Report05ServiceImpl : IReport05Service
    {
        private readonly IETEService _eteService;
        private readonly IConfiguration _configuration;
        private readonly string[] assetName = new string[9];

        public Report05ServiceImpl(
            IConfiguration configuration,
            IETEService eteService)
        {
            _configuration = configuration;
            for (var i = 0; i < 9; i++)
            {
                assetName[i] = configuration[$"ASSETCLASS:NAMES:{i}"].ToUpper();
            }

            _eteService = eteService;
        }

        
        //todo change to use deligate method
        private int OrderByAssetClass(string AssetClass)
        {
            var orderIndex = assetName.IndexOf(AssetClass.ToUpper().Replace(" ", ""));
            return orderIndex;
        }

        public async Task<List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>>>
            MapTable(
                PortfolioSearchContract searchBody,
                List<MFAPI_GET_BALANCEContract> dataMapped)
        {
            var resultMap = new List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>>();
            var customers =
                await _eteService.GetCustomersList(searchBody.PortfolioList.Select(s => s.RMID).ToList());

            if (dataMapped.Count == 0)
            {
                var allRmid = searchBody.PortfolioList.Select(s => s.RMID).ToList();
                var allFullName = _eteService.FindShowNames(allRmid, customers);
                var allPortCode = searchBody.PortfolioList.Select(s => s.PORTFOLIOCODE).ToList();
                resultMap.Add(
                    new PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>
                    { 
                        Values = new GraphReportContract
                        {
                            Graphs = new List<GraphBodyContract> { },
                            Values = new List<List<MFAPI_GET_BALANCEContract>> { }
                        },
                        Headers = new PDFHeaderContract
                        {
                            FullNames = allFullName.Distinct().ToList(),
                            FromDate = searchBody.FromDate, 
                        }
                    });
                return resultMap;
            }

            var portCodeList = searchBody.PortfolioList.Select(s => s.PORTFOLIOCODE).ToList();
            var values = dataMapped.Where(w => portCodeList.Contains(w.PORTNAME))
                .OrderBy(o => OrderByAssetClass(o.ASSET_CLASS))
                .GroupBy(g => g.ASSET_CLASS)
                .Select(s => s.ToList())
                .Where(w => w.Any()).ToList();

            portCodeList = values.SelectMany(sm => sm.Select(s => s.PORTNAME)).ToList();
            var rmids = searchBody.PortfolioList.Where(w => portCodeList.Contains(w.PORTFOLIOCODE)).Select(s => s.RMID)
                .ToList();
            var fullNames = _eteService.FindShowNames(rmids, customers);

            var graphValue = new GraphReportContract
            {
                Values = values,
                Graphs = BuildChart.MapValueToGraph(values, _configuration)
            };

            resultMap.Add(
                new PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>
                { 
                    Values = graphValue,
                    Headers = new PDFHeaderContract
                    {
                        FullNames = fullNames.Distinct().ToList(),
                        FromDate = searchBody.FromDate, 
                    }
                });
            return resultMap;
        }
    }
}