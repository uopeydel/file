﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_reportservice.Server.ViewModel;
using mf_service.Repository.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.MF.Result;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.Models;
using Microsoft.AspNetCore.Internal;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;

namespace mf_reportservice.Server.Service.Implement
{
    public class BuildQueryStoreServiceImpl : IBuildQueryStoreService
    {
        private readonly IConfiguration _configuration;
        private readonly IStoredProcedureRepository _storedProcedureRepo;

        public BuildQueryStoreServiceImpl(
            IConfiguration configuration,
            IStoredProcedureRepository storedProcedureRepo
        )
        {
            _storedProcedureRepo = storedProcedureRepo;
            _configuration = configuration;
        }

        /// <summary>
        /// 1 2 5
        /// </summary>
        /// <param name="portList"></param>
        /// <param name="fromDate"></param>
        /// <returns></returns>
        public async Task<PandaResults<List<MFAPI_GET_BALANCEModel>>> BuildQueryParamsBalance(string portList,
            string fromDate)
        {
            var queryParams = new List<List<OracleParameter>>();

            OracleParameter param2 = new OracleParameter
            {
                ParameterName = "FROMDATE",
                OracleDbType = OracleDbType.Varchar2,
                Direction = ParameterDirection.Input,
                Value = fromDate
            };

            OracleParameter param4 = new OracleParameter
            {
                ParameterName = "records1",
                OracleDbType = OracleDbType.RefCursor,
                Direction = ParameterDirection.Output
            };

            List<OracleParameter> oracleParameters = new List<OracleParameter>();
            OracleParameter param1 = new OracleParameter();
            param1.ParameterName = "PORTFOLIONO";
            param1.OracleDbType = OracleDbType.Varchar2;
            param1.Direction = ParameterDirection.Input;
            param1.Value = portList;

            oracleParameters.Add(param1);
            oracleParameters.Add(param2);
            oracleParameters.Add(param4);

            var commandText = _configuration["StoredProcedure:GETBALANCE"];
            var queryResults =
                await _storedProcedureRepo.GetQueryStore<MFAPI_GET_BALANCEModel>(commandText, oracleParameters);
            return queryResults;
        }

        /// <summary>
        /// 4
        /// </summary>
        /// <param name="portList"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public async Task<PandaResults<List<MFAPI_GET_STMREBALModel>>> BuildQueryParamsRebalance(string portList,
            string fromDate, string toDate)
        {
            OracleParameter param2 = new OracleParameter
            {
                ParameterName = "FROMDATE",
                OracleDbType = OracleDbType.Varchar2,
                Direction = ParameterDirection.Input,
                Value = fromDate
            };
            OracleParameter param3 = new OracleParameter
            {
                ParameterName = "TODATE",
                OracleDbType = OracleDbType.Varchar2,
                Direction = ParameterDirection.Input,
                Value = toDate
            };
            OracleParameter param4 = new OracleParameter
            {
                ParameterName = "records1",
                OracleDbType = OracleDbType.RefCursor,
                Direction = ParameterDirection.Output
            };


            List<OracleParameter> oracleParameters = new List<OracleParameter>();
            OracleParameter param1 = new OracleParameter();
            param1.ParameterName = "PORTFOLIONO";
            param1.OracleDbType = OracleDbType.Varchar2;
            param1.Direction = ParameterDirection.Input;
            param1.Value = portList;

            oracleParameters.Add(param1);
            oracleParameters.Add(param2);
            oracleParameters.Add(param3);
            oracleParameters.Add(param4);


            var commandText = _configuration["StoredProcedure:GETREBALANCE"];
            var queryResults =
                await _storedProcedureRepo.GetQueryStore<MFAPI_GET_STMREBALModel>(commandText, oracleParameters);
            return queryResults;
        }

        /// <summary>
        /// 6
        /// </summary>
        /// <param name="portList"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public async Task<PandaResults<List<MFAPI_GET_TRANSACTIONModel>>> BuildQueryParamsTransaction(string portList,
            string fromDate, string toDate)
        {
            OracleParameter param2 = new OracleParameter
            {
                ParameterName = "FROMDATE",
                OracleDbType = OracleDbType.Varchar2,
                Direction = ParameterDirection.Input,
                Value = fromDate
            };
            OracleParameter param3 = new OracleParameter
            {
                ParameterName = "TODATE",
                OracleDbType = OracleDbType.Varchar2,
                Direction = ParameterDirection.Input,
                Value = toDate
            };
            OracleParameter param4 = new OracleParameter
            {
                ParameterName = "records1",
                OracleDbType = OracleDbType.RefCursor,
                Direction = ParameterDirection.Output
            };

            List<OracleParameter> oracleParameters = new List<OracleParameter>();
            OracleParameter param1 = new OracleParameter();
            param1.ParameterName = "PORTFOLIONO";
            param1.OracleDbType = OracleDbType.Varchar2;
            param1.Direction = ParameterDirection.Input;
            param1.Value = portList;

            oracleParameters.Add(param1);
            oracleParameters.Add(param2);
            oracleParameters.Add(param3);
            oracleParameters.Add(param4);

            var commandText = _configuration["StoredProcedure:GETTRANSACTION"];

            List<MFAPI_GET_TRANSACTIONModel> result = new List<MFAPI_GET_TRANSACTIONModel>();
            var response =
                await _storedProcedureRepo.GetQueryStore<MFAPI_GET_TRANSACTIONModel>(commandText, oracleParameters);
            return response;
        }

        /// <summary>
        /// 7
        /// </summary>
        /// <param name="portList"></param>
        /// <param name="asOfDate"></param> 
        /// <returns></returns>
        public async Task<PandaResults<List<MFAPI_GET_LTF_RMF_BALModel>>> BuildQueryParamsLTFTMFBalance(
            string portList, string asOfDate)
        {
            OracleParameter param2 = new OracleParameter
            {
                ParameterName = "ASOFDATE",
                OracleDbType = OracleDbType.Varchar2,
                Direction = ParameterDirection.Input,
                Value = asOfDate
            };
            OracleParameter param4 = new OracleParameter
            {
                ParameterName = "RECORDS1",
                OracleDbType = OracleDbType.RefCursor,
                Direction = ParameterDirection.Output
            };

            List<OracleParameter> oracleParameters = new List<OracleParameter>();
            OracleParameter param1 = new OracleParameter();
            param1.ParameterName = "PORTFOLIONO";
            param1.OracleDbType = OracleDbType.Varchar2;
            param1.Direction = ParameterDirection.Input;
            param1.Value = portList;

            oracleParameters.Add(param1);
            oracleParameters.Add(param2);
            oracleParameters.Add(param4);

            var commandText = _configuration["StoredProcedure:GETLTFRMFBAL"];

            List<MFAPI_GET_LTF_RMF_BALModel> result = new List<MFAPI_GET_LTF_RMF_BALModel>();
            //return PandaResponse.CreateSuccessResponse(new List<MFAPI_GET_LTF_RMF_BALModel>());
            var response =
                await _storedProcedureRepo.GetQueryStore<MFAPI_GET_LTF_RMF_BALModel>(commandText, oracleParameters);
            return response;
        }

        public async Task<PandaResults<List<MFPortNoContract>>> SearchPortNo(string searchValue,
            MFEnums.SearchPortEnums searchBy)
        {
            var isDefined = Enum.IsDefined(typeof(MFEnums.SearchPortEnums), searchBy);
            if (!isDefined)
            {
                return PandaResponse.CreateErrorResponse<List<MFPortNoContract>>("Search by invalid.");
            }

            if (string.IsNullOrEmpty(searchValue))
            {
                return PandaResponse.CreateErrorResponse<List<MFPortNoContract>>("Search value invalid.");
            }

            List<OracleParameter> oracleParameters = new List<OracleParameter>();

            OracleParameter param1 = new OracleParameter();
            param1.ParameterName = "SEARCHBY";
            param1.OracleDbType = OracleDbType.Varchar2;
            param1.Direction = ParameterDirection.Input;
            param1.Value = searchBy;
            oracleParameters.Add(param1);

            OracleParameter param2 = new OracleParameter();
            param2.ParameterName = "SEARCHVALUE";
            param2.OracleDbType = OracleDbType.Varchar2;
            param2.Direction = ParameterDirection.Input;
            param2.Value = searchValue;
            oracleParameters.Add(param2);


            OracleParameter param3 = new OracleParameter();
            param3.ParameterName = "records1";
            param3.OracleDbType = OracleDbType.RefCursor;
            param3.Direction = ParameterDirection.Output;
            oracleParameters.Add(param3);

            var commandText = _configuration["StoredProcedure:SEARCHPORTNO"];
            var responseData =
                await _storedProcedureRepo.GetQueryStore<MFPortNoContract>(commandText, oracleParameters);
            if (!responseData.IsError())
            {
                responseData.Data = responseData.Data.OrderBy(o => o.PORTFOLIOCODE).ToList();
            }

            return responseData;
        }


        public async Task<PandaResults<List<MFAPI_GET_PARTIAL_PORTNOModel>>> SearchPartialPortNo(string portfolioNo)
        {
            if (string.IsNullOrEmpty(portfolioNo) || portfolioNo.Length > 100)
            {
                return PandaResponse.CreateErrorResponse<List<MFAPI_GET_PARTIAL_PORTNOModel>>(
                    "Search value invalid.");
            }

            List<OracleParameter> oracleParameters = new List<OracleParameter>();

            OracleParameter param1 = new OracleParameter();
            param1.ParameterName = "PORTFOLIONO";
            param1.OracleDbType = OracleDbType.Varchar2;
            param1.Direction = ParameterDirection.Input;
            param1.Value = portfolioNo;
            oracleParameters.Add(param1);


            OracleParameter param3 = new OracleParameter();
            param3.ParameterName = "RECORDS1";
            param3.OracleDbType = OracleDbType.RefCursor;
            param3.Direction = ParameterDirection.Output;
            oracleParameters.Add(param3);

            var commandText = _configuration["StoredProcedure:SEARCHPARTIALPORTNO"];
            var responseData =
                await _storedProcedureRepo.GetQueryStore<MFAPI_GET_PARTIAL_PORTNOModel>(commandText, oracleParameters);
            if (!responseData.IsError())
            {
                responseData.Data = responseData.Data.OrderBy(o => o.PORTFOLIOCODE).ToList();
            }

            return responseData;
        }


        public async Task<PandaResults<List<MFAPI_GET_SETTLEMENT_DATEModel>>> GetSettlementDate(string portFolioNo)
        {
            if (string.IsNullOrEmpty(portFolioNo))
            {
                return PandaResponse.CreateErrorResponse<List<MFAPI_GET_SETTLEMENT_DATEModel>>("Portfolio invalid.");
            }

            List<OracleParameter> oracleParameters = new List<OracleParameter>();

            OracleParameter param1 = new OracleParameter();
            param1.ParameterName = "PORTFOLIONO";
            param1.OracleDbType = OracleDbType.Varchar2;
            param1.Direction = ParameterDirection.Input;
            param1.Value = portFolioNo;
            oracleParameters.Add(param1);

            OracleParameter param3 = new OracleParameter();
            param3.ParameterName = "RECORDS1";
            param3.OracleDbType = OracleDbType.RefCursor;
            param3.Direction = ParameterDirection.Output;
            oracleParameters.Add(param3);

            var commandText = _configuration["StoredProcedure:GETSETTLEMENTDATE"];
            var responseData =
                await _storedProcedureRepo.GetQueryStore<MFAPI_GET_SETTLEMENT_DATEModel>(commandText, oracleParameters);

            return responseData;
        }


        public async Task<PandaResults<List<MFAPI_GET_SETTLEMENT_DATE_PTModel>>> GetSettlementDatePT(
            string fundName,
            string asOfDate
        )
        {
            if (string.IsNullOrEmpty(fundName))
            {
                return PandaResponse
                    .CreateErrorResponse<List<MFAPI_GET_SETTLEMENT_DATE_PTModel>>("Fund name  invalid.");
            }

            if (string.IsNullOrEmpty(asOfDate))
            {
                return PandaResponse
                    .CreateErrorResponse<List<MFAPI_GET_SETTLEMENT_DATE_PTModel>>("As Of Date invalid.");
            }


            List<OracleParameter> oracleParameters = new List<OracleParameter>();

            OracleParameter param1 = new OracleParameter();
            param1.ParameterName = "FUNDNAME";
            param1.OracleDbType = OracleDbType.Varchar2;
            param1.Direction = ParameterDirection.Input;
            param1.Value = fundName;
            oracleParameters.Add(param1);

            OracleParameter param2 = new OracleParameter();
            param2.ParameterName = "ASOFDATE";
            param2.OracleDbType = OracleDbType.Varchar2;
            param2.Direction = ParameterDirection.Input;
            param2.Value = asOfDate;
            oracleParameters.Add(param2);

            OracleParameter param3 = new OracleParameter();
            param3.ParameterName = "RECORDS1";
            param3.OracleDbType = OracleDbType.RefCursor;
            param3.Direction = ParameterDirection.Output;
            oracleParameters.Add(param3);

            var commandText = _configuration["StoredProcedure:GETSETTLEMENTDATEPT"];

            var responseData =
                await _storedProcedureRepo.GetQueryStore<MFAPI_GET_SETTLEMENT_DATE_PTModel>(commandText,
                    oracleParameters);
            return responseData;
        }


        public async Task<PandaResults<List<MFAPI_GET_SETTLEMENT_DATE_TSPModel>>> GetSettlementDateTSP(string asOfDate)
        {
            if (string.IsNullOrEmpty(asOfDate))
            {
                return PandaResponse.CreateErrorResponse<List<MFAPI_GET_SETTLEMENT_DATE_TSPModel>>(
                    "As Of Date invalid.");
            }

            List<OracleParameter> oracleParameters = new List<OracleParameter>();

            OracleParameter param1 = new OracleParameter();
            param1.ParameterName = "ASOFDATE";
            param1.OracleDbType = OracleDbType.Varchar2;
            param1.Direction = ParameterDirection.Input;
            param1.Value = asOfDate;
            oracleParameters.Add(param1);

            OracleParameter param3 = new OracleParameter();
            param3.ParameterName = "RECORDS1";
            param3.OracleDbType = OracleDbType.RefCursor;
            param3.Direction = ParameterDirection.Output;
            oracleParameters.Add(param3);

            var commandText = _configuration["StoredProcedure:GETSETTLEMENTDATETSP"];
            var responseData =
                await _storedProcedureRepo.GetQueryStore<MFAPI_GET_SETTLEMENT_DATE_TSPModel>(commandText,
                    oracleParameters);
            return responseData;
        }
    }
}