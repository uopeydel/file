using System;
using System.Security.Cryptography;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.Repository.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Models.MSSQL;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;

namespace mf_reportservice.Server.Service.Implement
{ 
    
    public class TokenServiceImpl : ITokenService 
    {
        private readonly ITokenRepository _tokenRepo;
        public TokenServiceImpl(ITokenRepository tokenRepo)
        {
            _tokenRepo = tokenRepo;
        }

        public async Task<PandaResults<bool>> CreateToken(string userId, string refreshToken)
        {
            byte[] salt = new byte[128 / 8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }
            string hashed = Hasher(refreshToken, salt);
            Token tokens = new Token
            {
                RefreshToken = hashed,
                UserId = userId,
                Salt = Convert.ToBase64String(salt),

            };
            var createResult = await _tokenRepo.CreateToken(tokens);
            return createResult;
        }

        public async Task<PandaResults<bool>> ValidToken(string userId, string refreshToken)
        {
            var userToken = await _tokenRepo.ReadToken(userId);

            string hashed = Hasher(
                refreshToken,
                Convert.FromBase64String(userToken.Data.Salt)
            );
            if (hashed.Equals(userToken.Data.RefreshToken))
            {
                return PandaResponse.CreateSuccessResponse(true);
            }
            else
            {
                return PandaResponse.CreateErrorResponse<bool>("Refresh token invalid");
            }
        }

        private string Hasher(string refreshToken, byte[] salt)
        {
            string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: refreshToken,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA1,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));
            return hashed;
        }

        public async Task<PandaResults<bool>> Logout(string userId)
        {
            return await _tokenRepo.Logout(userId);
        }


    }
}