using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;

namespace mf_reportservice.Server.Service.Implement
{
    public class Report06ServiceImpl : IReport06Service
    {
        private readonly IETEService _eteService;

        public Report06ServiceImpl(IETEService eteService)
        {
            _eteService = eteService;
        }


        public async Task<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>> MapTable
            (PortfolioSearchContract portfolioList, List<MFAPI_GET_TRANSACTIONContract> portDetailValues)
        {
            var resultMap = new List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>();
            var customers =
                await _eteService.GetCustomersList(portfolioList.PortfolioList.Select(s => s.RMID).ToList());
            portDetailValues = portDetailValues
                .Where(w =>
                {
                    var isContainBuy = Constant.buy.Contains(w.ORDERSUBTYPECODE);
                    var isContainSwiInSwiOut = Constant.swiInSwiOut.Contains(w.ORDERSUBTYPECODE);
                    var isContainSell = Constant.sell.Contains(w.ORDERSUBTYPECODE);
                    var isContainTranInTranOut = Constant.tranInTranOut.Contains(w.ORDERSUBTYPECODE);
                    var isContainDividend = Constant.dividend.Contains(w.ORDERSUBTYPECODE);
                    return isContainBuy || isContainSwiInSwiOut || isContainSell || isContainTranInTranOut ||
                           isContainDividend;
                }).ToList();

            if (!portDetailValues.Any())
            {
                var showNames =
                    _eteService.FindShowNames(portfolioList.PortfolioList.Select(s => s.RMID).ToList(), customers);
                var result = new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>
                {
                    Keys = portfolioList.PortfolioList,
                    Values = new List<MFAPI_GET_TRANSACTIONContract>(),
                    Headers = new PDFHeaderContract
                    {
                        FullNames = showNames.Distinct().ToList(),
                        FromDate = portfolioList.FromDate,
                        ToDate = portfolioList.ToDate,
                    },
                };
                resultMap.Add(result);
                return resultMap;
            }

            #region JointTypeCode.Single

            var portCodeSingleKey = portfolioList.PortfolioList
                .Where(w => w.JOINTTYPECODE.ToEnum<MFEnums.JointTypeCode>() == MFEnums.JointTypeCode.Single)
                .ToList();

            //Rule: Joint 10  ออก รายงานตาม RMID ลูกค้า
            var portSingleRmidList = portCodeSingleKey.Select(b => b.RMID).Distinct().ToList();

            foreach (var rmid in portSingleRmidList)
            {
                var showNames = _eteService.FindShowNames(new List<string> {rmid}, customers);


                var portsKeyForThisRmid = portCodeSingleKey.Where(w => w.RMID == rmid).ToList();
                var portCodes = portsKeyForThisRmid.Select(s => s.PORTFOLIOCODE).ToList();
                var portValueForThisRmid = portDetailValues
                    .Where(w => portCodes.Contains(w.PORTFOLIOCODE))
                    .ToList();
                if (portValueForThisRmid.Any())
                {
                    var result = new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>
                    {
                        Keys = portsKeyForThisRmid,
                        Values = portValueForThisRmid,
                        Headers = new PDFHeaderContract
                        {
                            FullNames = showNames.Distinct().ToList(),
                            FromDate = portfolioList.FromDate,
                            ToDate = portfolioList.ToDate,
                        },
                    };
                    resultMap.Add(result);
                }
            }

            #endregion

            #region JointTypeCode.Single

            var portCodeJointKey = portfolioList.PortfolioList
                .Where(w => w.JOINTTYPECODE.ToEnum<MFEnums.JointTypeCode>() == MFEnums.JointTypeCode.Joint)
                .ToList();
            //RULE: Port joint ต้อง group ตาม  PORT ID  ก่อน
            var portJointPortfolioCodeKeyList = portCodeJointKey.Select(b => b.PORTFOLIOCODE).ToList();

            var portJointGroupCount = portCodeJointKey.GroupBy(x => x.PORTFOLIOCODE)
                .Select(x => new
                {
                    Count = x.Count(),
                    Code = x.Key,
                    Value = x.ToList()
                })
                .OrderByDescending(x => x.Count).ToList();

            foreach (var portfolioCode in portJointPortfolioCodeKeyList.Distinct())
            {
                var isInReport = resultMap.Any(a => a.Keys.Any(aa => aa.PORTFOLIOCODE.Equals(portfolioCode)));
                if (isInReport)
                {
                    continue;
                }

                var countOfPort = portJointPortfolioCodeKeyList.Count(c => c.Equals(portfolioCode));
                var sameCodeSameCount = portJointGroupCount
                    .Where(w => w.Code.Equals(portfolioCode) && countOfPort == w.Count)
                    .ToList();
                var portRmidList = sameCodeSameCount.SelectMany(s => s.Value.Select(ss => ss.RMID).ToList()).ToList();

                // หา port ไม่โค้ดเหมือนกัน
                // แต่ จำนวน RMID เท่ากัน เหมือนกัน
                var diffCodeSameCount = portJointGroupCount
                    .Where(w => !w.Code.Equals(portfolioCode) && countOfPort == w.Count)
                    .Where(w => w.Value.All(aa => portRmidList.Contains(aa.RMID)))
                    .ToList();

                List<MFAPI_SEARCHPORTNOContract> reportKeys = new List<MFAPI_SEARCHPORTNOContract>();
                List<MFAPI_GET_TRANSACTIONContract> reportValues;
                if (diffCodeSameCount.Any())
                {
                    reportKeys = diffCodeSameCount.SelectMany(s => s.Value).ToList();
                    reportKeys.AddRange(sameCodeSameCount.SelectMany(s => s.Value).ToList());
                }
                else
                {
                    reportKeys = sameCodeSameCount.SelectMany(s => s.Value).ToList();
                }

                var portCodes = reportKeys.Select(s => s.PORTFOLIOCODE).ToList();
                reportValues = portDetailValues.Where(w => portCodes.Contains(w.PORTFOLIOCODE))
                    .OrderByDescending(o => o.TRANSACTIONDATE)
                    .ThenBy(o => o.FUNDNAMETH)
                    .ToList();
                var allportCode = portDetailValues.Select(s => s.PORTFOLIOCODE).ToList();
                if (reportValues.Any())
                {
                    var showNames = _eteService.FindShowNames(portRmidList, customers);
                    var result = new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>
                    {
                        Keys = reportKeys,
                        Values = reportValues,
                        Headers =
                            new PDFHeaderContract
                            {
                                FullNames = showNames.Distinct().ToList(),
                                FromDate = portfolioList.FromDate,
                                ToDate = portfolioList.ToDate,
                            }
                    };
                    resultMap.Add(result);
                }
            }

            #endregion

            if (!resultMap.Any())
            {
                var showNames =
                    _eteService.FindShowNames(portfolioList.PortfolioList.Select(s => s.RMID).ToList(), customers);
                var result = new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>
                {
                    Keys = portfolioList.PortfolioList,
                    Values = new List<MFAPI_GET_TRANSACTIONContract>(),
                    Headers =
                        new PDFHeaderContract
                        {
                            FullNames = showNames.Distinct().ToList(),
                            FromDate = portfolioList.FromDate,
                            ToDate = portfolioList.ToDate,
                        }
                };
                resultMap.Add(result);
            }

            return resultMap;
        }
    }
}