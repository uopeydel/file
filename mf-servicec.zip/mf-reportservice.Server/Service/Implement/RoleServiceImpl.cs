using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.Repository.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Body;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.Extensions;
using Microsoft.EntityFrameworkCore.Internal;

namespace mf_reportservice.Server.Service.Implement
{
    public class RoleServiceImpl : IRoleService
    {
        private readonly IRoleRepository _roleRepository;
        private readonly IRoleFeatureRepository _roleFeatureRepository;

        public RoleServiceImpl(IRoleRepository roleRepository, IRoleFeatureRepository roleFeatureRepository)
        {
            _roleFeatureRepository = roleFeatureRepository;
            _roleRepository = roleRepository;
        }

        public async Task<PandaResults<bool>> IsRoleActiveAndHaveFeature(string roleCode)
        {
            return await _roleRepository.IsRoleActiveAndHaveFeature(roleCode);
        }
        
        public async Task<PandaResults<List<RoleContract>>> GetRoles()
        {
            return await _roleRepository.GetRoles();
        }

        public async Task<PandaResults<List<RoleFeaturesContract>>> GetFeaturesByRole(RoleCreateContract roleCode)
        {
            if (string.IsNullOrEmpty(roleCode.roleCode))
            {
                return PandaResponse.CreateErrorResponse<List<RoleFeaturesContract>>("RoleCode must have value.");
            }

            if (roleCode.roleCode.Length > 250 || roleCode.roleCode.Length < 1)
            {
                return PandaResponse.CreateErrorResponse<List<RoleFeaturesContract>>("RoleCode length not support.");
            }

            return await _roleFeatureRepository.GetFeaturesByRole(roleCode.roleCode);
        }

        public async Task<PandaResults<List<RoleFeaturesContract>>> GetAllFeaturesRoles()
        {
            return await _roleFeatureRepository.GetAllFeaturesRoles();
        }

        public async Task<PandaResults<List<CodeNameContract>>> AddRole(List<RoleCreateContract> role)
        {
            role = role.Where(w => w.roleCode.Length < 250 && w.roleCode.Length > 0)
                .Select(s => new RoleCreateContract
                {
                    feature = s.feature
                        .Where(w => !string.IsNullOrEmpty(w.code))
                        .Select(sf =>
                            new CodeNameContract
                            {
                                code = Helper.LimitLength(sf.code),
                                name = Helper.LimitLength(sf.name)
                            }
                        ).ToList(),
                    roleCode = Helper.LimitLength(s.roleCode),
                    newRoleCode = Helper.LimitLength(s.newRoleCode),
                    roleStatus = s.roleStatus
                }).ToList();


            if (!role.Any())
            {
                return PandaResponse.CreateErrorResponse<List<CodeNameContract>>("Invalid role");
            }

            return await _roleFeatureRepository.AddRole(role);
        }

        public async Task<PandaResults<bool>> InactiveRole(RoleContract roleCode)
        {
            var deleteRoleFeatureResult = await _roleRepository.InactiveRole(roleCode);

            if (deleteRoleFeatureResult.IsError())
            {
                return PandaResponse.CreateErrorResponse<bool>("Invalid role");
            }

            return deleteRoleFeatureResult;
        }
    }
}