﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.MF.Result;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.UserManagement;
using mf_service.SharedService.Models;
using mf_service.SharedService.Models.MSSQL;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace mf_reportservice.Server.Service.Implement
{
    public class DataMapperServiceImpl : IDataMapperService
    {
        private readonly IMapper _mapper;

        public DataMapperServiceImpl(IMapper mapper)
        {
            _mapper = mapper;
        }

        /// <summary>
        /// 1 2 5
        /// </summary>
        /// <param name="datas"></param>
        /// <returns></returns>
        public List<MFAPI_GET_BALANCEContract> MapperModel(List<MFAPI_GET_BALANCEModel> datas)
        {
            datas = datas
                .ToList();
            var dataMapped = new List<MFAPI_GET_BALANCEContract>();
            foreach (var data in datas)
            {
                var mapEachResult = new MFAPI_GET_BALANCEContract();
                _mapper.Map<MFAPI_GET_BALANCEModel, MFAPI_GET_BALANCEContract>(data, mapEachResult);
                dataMapped.Add(mapEachResult);
            }

            return dataMapped;
        }


        private bool IsOrderSubTypeCodeForReport04(string orderSubTypeCode)
        {
            var isSellRebalance = Constant.sellRebalancing.Contains(orderSubTypeCode);
            var isBuyRebalance = Constant.buyRebalancing.Contains(orderSubTypeCode);
            var ismgmtFee = Constant.mgmtFee.Contains(orderSubTypeCode);
            return isSellRebalance || isBuyRebalance || ismgmtFee;
        }

        public List<MFAPI_GET_STMREBALContract> MapperModel(List<MFAPI_GET_STMREBALModel> datas)
        {
            datas = datas
                .Where(w => { return IsOrderSubTypeCodeForReport04(w.ORDERSUBTYPECODE); })
                .OrderByDescending(o => DateTime.Parse(o.TRANSACTIONDATE))
                .ThenByDescending(o => DateTime.Parse(o.EFFECTIVEDATE))
                .ThenBy(o => o.FUNDNAMETH)
                .ThenBy(o => o.PORTFOLIOCODE)
                .ToList();
            var dataMapped = new List<MFAPI_GET_STMREBALContract>();
            foreach (var data in datas)
            {
                var mapEachResult = new MFAPI_GET_STMREBALContract();
                _mapper.Map<MFAPI_GET_STMREBALModel, MFAPI_GET_STMREBALContract>(data, mapEachResult);
                dataMapped.Add(mapEachResult);
            }

            return dataMapped;
        }

        public List<SettlementDateByCalendarTSPResultContract> MapperModel(
            List<MFAPI_GET_SETTLEMENT_DATE_TSPModel> datas)
        {
            var dataMapped = datas.GroupBy(g => g.RED_DATE)
                .Select(s => new SettlementDateByCalendarTSPResultContract
                {
                    RedemptionDate = DateTime.Parse(s.Key).ToString("dd-MMM-yyyy").ToUpper(),
                    Details = s.ToList().Select(ss => new ModelSettlementDate
                    {
                        Model = ss.MODEL,
                        SettlementDate = DateTime.Parse(ss.SETTLEMENT_DATE).ToString("dd-MMM-yyyy").ToUpper()
                    }).ToList()
                }).ToList();
            return dataMapped;
        }

        public List<SettlementDateByCalendarPTResultContract> MapperModel(List<MFAPI_GET_SETTLEMENT_DATE_PTModel> datas)
        {
            List<SettlementDateByCalendarPTResultContract> dataMapped =
                new List<SettlementDateByCalendarPTResultContract>();
            foreach (var data in datas)
            {
                var mapEachResult = new SettlementDateByCalendarPTResultContract();
                _mapper.Map<MFAPI_GET_SETTLEMENT_DATE_PTModel, SettlementDateByCalendarPTResultContract>(data,
                    mapEachResult);
                dataMapped.Add(mapEachResult);
            }

            return dataMapped;
        }

        public List<SettlementDateByCustomerResultContract> MapperModel(List<MFAPI_GET_SETTLEMENT_DATEModel> datas)
        {
            List<SettlementDateByCustomerResultContract>
                dataMapped = new List<SettlementDateByCustomerResultContract>();
            foreach (var data in datas)
            {
                var mapEachResult = new SettlementDateByCustomerResultContract();
                _mapper.Map<MFAPI_GET_SETTLEMENT_DATEModel, SettlementDateByCustomerResultContract>(data,
                    mapEachResult);
                dataMapped.Add(mapEachResult);
            }

            return dataMapped;
        }

        /// <summary>
        /// 7
        /// </summary>
        /// <param name="datas"></param>
        /// <returns></returns>
        public List<MFAPI_GET_LTF_RMF_BALContract> MapperModel(List<MFAPI_GET_LTF_RMF_BALModel> datas)
        {
            List<MFAPI_GET_LTF_RMF_BALContract> dataMapped = new List<MFAPI_GET_LTF_RMF_BALContract>();
            foreach (var data in datas)
            {
                var mapEachResult = new MFAPI_GET_LTF_RMF_BALContract();
                _mapper.Map<MFAPI_GET_LTF_RMF_BALModel, MFAPI_GET_LTF_RMF_BALContract>(data, mapEachResult);
                dataMapped.Add(mapEachResult);
            }

            return dataMapped;
        }

        public List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>> MapperModel(
            List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>> datas)
        {
            var dataMapped = new List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>>();

            foreach (var data in datas)
            {
                var mapEachResult = new PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>();
                mapEachResult.Headers = data.Headers;
                mapEachResult.Keys = data.Keys;
                mapEachResult.Values = new GraphReportPDFContract();
                mapEachResult.Values.Graphs = data.Values.Graphs;
                mapEachResult.Values.Values = new List<List<MFAPI_GET_BALANCE_PDF_Contract>>();


                foreach (var balanceValues in data.Values.Values)
                {
                    var newBalances = new List<MFAPI_GET_BALANCE_PDF_Contract>();
                    foreach (var balanceValue in balanceValues)
                    {
                        var newBalance = new MFAPI_GET_BALANCE_PDF_Contract();
                        _mapper.Map<MFAPI_GET_BALANCEContract, MFAPI_GET_BALANCE_PDF_Contract>(balanceValue,
                            newBalance);
                        newBalances.Add(newBalance);
                    }

                    mapEachResult.Values.Values.Add(newBalances);
                }

                dataMapped.Add(mapEachResult);
            }

            return dataMapped;
        }

        /// <summary>
        /// 3 4 6
        /// </summary>
        /// <param name="datas"></param>
        /// <returns></returns>
        public List<MFAPI_GET_TRANSACTIONContract> MapperModel(List<MFAPI_GET_TRANSACTIONModel> datas)
        {
            List<MFAPI_GET_TRANSACTIONContract> dataMapped = new List<MFAPI_GET_TRANSACTIONContract>();
            foreach (var data in datas)
            {
                var mapEachResult = new MFAPI_GET_TRANSACTIONContract();
                _mapper.Map<MFAPI_GET_TRANSACTIONModel, MFAPI_GET_TRANSACTIONContract>(data, mapEachResult);
                dataMapped.Add(mapEachResult);
            }

            return dataMapped;
        }

        public List<LogExportContract> MapperModel(List<Log> datas)
        {
            List<LogExportContract> dataMapped = new List<LogExportContract>();
            foreach (var data in datas)
            {
                var mapEachResult = new LogExportContract();
                _mapper.Map<Log, LogExportContract>(data, mapEachResult);
                if (!string.IsNullOrEmpty(mapEachResult.Activity))
                {
                    dataMapped.Add(mapEachResult);
                }
            }

            return dataMapped;
            //AdministrationActivityAuditLog
        }
    }
}