using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.ETE;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.Mapper;
using Microsoft.EntityFrameworkCore.Internal;

namespace mf_reportservice.Server.Service.Implement
{
    public class Report01ServiceImpl : IReport01Service
    {
        private readonly IETEService _eteService;

        public Report01ServiceImpl(IETEService eteService)
        {
            _eteService = eteService;
        }

        public async Task<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_BALANCELiteContract>>>>
            MapTable(
                PortfolioSearchContract searchBody,
                List<MFAPI_GET_BALANCEContract> dataMapped)
        {
            var customerId = searchBody.PortfolioList.Where(w => !string.IsNullOrEmpty(w.MAINRMID))
                .Select(s => s.MAINRMID).FirstOrDefault();
            if (string.IsNullOrEmpty(customerId))
            {
                customerId = searchBody.PortfolioList
                    .Where(w => w.JOINTSTATUSCODE.Equals("110"))
                    .Where(w => !string.IsNullOrEmpty(w.RMID)).Select(s => s.RMID)
                    .FirstOrDefault();
            }

            var customers = new List<ETECustomerContract>();
            if (!string.IsNullOrEmpty(customerId))
            {
                customers =
                    await _eteService.GetCustomersList(new List<string> {customerId});
            }

            var resultMap =
                new List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_BALANCELiteContract>>>();

            var sumByPort = new List<MFAPI_GET_BALANCELiteContract>();
            var portCodeList = searchBody.PortfolioList.Select(s => s.PORTFOLIOCODE).Distinct().ToList();
            portCodeList = portCodeList.Where(w => dataMapped.Any(ww => ww.PORTNAME.Equals(w))).ToList();
            if (dataMapped.Any())
            {
                foreach (var portCode in portCodeList)
                {
                    var sumValue = dataMapped.Where(w => w.PORTNAME.Equals(portCode))
                        .Select(s => s.INVESTMENT_VAL)
                        .Sum();

                    sumByPort.Add(new MFAPI_GET_BALANCELiteContract
                    {
                        INVESTMENT_VAL = sumValue,
                        PORTNAME = portCode
                    });
                }

                if (sumByPort.Any())
                {
                    sumByPort.Add(
                        new MFAPI_GET_BALANCELiteContract
                        {
                            INVESTMENT_VAL = sumByPort.Select(s => s.INVESTMENT_VAL).Sum(),
                            PORTNAME = "SUM"
                        });
                }

                var sumByInvestmentType = new List<MFAPI_GET_BALANCELiteContract>();

                //todo sum by investment type
                var advTypes = dataMapped.Select(s => s.ADV_TYPE).Distinct().ToList();
                foreach (var advType in advTypes)
                {
                    //todo enum
                    //20 tmb smart port
                    //10 mutual fund
                    if (advType == "10")
                    {
                        var mutualFundPort = dataMapped.Where(w => w.ADV_TYPE == advType).ToList();
                        //todo enum , wait for TMB change wording
                        sumByInvestmentType.Add(MutualFundSumLTFRMF(mutualFundPort, "NO"));
                        sumByInvestmentType.Add(MutualFundSumLTFRMF(mutualFundPort, "YES"));
                    }
                    else if (advType == "20")
                    {
                        var sumByAdvType = dataMapped.Where(w => w.ADV_TYPE == advType).Sum(s => s.INVESTMENT_VAL);
                        sumByInvestmentType.Add(new MFAPI_GET_BALANCELiteContract
                        {
                            INVESTMENT_VAL = sumByAdvType,
                            ADV_TYPE = advType
                        });
                    }
                }

//sumRegularMutualFund
//sumMutualFund
                var reSumByInvestmentType = new List<MFAPI_GET_BALANCELiteContract>();
                if (sumByInvestmentType.Any())
                {
                    var sum = sumByInvestmentType.Select(s => s.INVESTMENT_VAL).Sum();


                    var sumSmartPort = sumByInvestmentType
                        .Where(w => !string.IsNullOrEmpty(w.ADV_TYPE))
                        .Where(w => w.ADV_TYPE.Equals("20"))
                        .Sum(s => s.INVESTMENT_VAL);
                    reSumByInvestmentType = new List<MFAPI_GET_BALANCELiteContract>
                    {
                        new MFAPI_GET_BALANCELiteContract
                        {
                            AdvType = Constant.sum,
                            INVESTMENT_VAL = sum
                        },
                        new MFAPI_GET_BALANCELiteContract
                        {
                            AdvType = Constant.sumSmartPort,
                            INVESTMENT_VAL = sumSmartPort
                        }
                    };


                    var sumRegularMutualFund = sumByInvestmentType
                        .Where(w => !string.IsNullOrEmpty(w.ADV_TYPE) && !string.IsNullOrEmpty(w.IS_LTF))
                        .Where(w => w.ADV_TYPE.Equals("10") && w.IS_LTF.Equals("NO"));
                    if (sumRegularMutualFund.Any())
                    {
                        reSumByInvestmentType.Add(new MFAPI_GET_BALANCELiteContract
                        {
                            AdvType = Constant.sumRegularMutualFund,
                            INVESTMENT_VAL = sumRegularMutualFund.Sum(s => s.INVESTMENT_VAL)
                        });
                    }

                    var sumMutualFund = sumByInvestmentType
                        .Where(w => !string.IsNullOrEmpty(w.ADV_TYPE) && !string.IsNullOrEmpty(w.IS_LTF))
                        .Where(w => w.ADV_TYPE.Equals("10") && w.IS_LTF.Equals("YES"));
                    if (sumMutualFund.Any())
                    {
                        reSumByInvestmentType.Add(new MFAPI_GET_BALANCELiteContract
                        {
                            AdvType = Constant.sumMutualFund,
                            INVESTMENT_VAL = sumMutualFund.Sum(s => s.INVESTMENT_VAL)
                        });
                    }
                }

                if (sumByPort.Any() || reSumByInvestmentType.Any())
                {
                    var fullNames = _eteService.FindShowNames(new List<string> {customerId}, customers);
                    var address = _eteService.FindShowAddress(new List<string> {customerId}, customers);
                    sumByPort.AddRange(reSumByInvestmentType);
                    sumByPort.ForEach(f =>
                    {
                        f.InvestmentValue =
                            MappingProfile.ConvertToDecimal(f.INVESTMENT_VAL.ToString(CultureInfo.InvariantCulture), 2);
                        f.INVESTMENT_VAL = 0;
                    });
                    resultMap.Add(
                        new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_BALANCELiteContract>>
                        {
                            //Keys = searchBody.PortfolioList,
                            Values = sumByPort,
                            Headers = new PDFHeaderContract
                            {
                                FullNames = fullNames.Distinct().ToList(),
                                FromDate = searchBody.FromDate,
                                Addresses = address
                            }
                        });
                }
            }

            if (!resultMap.Any() || !dataMapped.Any())
            {
                var fullNames = _eteService.FindShowNames(new List<string> {customerId}, customers);
                var address = _eteService.FindShowAddress(new List<string> {customerId}, customers);
                resultMap = new List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_BALANCELiteContract>>>();
                resultMap.Add(
                    new PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_BALANCELiteContract>>
                    {
                        //Keys = searchBody.PortfolioList,
                        Values = new List<MFAPI_GET_BALANCELiteContract>(),
                        Headers = new PDFHeaderContract
                        {
                            FullNames = fullNames.Distinct().ToList(),
                            FromDate = searchBody.FromDate,
                            Addresses = address
                        }
                    });
            }

            return resultMap;
        }


        private MFAPI_GET_BALANCELiteContract MutualFundSumLTFRMF(
            List<MFAPI_GET_BALANCEContract> dataMapped,
            string fundType)
        {
            var fund = dataMapped
                .Where(w => !string.IsNullOrEmpty(w.IS_LTF))
                .Where(w => w.IS_LTF.ToUpper().Equals(fundType))
                .ToList();
            return new MFAPI_GET_BALANCELiteContract
            {
                INVESTMENT_VAL = fund.Select(s => s.INVESTMENT_VAL).Sum(),
                ADV_TYPE = fund.Select(s => s.ADV_TYPE).FirstOrDefault(),
                IS_LTF = fundType
            };
        }
    }
}