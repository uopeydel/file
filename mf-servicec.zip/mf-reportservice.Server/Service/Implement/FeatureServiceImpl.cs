using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.Repository.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.Models.MSSQL;

namespace mf_reportservice.Server.Service.Implement
{
    public class FeatureServiceImpl : IFeatureService
    {
        private readonly IFeatureRepository _featureRepository;

        public FeatureServiceImpl(IFeatureRepository featureRepository)
        {
            _featureRepository = featureRepository;
        }


        public async Task<PandaResults<List<FeatureContract>>> GetFeatures()
        {
            return await _featureRepository.GetFeatures();
        }

        public async Task<PandaResults<FeatureContract>> AddFeatures(FeatureContract feature)
        {
            var now = DateTime.Now.ToLocalTime();
            var newFeature = new Feature
            {
                code = Helper.LimitLength(feature.code),
                created = now,
                modified = now,
                is_active = true,
                name = Helper.LimitLength(feature.name),
            };
            return await _featureRepository.AddFeatures(newFeature);
        }
    }
}