using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Configuration;

namespace mf_reportservice.Server.Service.Implement
{
    public class Report02ServiceImpl : IReport02Service
    {
        private readonly IConfiguration _configuration;
        private readonly IETEService _eteService;
        private readonly string[] _assetName = new string[9];
        public Report02ServiceImpl(
            IConfiguration configuration,
            IETEService eteService)
        {
            _configuration = configuration;
            for (var i = 0; i < 9; i++)
            {
                _assetName[i] = configuration[$"ASSETCLASS:NAMES:{i}"].ToUpper();
                //Console.WriteLine( _assetName[i]);
            }

            _eteService = eteService;
        }
        
        private int OrderByAssetClass(string assetClass)
        {
            var orderIndex = _assetName.IndexOf(assetClass.ToUpper().Replace(" ", ""));
            return orderIndex;
        }

        public async Task<List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>>>
            MapTable(
                PortfolioSearchContract searchBody,
                List<MFAPI_GET_BALANCEContract> dataMapped)
        {
            var resultMap =
                new List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>>();

            var customers =
                await _eteService.GetCustomersList(searchBody.PortfolioList.Select(s => s.RMID).ToList());


            var portCodeList = searchBody.PortfolioList.Select(s => s.PORTFOLIOCODE).ToList();
            foreach (var portCode in portCodeList)
            {
                var rmids = searchBody.PortfolioList.Where(w => w.PORTFOLIOCODE.Equals(portCode)).Select(s => s.RMID)
                    .ToList();
                var fullNames = _eteService.FindShowNames(rmids, customers);

                var values = dataMapped.Where(w => w.PORTNAME.Equals(portCode))
                    .OrderBy(o => OrderByAssetClass(o.ASSET_CLASS))
                    .GroupBy(g => g.ASSET_CLASS)
                    .Select(s => s.ToList())
                    .Where(w => w.Any()).ToList();

                if (values.Any())
                {
                    var graphValue = new GraphReportContract
                    {
                        Values = values,
                        Graphs = BuildChart.MapValueToGraph(values, _configuration)
                    };
                    resultMap.Add(
                        new PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>
                        {
                            //Keys = searchBody.PortfolioList.Where(w => w.PORTFOLIOCODE.Equals(portCode)).ToList(),
                            Values = graphValue,
                            Headers = new PDFHeaderContract
                            {
                                FullNames = fullNames,
                                FromDate = searchBody.FromDate,
                                PortfolioCode = new List<string> {portCode},
                            }
                        });
                }
            }

            if (!resultMap.Any())
            {
                var rmids = searchBody.PortfolioList.Select(s => s.RMID).ToList();
                var fullNames = _eteService.FindShowNames(rmids, customers);

                resultMap.Add(
                    new PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>
                    {
                        //Keys = searchBody.PortfolioList,
                        Values = new GraphReportContract
                        {
                            Graphs = new List<GraphBodyContract> { },
                            Values = new List<List<MFAPI_GET_BALANCEContract>> { }
                        },
                        Headers = new PDFHeaderContract
                        {
                            FullNames = fullNames,
                            FromDate = searchBody.FromDate,
                            PortfolioCode = portCodeList
                        }
                    });
            }

            return resultMap;
        }
    }
}