using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract.ETE;
using System.Linq;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Requester;
using Microsoft.EntityFrameworkCore.Internal;
using Newtonsoft.Json;

namespace mf_reportservice.Server.Service.Implement
{
    public class ETEServiceImpl : IETEService
    {
        private readonly RequesterService _requesterService;

        public ETEServiceImpl(RequesterService requesterService)
        {
            _requesterService = requesterService;
        }

        public async Task<List<ETECustomerContract>> GetCustomersList(List<string> rmids)
        {
            GetCustomersContract getCustomersContract = new GetCustomersContract
            {
                query = rmids.Distinct().Select(s => new GetCustomersSearchContract {customerId = s}).ToList()
            };
            var result = await _requesterService.Request<GetCustomersContract, GetCustomersResponseContract>
                ("GetCustomers", getCustomersContract);

            if (!result.IsError())
            {
                if (result?.Data?.Customers == null)
                {
                    goto ReturnEmpty;
                }
                else if (result.Data.Customers.Any(a => a.Type.Equals("P")))
                {
                    return result.Data.Customers.Where(w => !string.IsNullOrEmpty(w.Profile.ShowName)).ToList();
                }
                else if (result.Data.Customers.Any(a => a.Type.Equals("C")))
                {
                    return result.Data.Customers.Where(w => !string.IsNullOrEmpty(w.CompanyProfile.CompanyName))
                        .ToList();
                }
            }

            ReturnEmpty:
            return new List<ETECustomerContract>();
        }


        private static string SelectShowName(ETECustomerContract customer)
        {
            if (customer.Type.ToUpper().Equals("P"))
            {
                return customer.Profile.FullName;
            }
            else if (customer.Type.ToUpper().Equals("C"))
            {
                return customer.CompanyProfile.CompanyName;
            }
            else
            {
                return null;
            }
        }

        private static string SelectShowAddress(ETECustomerContract customer)
        {
            try
            {
                return
                    customer.Addresses.FirstOrDefault()?.address1 + " \n" +
                    customer.Addresses.FirstOrDefault()?.address2 + " \n" +
                    customer.Addresses.FirstOrDefault()?.address3 + " \n" +
                    customer.Addresses.FirstOrDefault()?.city + " \n" +
                    customer.Addresses.FirstOrDefault()?.postalCode;
                /*address.Add(customer.Addresses.FirstOrDefault()?.address1);
                address.Add(customer.Addresses.FirstOrDefault()?.address2);
                address.Add(customer.Addresses.FirstOrDefault()?.address3);
                address.Add(customer.Addresses.FirstOrDefault()?.city);
                address.Add(customer.Addresses.FirstOrDefault()?.postalCode);*/
            }
            finally
            {
            }
        }

        public List<string> FindShowNames(List<string> rmIds, List<ETECustomerContract> customers)
        {
            var result = new List<string>();
            rmIds.ForEach(rmid =>
            {
                var showName = customers
                    .Where(w => w.CustomerId.Equals(rmid))
                    .Select(SelectShowName)
                    .FirstOrDefault();
                result.Add(!string.IsNullOrEmpty(showName) ? showName : rmid);
            });
            return result;
        }

        public List<string> FindShowAddress(List<string> rmIds, List<ETECustomerContract> customers)
        {
            var result = new List<string>();
            rmIds.ForEach(rmid =>
            {
                var showAddress = customers
                    .Where(w => w.CustomerId.Equals(rmid))
                    .Select(SelectShowAddress)
                    .FirstOrDefault();
                result.Add(!string.IsNullOrEmpty(showAddress) ? showAddress : rmid);
            });
            return result.Where(w => !string.IsNullOrEmpty(w)).ToList();
        }
    }
}