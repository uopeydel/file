using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.Repository.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Models.MSSQL;
using Microsoft.AspNetCore.Internal;

namespace mf_reportservice.Server.Service.Implement
{
    public class LogServiceImpl : ILogService
    {
        private readonly ILogRepository _logRepository;

        public LogServiceImpl(ILogRepository logRepository)
        {
            _logRepository = logRepository;
        }

        public async Task<PandaResults<List<Log>>> ExportLog(string userid, MFEnums.LogType? logType, DateTime? from,
            DateTime? to)
        {
            return await _logRepository.ExportLog(userid, logType, from, to);
        }

        public async Task<PandaResults<bool>> LogAccess(string access)
        {
            return await _logRepository.LogAccess(access);
        }
    }
}