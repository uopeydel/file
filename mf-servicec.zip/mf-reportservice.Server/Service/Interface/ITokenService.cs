using System.Threading.Tasks;
using mf_service.SharedService.Contract;

namespace mf_reportservice.Server.Service.Interface
{
    public interface ITokenService
    {
        Task<PandaResults<bool>> CreateToken(string userId, string refreshToken);
        Task<PandaResults<bool>> ValidToken(string userId, string refreshToken);
        Task<PandaResults<bool>> Logout(string userId);
    }
}