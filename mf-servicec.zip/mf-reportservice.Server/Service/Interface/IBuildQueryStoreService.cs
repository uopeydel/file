﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.MF.Result;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.Models;

namespace mf_reportservice.Server.Service.Interface
{
    public interface IBuildQueryStoreService
    {
        /// <summary>
        /// 1 2 5
        /// </summary>
        /// <param name="portList"></param>
        /// <param name="fromDate"></param>
        /// <returns></returns>
        Task<PandaResults<List<MFAPI_GET_BALANCEModel>>> BuildQueryParamsBalance(string portList, string fromDate);

        /// <summary>
        /// 4
        /// </summary>
        /// <param name="portList"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        Task<PandaResults<List<MFAPI_GET_STMREBALModel>>> BuildQueryParamsRebalance(string portList,
            string fromDate, string toDate);

        /// <summary>
        ///  6
        /// </summary>
        /// <param name="portList"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        Task<PandaResults<List<MFAPI_GET_TRANSACTIONModel>>> BuildQueryParamsTransaction(string portList,
            string fromDate, string toDate);


        /// <summary>
        /// 7
        /// </summary>
        /// <param name="portList"></param>
        /// <param name="asOfDate"></param> 
        /// <returns></returns>
        Task<PandaResults<List<MFAPI_GET_LTF_RMF_BALModel>>> BuildQueryParamsLTFTMFBalance(
            string portList, string asOfDate);

        
        Task<PandaResults<List<MFAPI_GET_PARTIAL_PORTNOModel>>> SearchPartialPortNo(string portfolioNo);
        Task<PandaResults<List<MFPortNoContract>>> SearchPortNo(string searchValue, MFEnums.SearchPortEnums searchBy);


        Task<PandaResults<List<MFAPI_GET_SETTLEMENT_DATEModel>>> GetSettlementDate(string portFolioNo); 
        Task<PandaResults<List<MFAPI_GET_SETTLEMENT_DATE_PTModel>>> GetSettlementDatePT(string fundName,
            string asOfDate); 
        Task<PandaResults<List<MFAPI_GET_SETTLEMENT_DATE_TSPModel>>> GetSettlementDateTSP(string asOfDate);
        }
}