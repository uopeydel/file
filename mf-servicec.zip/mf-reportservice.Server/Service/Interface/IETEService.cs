using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract.ETE;

namespace mf_reportservice.Server.Service.Interface
{
    public interface IETEService
    {
        List<string> FindShowNames(List<string> rmIds, List<ETECustomerContract> customers);
        List<string> FindShowAddress(List<string> rmIds, List<ETECustomerContract> customers);
        Task<List<ETECustomerContract>> GetCustomersList(List<string> toList);
    }
}