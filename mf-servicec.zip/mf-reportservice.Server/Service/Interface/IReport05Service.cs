using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;

namespace mf_reportservice.Server.Service.Interface
{
    public interface IReport05Service
    {
        Task<List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>>>
            MapTable(
                PortfolioSearchContract searchBody,
                List<MFAPI_GET_BALANCEContract> dataMapped);
    }
}