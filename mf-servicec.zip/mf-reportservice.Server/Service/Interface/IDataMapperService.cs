﻿using System;
using System.Collections.Generic;
using mf_service.SharedService.Contract.MF.Result;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Models;
using mf_service.SharedService.Models.MSSQL;

namespace mf_reportservice.Server.Service.Interface
{
    public interface IDataMapperService
    {
        List<MFAPI_GET_BALANCEContract> MapperModel(List<MFAPI_GET_BALANCEModel> datas);
        List<MFAPI_GET_TRANSACTIONContract> MapperModel(List<MFAPI_GET_TRANSACTIONModel> datas);
        List<MFAPI_GET_STMREBALContract> MapperModel(List<MFAPI_GET_STMREBALModel> datas);
        
        List<SettlementDateByCalendarTSPResultContract> MapperModel(List<MFAPI_GET_SETTLEMENT_DATE_TSPModel> datas); 
        List<SettlementDateByCalendarPTResultContract> MapperModel(List<MFAPI_GET_SETTLEMENT_DATE_PTModel> datas);
        List<SettlementDateByCustomerResultContract> MapperModel(List<MFAPI_GET_SETTLEMENT_DATEModel> datas); 
        List<MFAPI_GET_LTF_RMF_BALContract> MapperModel(List<MFAPI_GET_LTF_RMF_BALModel> datas);

        List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>> MapperModel(
            List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportContract>> datas);

        List<LogExportContract> MapperModel(List<Log> data);
    }
}
