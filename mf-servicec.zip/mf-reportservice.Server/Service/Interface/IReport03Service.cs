using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;

namespace mf_reportservice.Server.Service.Interface
{
    public interface IReport03Service
    {
        Task<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>> MapTable
            (PortfolioSearchContract portfolioList, List<MFAPI_GET_TRANSACTIONContract> portDetailValues);
    }
}