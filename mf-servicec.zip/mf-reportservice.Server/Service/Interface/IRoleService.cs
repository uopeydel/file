using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Body;
using mf_service.SharedService.Contract.UserManagement.Result;

namespace mf_reportservice.Server.Service.Interface
{
    public interface IRoleService
    {
        Task<PandaResults<bool>> IsRoleActiveAndHaveFeature(string roleCode);
        Task<PandaResults<List<RoleContract>>> GetRoles();
        Task<PandaResults<List<RoleFeaturesContract>>> GetFeaturesByRole(RoleCreateContract roleCode);
        Task<PandaResults<List<CodeNameContract>>> AddRole(List<RoleCreateContract> role);
        Task<PandaResults<List<RoleFeaturesContract>>> GetAllFeaturesRoles();
        Task<PandaResults<bool>> InactiveRole(RoleContract roleCode);
    }
}