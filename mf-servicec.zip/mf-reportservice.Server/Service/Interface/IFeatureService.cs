using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Result;

namespace mf_reportservice.Server.Service.Interface
{
    public interface IFeatureService
    {
        Task<PandaResults<List<FeatureContract>>> GetFeatures();
        Task<PandaResults<FeatureContract>> AddFeatures(FeatureContract feature);
    }
}