using System.Collections.Generic;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Body;
using mf_service.SharedService.Contract.UserManagement.Result;
using Microsoft.AspNetCore.Internal;

namespace mf_reportservice.Server.ViewModel
{
    public class RoleViewModel
    {
        private readonly IRoleService _roleService;

        public RoleViewModel(IRoleService roleService)
        {
            _roleService = roleService;
        }

        public async Task<PandaResults<bool>> IsRoleActiveAndHaveFeature(string roleCode)
        {
            return await _roleService.IsRoleActiveAndHaveFeature(roleCode);
        }
        
        public async Task<PandaResults<List<RoleContract>>> GetRoles()
        {
            return await _roleService.GetRoles();
        }

        public async Task<PandaResults<List<RoleFeaturesContract>>> GetFeaturesByRole(RoleCreateContract roleCode)
        {
            return await _roleService.GetFeaturesByRole(roleCode);
        }

        public async Task<PandaResults<List<RoleFeaturesContract>>> GetAllFeaturesRoles()
        {
            return await _roleService.GetAllFeaturesRoles();
        }

        public async Task<PandaResults<List<CodeNameContract>>> AddRole(List<RoleCreateContract> role)
        {
            return await _roleService.AddRole(role);
        }

        public async Task<PandaResults<bool>> InactiveRole(RoleContract roleCode)
        {
            return await _roleService.InactiveRole(roleCode);
        }
    }
}