﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.ETE;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using Microsoft.AspNetCore.Mvc;

namespace mf_reportservice.Server.ViewModel
{
    public class Report06ViewModel
    {
        private readonly IReport06Service _report06Service;
        private readonly IDataMapperService _dataMapperService;
        private readonly IBuildQueryStoreService _buildQueryStoreService;


        public Report06ViewModel(
            IBuildQueryStoreService buildQueryStoreService,
            IReport06Service report06Service,
            IDataMapperService dataMapperService
        )
        {
            _buildQueryStoreService = buildQueryStoreService;
            _dataMapperService = dataMapperService;
            _report06Service = report06Service;
        }

        public async Task<
                PandaResults<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>>>
            ReadReport06Data(PortfolioSearchContract searchBody)
        {
            var results = await _buildQueryStoreService.BuildQueryParamsTransaction(
                searchBody.JoinPortList,
                searchBody.FromDate, searchBody.ToDate);
            if (results.IsError())
            {
                return PandaResponse
                    .CreateErrorResponse<
                        List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>>(
                        results.Errors.ToArray());
            }

            var dataMapped = _dataMapperService.MapperModel(results.Data);

            var resultsMap = await _report06Service.MapTable(searchBody, dataMapped);
            return PandaResponse.CreateSuccessResponse(resultsMap);
        }
    }
}