﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.ETE;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.Models;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace mf_reportservice.Server.ViewModel
{
    public class Report05ViewModel
    {
        private readonly IReport05Service _report05Service;
        private readonly IDataMapperService _dataMapperService;
        private readonly IBuildQueryStoreService _buildQueryStoreService;
        private readonly IMFLoggerService _logger;


        public Report05ViewModel(
            IBuildQueryStoreService buildQueryStoreService,
            IReport05Service report05Service,
            IDataMapperService dataMapperService,
            IMFLoggerService logger
        )
        {
            _logger = logger;
            _buildQueryStoreService = buildQueryStoreService;
            _dataMapperService = dataMapperService;
            _report05Service = report05Service;
        }

        public async Task<PandaResults<
                List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>>>>
            ReadReport05Data(PortfolioSearchContract searchBody)
        {
            var results = await _buildQueryStoreService.BuildQueryParamsBalance(
                searchBody.JoinPortList,
                searchBody.FromDate);

            
            if (results.IsError())
            {
                _logger.LogInfo("RE05" ,string.Join(", ", results.Errors),
                    typeof(Report05ViewModel).Name); 
                return PandaResponse
                    .CreateErrorResponse<List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>>>(
                        results.Errors.ToArray());
            }

            var dataMapped = _dataMapperService.MapperModel(results.Data);

            var resultsMap = await _report05Service.MapTable(searchBody, dataMapped);
            
             
            List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>> remap 
                = new List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>>();
            remap = _dataMapperService.MapperModel(resultsMap);
            
            return PandaResponse.CreateSuccessResponse(remap);
        }
    }
}