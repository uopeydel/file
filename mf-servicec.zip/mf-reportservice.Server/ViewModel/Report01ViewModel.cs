﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Constants;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.ETE;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using Microsoft.AspNetCore.Mvc;

namespace mf_reportservice.Server.ViewModel
{
    public class Report01ViewModel
    {
        private readonly IReport01Service _report01Service;
        private readonly IDataMapperService _dataMapperService;
        private readonly IBuildQueryStoreService _buildQueryStoreService;


        public Report01ViewModel(
            IBuildQueryStoreService buildQueryStoreService,
            IReport01Service report01Service,
            IDataMapperService dataMapperService
        )
        {
            _buildQueryStoreService = buildQueryStoreService;
            _dataMapperService = dataMapperService;
            _report01Service = report01Service;
        }

        public async Task<
                PandaResults<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_BALANCELiteContract>>>>>
            ReadReport01Data(PortfolioSearchContract searchBody)
        {
            var results = await _buildQueryStoreService.BuildQueryParamsBalance(
                searchBody.JoinPortList,
                searchBody.FromDate);
            if (results.IsError())
            {
                return PandaResponse
                    .CreateErrorResponse<
                        List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_BALANCELiteContract>>>
                    >(results.Errors.ToArray());
            }

            var dataMapped = _dataMapperService.MapperModel(results.Data);

            var resultsMap = await _report01Service.MapTable(searchBody, dataMapped);
            return PandaResponse.CreateSuccessResponse(resultsMap);
        }
    }
}