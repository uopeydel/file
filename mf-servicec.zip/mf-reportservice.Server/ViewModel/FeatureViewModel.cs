using System.Collections.Generic;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Result;
using Microsoft.AspNetCore.Internal;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace mf_reportservice.Server.ViewModel
{
    public class FeatureViewModel
    {
        private readonly IFeatureService _featureService;

        public FeatureViewModel(IFeatureService featureService)
        {
            _featureService = featureService;
        }

        public async Task<PandaResults<List<FeatureContract>>> GetFeatures()
        {
            return await _featureService.GetFeatures();
        }

        public async Task<PandaResults<FeatureContract>> AddFeatures(FeatureContract feature)
        {
            return await _featureService.AddFeatures(feature);
        }
    }
}