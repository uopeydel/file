using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.MF.Result;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Models;
using mf_service.SharedService.Models.MSSQL;
using Microsoft.AspNetCore.Internal;

namespace mf_reportservice.Server.ViewModel
{
    public class MutualFundViewModel
    {
        private readonly IDataMapperService _dataMapperService;
        private readonly IBuildQueryStoreService _buildQueryStoreService;
        private readonly ILogService _logService;

        public MutualFundViewModel(
            IBuildQueryStoreService buildQueryStoreService,
            IDataMapperService dataMapperService,
            ILogService logService)
        {
            _dataMapperService = dataMapperService;
            _buildQueryStoreService = buildQueryStoreService;
            _logService = logService;
        }

        public async Task<PandaResults<List<SettlementDateByCustomerResultContract>>> GetSettlementDate(
            GetSettlementDateSearchContract searchBody)
        {
            var storedResult = await _buildQueryStoreService.GetSettlementDate(
                string.Join(",", searchBody.portFolioNo.ToArray())
            );
            if (storedResult.IsError())
            {
                return PandaResponse.CreateErrorResponse<List<SettlementDateByCustomerResultContract>>(
                    storedResult.Errors.ToArray());
            }

            var dataMapped = _dataMapperService.MapperModel(storedResult.Data);

            return PandaResponse.CreateSuccessResponse(dataMapped);
        }

        public async Task<PandaResults<List<SettlementDateByCalendarPTResultContract>>> GetSettlementDatePT(
            GetSettlementDateSearchContract searchBody)
        {
            var storedResult =
                await _buildQueryStoreService.GetSettlementDatePT(searchBody.fundName, searchBody.asOfDate);
            if (storedResult.IsError())
            {
                return PandaResponse.CreateErrorResponse<List<SettlementDateByCalendarPTResultContract>>(
                    storedResult.Errors.ToArray());
            }

            var dataMapped = _dataMapperService.MapperModel(storedResult.Data);
            return PandaResponse.CreateSuccessResponse(dataMapped);
        }

        public async Task<PandaResults<List<SettlementDateByCalendarTSPResultContract>>> GetSettlementDateTSP(
            GetSettlementDateSearchContract searchBody)
        {
            var storedResult = await _buildQueryStoreService.GetSettlementDateTSP(searchBody.asOfDate);
            if (storedResult.IsError())
            {
                return PandaResponse.CreateErrorResponse<List<SettlementDateByCalendarTSPResultContract>>(
                    storedResult.Errors.ToArray());
            }

            var dataMapped = _dataMapperService.MapperModel(storedResult.Data);

            return PandaResponse.CreateSuccessResponse(dataMapped);
        }

        public async Task<PandaResults<List<LogExportContract>>> ExportLog(string userid, MFEnums.LogType? logType, DateTime? from,
            DateTime? to)
        {
            var result = await _logService.ExportLog(userid, logType, from, to);
            if (result.IsError())
            {
                return PandaResponse.CreateErrorResponse<List<LogExportContract>>(
                    result.Errors.ToArray());
            }
            
            var dataMapped = _dataMapperService.MapperModel(result.Data);
            
            return PandaResponse.CreateSuccessResponse(dataMapped);
        }
    }
}