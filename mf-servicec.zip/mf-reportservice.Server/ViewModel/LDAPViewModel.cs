using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_service.LDAP.Contract;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Internal;

namespace mf_reportservice.Server.ViewModel
{
    public class LDAPViewModel
    {
        private readonly ILDAPService _ldapService;
        private readonly ITokenService _tokenService;
        private readonly IRoleService _roleService;
        private readonly IMFLoggerService _logger;
        private readonly ILogService _logService;
        public LDAPViewModel(
            ILDAPService ldapService, 
            ITokenService tokenService, 
            IRoleService roleService, 
            IMFLoggerService logger,
            ILogService logService)
        {
            _ldapService = ldapService;
            _tokenService = tokenService;
            _roleService = roleService;
            _logger = logger;
            _logService = logService;
        }

        public async Task<ObjectResult> Login(Func<int, object, ObjectResult> func, LoginContract loginContract)
        {
            var result = _ldapService.Login(loginContract);
            if (result.IsError())
            {
                Console.WriteLine("Login");
 
                _logger.LogObj(" LDAP LOGIN ERROR ",  result.Errors, typeof(LDAPViewModel).Name);

                result.Errors = new List<string>
                    {"Access denied, Invalid User ID - Password and / or not Authorized to access"};
 
                var errorObj = PandaResponse.CreateErrorResponse<LDAPLoginResponseContract>(
                    result.Errors.ToArray());
                return func(401, errorObj);
            }

            var roleResult = await _roleService.IsRoleActiveAndHaveFeature(result.Data.authority.ToUpper());
            if (roleResult.IsError())
            {
                Console.WriteLine("GetRoles");
                _logger.LogObj(" LDAP GET ROLE ERROR ",  roleResult.Errors, typeof(LDAPViewModel).Name);
                roleResult.Errors = new List<string>
                    {"Access denied, Invalid User ID - Password and / or not Authorized to access"};
                var errorObj = PandaResponse.CreateErrorResponse<LDAPLoginResponseContract>(
                    roleResult.Errors.ToArray());
                return func(401, errorObj);
            }

            var isRoleContain = roleResult.Data;
            if (!isRoleContain)
            {
                Console.WriteLine("!isRoleContain");
                _logger.LogObj(" LDAP GET !IS ROLE CONTAIN ",  default, typeof(LDAPViewModel).Name);
                roleResult.Errors = new List<string>
                    {"Access denied, Invalid User ID - Password and / or not Authorized to access"};
                var errorObj = PandaResponse.CreateErrorResponse<LDAPLoginResponseContract>(
                    roleResult.Errors.ToArray());
                return func(401, errorObj);
            }


            var createToken =
                await _tokenService.CreateToken(userId: result.Data.userId, refreshToken: result.Data.refresh_token);
            if (createToken.IsError())
            {
                Console.WriteLine("createToken");
                _logger.LogObj(" LDAP GET CREATE TOKEN ",  createToken.Errors, typeof(LDAPViewModel).Name);
                createToken.Errors = new List<string>
                    {"Access denied, Invalid User ID - Password and / or not Authorized to access"};
                var errorObj = PandaResponse.CreateErrorResponse<LDAPLoginResponseContract>(
                    createToken.Errors.ToArray());
                return func(401, errorObj);
            }
            _logger.LogObj(" LDAP LOGIN SUCCESS ",  default, typeof(LDAPViewModel).Name);
            await _logService.LogAccess("Login");
            return func(200, result);
        }


        public async Task<ObjectResult> RefreshToken(Func<int, object, ObjectResult> func, RefreshTokenContract token)
        {
            var refreshTokenResults = _ldapService.RefreshToken(token);
            if (refreshTokenResults.IsError())
            {
                var errorObj = PandaResponse.CreateErrorResponse<LDAPLoginResponseContract>(
                    refreshTokenResults.Errors.FirstOrDefault());
                return func(401, errorObj);
            }

            var (refreshTokenResult, userId) = refreshTokenResults.Data;

            var tokenIsValid = await _tokenService.ValidToken(userId, token.RefreshToken);
            if (tokenIsValid.IsError())
            {
                tokenIsValid.Errors = new List<string>
                    {"Access denied, Invalid User ID - Password and / or not Authorized to access"};
                var errorObj = PandaResponse.CreateErrorResponse<LDAPLoginResponseContract>(
                    tokenIsValid.Errors.ToArray());
                return func(401, errorObj);
            }

            var updateTokenResult =
                await _tokenService.CreateToken(userId, refreshTokenResult.refresh_token);
            if (updateTokenResult.IsError())
            {
                updateTokenResult.Errors = new List<string>
                    {"Access denied, Invalid User ID - Password and / or not Authorized to access"};
                var errorObj = PandaResponse.CreateErrorResponse<LDAPLoginResponseContract>(
                    updateTokenResult.Errors.ToArray()
                );
                return func(401, errorObj);
            }

            return func(200, PandaResponse.CreateSuccessResponse(refreshTokenResult));
        }

        public async Task<ObjectResult> Logout(Func<int, object, ObjectResult> func, LoginContract logout)
        {
            var logoutResult = await _tokenService.Logout(logout.UserName);
            Console.WriteLine("LOGOUx");
            if (logoutResult.IsError())
            {
                return func(500, logoutResult);
            }
            else
            {
                _logger.LogObj(" LDAP LOGOUT SUCCESS ",  default, typeof(LDAPViewModel).Name);
                Console.WriteLine("LOGOUTTTTT");
                await _logService.LogAccess("Logout");
                return func(200, logoutResult);
            }
        }
    }
}