﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using mf_service.SharedService.MfLogProvider;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace mf_reportservice.Server
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((hostingContext, config) =>
                {
                    var env = hostingContext.HostingEnvironment;
                    config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                        .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true);

                    config.SetBasePath(Directory.GetCurrentDirectory());  
                    if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX) || RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    {
                        config.AddXmlFile(
                            "wwwroot/MapperConfig.xml", optional: false, reloadOnChange: false);
                    }
                    else
                    {
                        config.AddXmlFile(
                            "./MapperConfig.xml", optional: false, reloadOnChange: false);
                    }

                    config.AddCommandLine(args);
                })
                .ConfigureLogging(builder => builder.AddFile(opts =>
                {
                    opts.FileName = "service-";
                    //opts.FileSizeLimit = 10 * 1024 * 1024;
                }))
                .UseStartup<Startup>();
    }
}