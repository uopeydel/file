using System.Threading.Tasks;
using mf_reportservice.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace mf_reportservice.Server.Controllers
{
    [Route("api/v1/feature")]
    public class FeatureController : BaseController
    {
        private readonly FeatureViewModel _viewModel;
        private readonly IMFLoggerService _logger;

        public FeatureController(FeatureViewModel viewModel, IMFLoggerService logger)
        {
            _logger = logger;
            _viewModel = viewModel;
        }

        [AllowAnonymous]
        [HttpPost("")]
        public async Task<IActionResult> GetAll()
        {
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET FEATURE ", default, typeof(FeatureController).Name);
            var result = await _viewModel.GetFeatures();
            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("create")]
        public async Task<IActionResult> AddFeatures([FromBody] FeatureContract feature)
        {
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" ADD FEATURE ", feature, typeof(FeatureController).Name);
            var result = await _viewModel.AddFeatures(feature);
            return Ok(result);
        }
    }
}