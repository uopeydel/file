﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Mvc;


namespace mf_reportservice.Server.Controllers
{
    [Route("api/v1/r06")]
    public class Report06Controller : BaseController
    {
        private readonly Report06ViewModel _report06ViewModel;
        private readonly IMFLoggerService _logger;

        public Report06Controller(Report06ViewModel report06ViewModel, IMFLoggerService logger)
        {
            _logger = logger;
            _report06ViewModel = report06ViewModel;
        }

        [HttpPost("")]
        public async Task<IActionResult> Data([FromBody] PortfolioSearchContract searchBody)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
            }
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET DATA REPORT 6 ", searchBody, typeof(Report06Controller).Name);
            var result = await _report06ViewModel.ReadReport06Data(searchBody);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }
    }
}