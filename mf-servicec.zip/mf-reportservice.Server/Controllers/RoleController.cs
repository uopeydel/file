using System.Collections.Generic;
using System.Threading.Tasks;
using mf_reportservice.Server.ViewModel;
using mf_service.SharedService.Contract.UserManagement.Body;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace mf_reportservice.Server.Controllers
{
    [Route("api/v1/role")]
    public class RoleController : BaseController
    {
        private readonly RoleViewModel _viewModel;
        private readonly IMFLoggerService _logger;

        public RoleController(RoleViewModel viewModel, IMFLoggerService logger)
        {
            _logger = logger;
            _viewModel = viewModel;
        }

        [AllowAnonymous]
        [HttpPost("")]
        public async Task<IActionResult> GetAll()
        {
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET ALL ROLE ", default, typeof(RoleController).Name);
            var result = await _viewModel.GetRoles();
            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("code")]
        public async Task<IActionResult> GetFeaturesByRole([FromBody] RoleCreateContract roleCode)
        {
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET BY CODE ", roleCode, typeof(RoleController).Name);
            var result = await _viewModel.GetFeaturesByRole(roleCode);
            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("all")]
        public async Task<IActionResult> GetAllFeaturesRoles()
        {
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET ALL ", default, typeof(RoleController).Name);
            var result = await _viewModel.GetAllFeaturesRoles();
            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("inactive")]
        public async Task<IActionResult> InactiveRole([FromBody] RoleContract role)
        {
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" INACTIVE BY CODE ", role, typeof(RoleController).Name);
            var result = await _viewModel.InactiveRole(role);
            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("create")]
        public async Task<IActionResult> AddRole([FromBody] List<RoleCreateContract> role)
        {
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" CREATE ROLE ", role, typeof(RoleController).Name);
            var result = await _viewModel.AddRole(role);
            return Ok(result);
        }
    }
}