﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.ViewModel;
using mf_service.LDAP.Contract;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


namespace mf_reportservice.Server.Controllers
{
    [AllowAnonymous]
    [Route("api/ldap")]
    public class LDAPController : BaseController
    {
        private readonly LDAPViewModel _ldapViewModel;
        private readonly IMFLoggerService _logger;

        public LDAPController(LDAPViewModel ldapViewModel, IMFLoggerService logger)
        {
            _logger = logger;
            _ldapViewModel = ldapViewModel;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginContract loginContract)
        {
            var logDesc = LogDesc;
            logDesc.UserId = loginContract.UserName;
            _logger.SetLogDesc(logDesc);

            var loginResult = await _ldapViewModel.Login(StatusCode, loginContract);
            _logger.LogObj($" LOGIN {loginContract.UserName} ", loginResult, typeof(LDAPController).Name);
            return loginResult;
        }

        [HttpPost("refresh")]
        public async Task<IActionResult> RefreshToken([FromBody] RefreshTokenContract token)
        {
            return await _ldapViewModel.RefreshToken(StatusCode, token);
        }

        [HttpPost("logout")]
        public async Task<IActionResult> Logout([FromBody] LoginContract logout)
        {
            var logDesc = LogDesc;
            Console.WriteLine( logDesc.UserId + "  LOGOUT <<"  );
            _logger.SetLogDesc(logDesc);
            return await _ldapViewModel.Logout(StatusCode, logout);
        }
    }
}