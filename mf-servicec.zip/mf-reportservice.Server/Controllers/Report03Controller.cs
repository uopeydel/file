﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Mvc;


namespace mf_reportservice.Server.Controllers
{
    [Route("api/v1/r03")]
    public class Report03Controller : BaseController
    {
        private readonly Report03ViewModel _report03ViewModel;
        private readonly IMFLoggerService _logger;

        public Report03Controller(Report03ViewModel report03ViewModel, IMFLoggerService logger)
        {
            _logger = logger;
            _report03ViewModel = report03ViewModel;
        }

        [HttpPost("")]
        public async Task<IActionResult> Data([FromBody] PortfolioSearchContract searchBody)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
            }
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET DATA REPORT 3 ", searchBody, typeof(Report03Controller).Name);
            var result = await _report03ViewModel.ReadReport03Data(searchBody);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }
    }
}