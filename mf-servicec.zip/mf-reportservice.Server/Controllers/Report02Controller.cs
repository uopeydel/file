﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Mvc;


namespace mf_reportservice.Server.Controllers
{
    [Route("api/v1/r02")]
    public class Report02Controller : BaseController
    {
        private readonly Report02ViewModel _report02ViewModel;
        private readonly IMFLoggerService _logger;

        public Report02Controller(Report02ViewModel report02ViewModel, IMFLoggerService logger)
        {
            _logger = logger;
            _report02ViewModel = report02ViewModel;
        }

        [HttpPost("")]
        public async Task<IActionResult> Data([FromBody] PortfolioSearchContract searchBody)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET DATA REPORT 2 ", searchBody, typeof(Report02Controller).Name);
            var result = await _report02ViewModel.ReadReport02Data(searchBody);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }
    }
}