﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_service.SharedService.Middlewares;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace mf_reportservice.Server.Controllers
{
    public class BaseController : Controller
    {
        protected LogDesc LogDesc
        {
            get
            {
                var newLogDesc = (LogDesc) HttpContext.Items["logDesc"];
                newLogDesc.Uuid = HttpContext?.Request?.Headers?.Where(w => w.Key == "MFUUID").Select(s => s.Value)
                    .FirstOrDefault();
                newLogDesc.UserId = HttpContext?.Request?.Headers?.Where(w => w.Key == "MFUSERID").Select(s => s.Value)
                    .FirstOrDefault();

                Console.ResetColor();

                return newLogDesc;
            }
        }
    }
}