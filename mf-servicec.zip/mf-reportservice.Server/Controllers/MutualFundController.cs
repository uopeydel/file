﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.Service.Interface;
using mf_reportservice.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.MF.Result;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace mf_reportservice.Server.Controllers
{
    [Route("api/mutualfund")]
    public class MutualFundController : BaseController
    {
        private readonly IBuildQueryStoreService _buildQueryStoreService;
        private readonly MutualFundViewModel _mfViewModel;
        private readonly IETEService _eteService;
        private readonly IMFLoggerService _logger;


        public MutualFundController(
            IBuildQueryStoreService buildQueryStoreService,
            MutualFundViewModel mfViewModel,
            IETEService eteService,
            IMFLoggerService logger
        )
        {
            _logger = logger;
            _eteService = eteService;
            _mfViewModel = mfViewModel;
            _buildQueryStoreService = buildQueryStoreService;
        }

        [AllowAnonymous]
        [HttpPost("searchportno")]
        public async Task<IActionResult> SearchPortNo([FromBody] SearchPortNoContract searchBody)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" SEARCH PORT NO ", searchBody, typeof(MutualFundController).Name);
            var result = await _buildQueryStoreService.SearchPortNo(searchBody.SearchValue, searchBody.SearchBy);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("searchpartialportno")]
        public async Task<IActionResult> SearchPartialPortNo([FromBody] SearchPartialPortNoContract searchBody)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" SEARCH PARTIAL PORT NO ", searchBody, typeof(MutualFundController).Name);
            var result = await _buildQueryStoreService.SearchPartialPortNo(searchBody.PORTFOLIONO);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }


        [AllowAnonymous]
        [HttpPost("GetSettlementDate")]
        public async Task<IActionResult> GetSettlementDate([FromBody] GetSettlementDateSearchContract searchBody)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET SETTLEMENT DATE ", searchBody, typeof(MutualFundController).Name);
            var result = await _mfViewModel.GetSettlementDate(searchBody);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("GetSettlementDatePT")]
        public async Task<IActionResult> GetSettlementDatePT([FromBody] GetSettlementDateSearchContract searchBody)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET SETTLEMENT DATE PT ", searchBody, typeof(MutualFundController).Name);
            var result = await _mfViewModel.GetSettlementDatePT(searchBody);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("GetSettlementDateTSP")]
        public async Task<IActionResult> GetSettlementDateTSP([FromBody] GetSettlementDateSearchContract searchBody)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET SETTLEMENT DATE PT ", searchBody, typeof(MutualFundController).Name);
            var result = await _mfViewModel.GetSettlementDateTSP(searchBody);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }


        [AllowAnonymous]
        [HttpPost("getcustomerete")]
        public async Task<IActionResult> GetCustomerETE([FromBody] List<string> rmids)
        {
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET CUSTOMER ETE ", rmids, typeof(MutualFundController).Name);
            var result = await _eteService.GetCustomersList(rmids);
            return Ok(result);
        }

        [AllowAnonymous]
        [HttpPost("exportlog")]
        public async Task<IActionResult> ExportLog([FromBody] GetLogContract searchBody)
        {
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET LOG ", searchBody, typeof(MutualFundController).Name);
            var result =
                await _mfViewModel.ExportLog(searchBody.userid, searchBody.logType, searchBody.from, searchBody.to);
            return Ok(result);
        }
    }
}