﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.MF.Search;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileProviders;

namespace mf_reportservice.Server.Controllers
{
    [Route("api/healthchecklog")]
    public class HealthCheckLogController : Controller
    {
        [AllowAnonymous]
        [HttpGet("lastestlog")]
        public IActionResult GetLastestLogReport([FromBody] GetLogReport getBody)
        {
            string filePath = Directory.GetCurrentDirectory() + "/Logs";

            IFileProvider provider = new PhysicalFileProvider(filePath);

            //Format Date file yyyymmdd example service-2019-12-24.log
            string fileName = "service-" + getBody.dateFile.Substring(0, 4) + "-" + getBody.dateFile.Substring(4, 2) + "-" + getBody.dateFile.Substring(6, 2) + ".log";

            IFileInfo fileInfo = provider.GetFileInfo(fileName);
            if (fileInfo.Exists)
            {
                var readStream = fileInfo.CreateReadStream();
                var mimeType = "text/plain";
                return File(readStream, mimeType, fileName);
            }
            else
            {
                return Ok("File Not Found");
            }
        }

        [AllowAnonymous]
        [HttpGet("previouslog")]
        public IActionResult GetPreviousLogReport([FromBody] GetLogReport getBody)
        {
            string filePath = Directory.GetCurrentDirectory() + "/Archive";

            IFileProvider provider = new PhysicalFileProvider(filePath);

            //Format Date file yyyymmdd example archive_log_20191224.zip
            string fileName = "archive_log_" + getBody.dateFile + ".zip";

            IFileInfo fileInfo = provider.GetFileInfo(fileName);
            if (fileInfo.Exists)
            {
                var readStream = fileInfo.CreateReadStream();
                var mimeType = "application/x-zip-compressed";
                return File(readStream, mimeType, fileName);
            }
            else
            {
                return Ok("File Not Found");
            }
        }
    }
}