﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_reportservice.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Mvc;


namespace mf_reportservice.Server.Controllers
{
    [Route("api/v1/r04")]
    public class Report04Controller : BaseController
    {
        private readonly Report04ViewModel _report04ViewModel;
        private readonly IMFLoggerService _logger;

        public Report04Controller(Report04ViewModel report04ViewModel, IMFLoggerService logger)
        {
            _logger = logger;
            _report04ViewModel = report04ViewModel;
        }

        [HttpPost("")]
        public async Task<IActionResult> Data([FromBody] PortfolioSearchContract searchBody)
        {
            if (!ModelState.IsValid)
            {
                return StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
            }
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET DATA REPORT 4 ", searchBody, typeof(Report04Controller).Name);
            var result = await _report04ViewModel.ReadReport04Data(searchBody);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }
    }
}