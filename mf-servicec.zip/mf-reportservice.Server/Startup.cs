﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using Microsoft.AspNetCore.Mvc.Cors.Internal;
using System.Runtime.InteropServices;
using Microsoft.Extensions.Logging;
using FluentValidation.AspNetCore;
using Rotativa.AspNetCore;
using Microsoft.Extensions.FileProviders;
using System.IO;
using Microsoft.Extensions.Configuration.Xml;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Diagnostics;
using System.Collections.Generic;
using mf_reportservice.Server.SystemService;
using mf_service.Repository.DataAccess;
using mf_service.SharedService.Contract.ETE;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.Middlewares;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;

namespace mf_reportservice.Server
{
    public class Startup
    {
        public IConfigurationRoot ConfigurationRoot { get; set; }

        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            Configuration = configuration;

            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);

            ConfigurationRoot = builder.Build();
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            var MFDbConnection = Configuration.GetConnectionString("MFDbConnection");
            var previousPassword = (MFDbConnection.Split(";")[3]).Replace("Password=", "");
            /*var encrypted = AesMf.EncryptAES(
                 "MFAPI__2019", 
                 Encoding.UTF8.GetBytes(mf_service.SharedService.Contract.Constants.Constant.AesKey), 
                 Encoding.UTF8.GetBytes(mf_service.SharedService.Contract.Constants.Constant.AesIV)
            );*/
          
            var password = AesMf.DecryptAES(
                 previousPassword,
                 Encoding.UTF8.GetBytes(mf_service.SharedService.Contract.Constants.Constant.AesKey),
                 Encoding.UTF8.GetBytes(mf_service.SharedService.Contract.Constants.Constant.AesIV)
            );

            MFDbConnection = MFDbConnection.Replace(previousPassword, password);
            services.AddDbContext<MFDbContext>(options => { options.UseSqlServer(MFDbConnection); });


            services.AddCors(options =>
            {
                options.AddPolicy("mf",
                    builder =>
                    {
                        builder.AllowAnyOrigin()
                            .AllowAnyHeader()
                            .AllowAnyMethod();
                    });
            });

            services.AddIoc(Configuration);


            services.AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_2)
                .AddJsonOptions(options => { options.SerializerSettings.Formatting = Formatting.Indented; })
                .AddFluentValidation();

            services.Configure<List<APIConfigContract>>(Configuration.GetSection("API"));
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
#if DEBUG
            Console.WriteLine("DEBUG MODE");
#endif
            Console.WriteLine("\nEnvironmentName : {0}\n", env.EnvironmentName);
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseCors("mf");
            app.UseHttpsRedirection();

            app.UseStaticFiles();

            app.UseMiddleware<RequestLoggingMiddleware>();

            app.UseMvc(routes => { routes.MapRoute(name: "default", template: "{controller}/{action}/{id?}"); });
        }
    }
}