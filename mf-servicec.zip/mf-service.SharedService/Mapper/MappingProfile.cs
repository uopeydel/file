using System;
using System.Linq;
using System.Globalization;
using AutoMapper;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.MF.Result;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.UserManagement;
using mf_service.SharedService.Models;
using mf_service.SharedService.Models.MSSQL;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace mf_service.SharedService.Mapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile(IConfiguration configuration)
        {
            CreateMap<MFAPI_GET_TRANSACTIONModel, MFAPI_GET_TRANSACTIONContract>()
                .ForMember(
                    f => f.AmountFormat,
                    opt => opt.MapFrom(mf => ConvertToDecimal(mf.AMOUNT, 2)))
                .ForMember(
                    f => f.OrderSubTypeName,
                    opt => opt.MapFrom(mf =>
                        string.IsNullOrEmpty(mf.ORDERSUBTYPECODE)
                            ? "-"
                            : configuration[$"ORDERSUBTYPECODE:{mf.ORDERSUBTYPECODE}"]
                    ))
                .ForMember(
                    f => f.Status,
                    opt => opt.MapFrom(mf =>
                        string.IsNullOrEmpty(mf.STATUSCODE) ||
                        string.IsNullOrEmpty(configuration[$"STATUSCODE:CODE{mf.STATUSCODE}"])
                            ? "-"
                            : configuration[$"STATUSCODE:CODE{mf.STATUSCODE}"]
                    ))
                .ForMember(
                    f => f.StatusColor,
                    opt => opt.MapFrom(mf =>
                        mf.STATUSCODE == "90" ? "#1E90FF" :
                        (new[] {"0", "21", "22"}).Contains(mf.STATUSCODE) ? "#DC143C" :
                        (new[] {"35", "40"}).Contains(mf.STATUSCODE) ? "#1E90FF" : "#000000"
                    )) //todo status 24 Pre-Trade Payment Rejected. //wait for processing
                .ForMember(
                    f => f.UNIT,
                    opt => opt.MapFrom(mf => ConvertToDecimal(mf.UNIT, 4)))
                .ForMember(
                    f => f.PRICE,
                    opt => opt.MapFrom(mf => ConvertToDecimal(mf.PRICE, 4)
                    ))
                .ForMember(
                    f => f.DateEffective,
                    opt => opt.MapFrom(mf =>
                        DateTime.Parse(mf.EFFECTIVEDATE).ToString("dd-MMM-yyyy").ToUpper()
                    ))
                .ForMember(
                    f => f.DateTransaction,
                    opt => opt.MapFrom(mf =>
                        DateTime.Parse(mf.TRANSACTIONDATE).ToString("dd-MMM-yyyy").ToUpper()
                    ))
                .ReverseMap();


            CreateMap<MFAPI_GET_STMREBALModel, MFAPI_GET_STMREBALContract>()
                .ForMember(
                    f => f.AmountFormat,
                    opt => opt.MapFrom(mf => ConvertToDecimal(mf.AMOUNT.ToString(CultureInfo.InvariantCulture), 2)))
                .ForMember(
                    f => f.OrderSubTypeName,
                    opt => opt.MapFrom(mf =>
                        string.IsNullOrEmpty(mf.ORDERSUBTYPECODE)
                            ? "-"
                            : configuration[$"ORDERSUBTYPECODE:{mf.ORDERSUBTYPECODE}"]
                    ))
                .ForMember(
                    f => f.Status,
                    opt => opt.MapFrom(mf =>
                        string.IsNullOrEmpty(mf.STATUSCODE) ||
                        string.IsNullOrEmpty(configuration[$"STATUSCODE:CODE{mf.STATUSCODE}"])
                            ? "-"
                            : configuration[$"STATUSCODE:CODE{mf.STATUSCODE}"]
                    ))
                .ForMember(
                    f => f.StatusColor,
                    opt => opt.MapFrom(mf =>
                        mf.STATUSCODE == "90" ? "#1E90FF" :
                        (new[] {"0", "21", "22"}).Contains(mf.STATUSCODE) ? "#DC143C" :
                        (new[] {"35", "40", "20"}).Contains(mf.STATUSCODE) ? "#1E90FF" : "#000000"
                    ))
                .ForMember(
                    f => f.UNIT,
                    opt => opt.MapFrom(mf => ConvertToDecimal(mf.UNIT.ToString(CultureInfo.InvariantCulture), 4)
                    ))
                .ForMember(
                    f => f.PRICE,
                    opt => opt.MapFrom(mf => ConvertToDecimal(mf.PRICE.ToString(CultureInfo.InvariantCulture), 4)
                    ))
                .ForMember(
                    f => f.DateEffective,
                    opt => opt.MapFrom(mf =>
                        DateTime.Parse(mf.EFFECTIVEDATE).ToString("dd-MMM-yyyy").ToUpper()
                    ))
                .ForMember(
                    f => f.DateTransaction,
                    opt => opt.MapFrom(mf =>
                        DateTime.Parse(mf.TRANSACTIONDATE).ToString("dd-MMM-yyyy").ToUpper()
                    ))
                .ReverseMap();

            CreateMap<MFAPI_GET_LTF_RMF_BALModel, MFAPI_GET_LTF_RMF_BALContract>()
                .ReverseMap();

            CreateMap<MFAPI_GET_BALANCE_PDF_Contract, MFAPI_GET_BALANCEContract>()
                .ReverseMap();

            CreateMap<MFAPI_GET_BALANCEModel, MFAPI_GET_BALANCEContract>()
                .ForMember(
                    f => f.AssetClass,
                    opt => opt.MapFrom(mf => CheckAssetClass(mf.ASSET_CLASS, configuration)
                    ))
                .ReverseMap();


            CreateMap<MFAPI_GET_SETTLEMENT_DATEModel, SettlementDateByCustomerResultContract>()
                .ForMember(
                    f => f.Amount,
                    opt => opt.MapFrom(mf => ConvertToDecimal(mf.AMOUNT.ToString(CultureInfo.InvariantCulture), 2)))
                .ForMember(
                    f => f.Fund,
                    opt => opt.MapFrom(mf => mf.FUNDNAME))
                .ForMember(
                    f => f.Status,
                    opt => opt.MapFrom(mf =>
                        string.IsNullOrEmpty(mf.STATUSCODE) ||
                        string.IsNullOrEmpty(configuration[$"STATUSCODEEN:CODE{mf.STATUSCODE}"])
                            ? "-"
                            : configuration[$"STATUSCODEEN:CODE{mf.STATUSCODE}"]
                    ))
                .ForMember(
                    f => f.FullRedemption,
                    opt => opt.MapFrom(mf => string.IsNullOrEmpty(mf.FULLREDEMTION) ? "-" : mf.FULLREDEMTION))
                .ForMember(
                    f => f.PortfolioNumber,
                    opt => opt.MapFrom(mf => mf.PORTFOLIOCODE))
                .ForMember(
                    f => f.SettlementDate,
                    opt => opt.MapFrom(mf =>
                        string.IsNullOrEmpty(mf.SETTLEMENT_DATE)
                            ? "-"
                            : DateTime.Parse(mf.SETTLEMENT_DATE).ToString("dd-MMM-yyyy")
                    ))
                .ForMember(
                    f => f.TransactionDate,
                    opt => opt.MapFrom(mf =>
                        string.IsNullOrEmpty(mf.TRANSACTIONDATE)
                            ? "-"
                            : DateTime.Parse(mf.TRANSACTIONDATE).ToString("dd-MMM-yyyy")
                    ))
                .ReverseMap();


            CreateMap<MFAPI_GET_SETTLEMENT_DATE_PTModel, SettlementDateByCalendarPTResultContract>()
                .ForMember(
                    f => f.Seq,
                    opt => opt.MapFrom(mf => mf.SEQ
                    ))
                .ForMember(
                    f => f.SettlementDate,
                    opt => opt.MapFrom(mf =>
                        string.IsNullOrEmpty(mf.SETTLEMENT_DATE)
                            ? "-"
                            : DateTime.Parse(mf.SETTLEMENT_DATE).ToString("dd-MMM-yyyy")
                    ))
                .ForMember(
                    f => f.RedemptionDate,
                    opt => opt.MapFrom(mf =>
                        string.IsNullOrEmpty(mf.RED_DATE) ? "-" : DateTime.Parse(mf.RED_DATE).ToString("dd-MMM-yyyy")
                    ))
                .ReverseMap();


            CreateMap<Log, LogExportContract>()
                .ForMember(
                    f => f.UserId,
                    opt => opt.MapFrom(mf => mf.userid))
                .ForMember(
                    f => f.Created,
                    opt => opt.MapFrom(mf => mf.created))
                .ForMember(
                    f => f.LogType,
                    opt => opt.MapFrom(mf => mf.logType.ToString()))
                .AfterMap((source, destination) =>
                {
                    if (source.logType == MFEnums.LogType.AdministrationActivityAuditLog)
                    {
                        var deserMessage =
                            JsonConvert.DeserializeObject<AdministrationActivityAuditLog>(source.message);
                        if (deserMessage.Activity == MFEnums.ActivityType.Link)
                        { 
                            return;
                        }

                        destination.FeatureCode = deserMessage.FeatureCode;
                        destination.RoleCode = deserMessage.RoleCode;
                        destination.Activity = deserMessage.Activity.ToString();

                        if (string.IsNullOrEmpty(destination.UserId))
                        {
                            destination.UserId = deserMessage.UserId;
                        }
                    }

                    if (source.logType == MFEnums.LogType.AccessActivity)
                    {
                        destination.Activity = source.message;
                    }
                })
                .ReverseMap();
        }

        public static string ConvertToDecimal(string value, int decimalPlaces)
        {
            string result = "-";
            if (double.TryParse(value, out var parseValue))
            {
                if (Math.Abs(parseValue) > 0)
                {
                    result = string.Format(new NumberFormatInfo() {NumberDecimalDigits = decimalPlaces}, "{0:n}",
                        new decimal(parseValue));
                }
                else
                {
                    result = "0";
                }
            }

            return result;
        }

        private static string CheckAssetClass(string assetClass, IConfiguration configuration)
        {
            var assetClassKey = assetClass.Replace("_", "").Replace(" ", string.Empty);
            var assetClassMapped =
                configuration[$"ASSETCLASS:{assetClassKey}:NAMETH"];
            return string.IsNullOrEmpty(assetClass) || string.IsNullOrEmpty(assetClassMapped) ? "-" : assetClassMapped;
        }
    }
}