using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.ETE;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace mf_service.SharedService.Requester
{
    public class RequesterService
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly IOptions<List<APIConfigContract>> _config;
        private readonly IConfiguration _configuration;
        private readonly IMFLoggerService _logger;

        public RequesterService(
            IMFLoggerService logger,
            IConfiguration configuration,
            IOptions<List<APIConfigContract>> config,
            IHttpClientFactory clientFactory)
        {
            _logger = logger;
            _clientFactory = clientFactory;
            _config = config;
            _configuration = configuration;
        }

        public async Task<PandaResults<TResponse>> Request<TRequest, TResponse>(
            string endPointName,
            TRequest queryBody,
            string queryParams = null)
            where TRequest : class
            where TResponse : class
        {
            var errorMessage = "";
            try
            {
                errorMessage = " Error while request data ";
                var jsonResult = await Request<TRequest>(endPointName, queryBody, queryParams);
                errorMessage = " Error while DeserializeObject ";


                var result = JsonConvert.DeserializeObject<TResponse>(jsonResult);
                _logger.LogInfo($" RESPONSE: {endPointName} ", jsonResult, typeof(RequesterService).Name);
                return PandaResponse.CreateSuccessResponse(result);
            }
            catch (Exception e)
            {
                _logger.LogInfo($" REQUEST ERROR: {endPointName} ", errorMessage + "  " + e.ToString(),
                    typeof(RequesterService).Name);
                return PandaResponse.CreateErrorResponse<TResponse>(errorMessage, e);
            }
        }

        public async Task<string> Request<TBody>(string endpointName, TBody body, string queryParams = null)
            where TBody : class
        {
            var errorMessage = "";
            try
            {
                var endpointObject = BuildEndPoint(endpointName);
                var jsonContent = JsonConvert.SerializeObject(body, Formatting.None).Replace(Environment.NewLine, " ");
                jsonContent = Regex.Replace(jsonContent, "(\"(?:[^\"\\\\]|\\\\.)*\")|\\s+", "$1");
                var content = new StringContent(jsonContent, Encoding.UTF8,
                    "application/json");

                var headerValueLog = " HEADER: ";
                var isHeaderConcrete = endpointObject.GatewayHeaders != null && endpointObject.GatewayHeaders.Any();
                if (isHeaderConcrete)
                {
                    endpointObject.GatewayHeaders.ForEach(f =>
                    {
                        var headerValue = f.Value;
                        if (f.Name.Equals("request-uid"))
                        {
                            headerValue = Guid.NewGuid().ToString();
                        }

                        //"7d8277e0-b5cc-41b2-8dc8-9e06d763a713"
                        if (f.Name.Equals("request-datetime"))
                        {
                            headerValue = DateTime.Now.ToLocalTime().ToString("yyyy-MM-ddTHH:mm:ss");
                        }

                        //"2018-10-22T10:23:14"
                        if (f.Name.Equals("MFUUID"))
                        {
                            headerValue = _logger.GetLogDesc().Uuid;
                        }

                        if (f.Name.Equals("MFUSERID"))
                        {
                            headerValue = _logger.GetLogDesc().UserId;
                        }

                        headerValueLog += $" {f.Name}:{headerValue} ";
                        content.Headers.Add(f.Name, headerValue);
                    });
                }

                var clientHandler = new HttpClientHandler
                {
                    ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
                };

                errorMessage = " Error while PostAsync ";
                var client = new HttpClient(clientHandler);
                client.Timeout = TimeSpan.FromMinutes(10);
                var requestTime = DateTime.Now.ToLocalTime();
                if (endpointObject.Url.Contains("ldap"))
                {
                    jsonContent = "";
                }

                _logger.LogInfo(" REQUEST API ",
                    " REQUEST URL: " + endpointObject.Url + queryParams + headerValueLog + " REQUEST " +
                    jsonContent + " ",
                    typeof(RequesterService).Name);
                var postBypass = await client.PostAsync(endpointObject.Url + queryParams, content);
                var responseTime = DateTime.Now.ToLocalTime() - requestTime;

                _logger.LogInfo(" RESPONSE ",
                    " RESPONSE URL: " + endpointObject.Url + queryParams + " STATUS RESPONSE " +
                    postBypass.StatusCode + $" RESPONSE TIME (s): {responseTime.TotalSeconds} ",
                    typeof(RequesterService).Name);
                errorMessage = " Error while ReadAsStringAsync ";
                var result = await postBypass.Content.ReadAsStringAsync();
                result = result.Replace(Environment.NewLine, " "); 
                result = Regex.Replace(result, "(\"(?:[^\"\\\\]|\\\\.)*\")|\\s+", "$1");
                return result;
            }
            catch (Exception e)
            {
                _logger.LogInfo(" ERROR REQUEST: ", errorMessage + " " + e.Message, typeof(RequesterService).Name);
                throw new Exception(errorMessage, e);
            }
        }

        private APIConfigContract BuildEndPoint(string endpointName)
        {
            return _config.Value.FirstOrDefault(w => w.Name == endpointName);
        }
    }
}