using System.Security.Claims;
using System.Threading.Tasks;
using mf_service.LDAP.Contract;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace mf_service.SharedService.Middlewares
{
    public class AuthenticationMiddlewareCustom
    {
        private readonly RequestDelegate _next;
        private readonly IJwtTokenService _jwtTokenService;
        private readonly IConfiguration _configuration;
        // Dependency Injection
        public AuthenticationMiddlewareCustom(
            RequestDelegate next,
            IJwtTokenService jwtTokenService,
            IConfiguration configuration
        )
        {
            _next = next;
            _jwtTokenService = jwtTokenService;
            _configuration = configuration;
        }

        public async Task Invoke(HttpContext context)
        {
            string authHeader = context.Request.Headers["Authorization"];

            ClaimsPrincipal pcp = null;
            if (!string.IsNullOrEmpty(authHeader) && authHeader.Contains("Bearer"))
            {
                authHeader = authHeader.Replace("Bearer ", "");
                pcp = _jwtTokenService.GetPrincipalFromToken(authHeader, "JWT:Audience");
                if (pcp == null)
                {
                    context.Response.StatusCode = 500;
                    var errObj = new LDAPErrorResponseContract()
                    {
                        error = "Token Invalid"
                    };
                    await context.Response.WriteAsync(JsonConvert.SerializeObject(errObj));
                    return;
                }
            }

            await _next(context);
        }


    }
}