using mf_service.SharedService.Middlewares;
using Microsoft.Extensions.Logging;

namespace mf_service.SharedService.SystemService.Interface
{
    public interface IMFLoggerService
    {
        void LogInfo(string key, string value, string className, LogLevel logLevel = LogLevel.Information);
        void LogObj(string key, object obj, string className, LogLevel logLevel = LogLevel.Information);
        void SetLogDesc(LogDesc logDesc);
        LogDesc GetLogDesc();
    }
}