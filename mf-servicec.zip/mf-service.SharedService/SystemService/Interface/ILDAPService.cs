﻿using System;
using System.Threading.Tasks;
using mf_service.LDAP.Contract;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.MF.Search;
using Microsoft.AspNetCore.Mvc;

namespace mf_service.SharedService.SystemService.Interface
{
    public interface ILDAPService
    {
        PandaResults<LDAPLoginResponseContract> Login(LoginContract loginContract);

        PandaResults<Tuple<LDAPLoginResponseContract, string>> RefreshToken(RefreshTokenContract token);
    }
}