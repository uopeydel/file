﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using mf_service.LDAP.Contract;

namespace mf_service.SharedService.SystemService.Interface
{
    public interface IJwtTokenService
    {
        Tuple<IEnumerable<Claim>, LDAPLoginResponseContract> BuildClaims(LDAPLoginResponseContract account);
        LDAPLoginResponseContract GenerateToken(IEnumerable<Claim> claims, LDAPLoginResponseContract account);
        ClaimsPrincipal GetPrincipalFromToken(string token, string audience = "JWT:Audience");
        string GetValueFromClaimType(ClaimsPrincipal principal, string claimType = JwtRegisteredClaimNames.NameId);
        LDAPLoginResponseContract ClaimToLoginResponse(ClaimsPrincipal principal);
    }
}
