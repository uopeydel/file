﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using mf_service.LDAP.Contract;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace mf_service.SharedService.SystemService.Implement
{
    public class JwtTokenServiceImpl : IJwtTokenService
    {
        private readonly IConfiguration _configuration;

        public JwtTokenServiceImpl(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        //1 After loged in send data to build claims
        public Tuple<IEnumerable<Claim>, LDAPLoginResponseContract> BuildClaims(LDAPLoginResponseContract account)
        {
            account.jti = Guid.NewGuid().ToString();
            try
            {
                var claims = new List<Claim>
                {
                    new Claim(JwtRegisteredClaimNames.NameId, account.userId),
                    new Claim(JwtRegisteredClaimNames.Jti, account.jti),
                };

                Action<string, string> add = (typeVar, valueVar) =>
                {
                    if (!String.IsNullOrEmpty(valueVar))
                    {
                        claims.Add(new Claim(type: typeVar, value: valueVar));
                    }
                };
                add("authority", account.authority);
                add("authority", account.authority);
                add("branchCode", account.branchCode);
                add("branchTh", account.branchTh);
                add("channel", account.channel);
                add("fullName", account.fullName);
                add("fullNameTh", account.fullNameTh);
                add("lastLogOn", account.lastLogOn);
                add("roleCode", account.roleCode);
                add("roleEn", account.roleEn);
                add("roleTh", account.roleTh);
                add("scope", account.scope);
                add("sex", account.sex);
                add("tellerId", account.tellerId);

                return Tuple.Create(claims.AsEnumerable(), account);
            }
            catch
            {
                return null;
            }
        }

        //2  generate token and refresh 
        public LDAPLoginResponseContract GenerateToken(IEnumerable<Claim> claims, LDAPLoginResponseContract account)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Key"]));
            var credential = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            #region access token

            var expiredAt = int.Parse(_configuration["JWT:ExpiredAt"]);
            var expiredTokenDate = DateTime.Now.AddMinutes(expiredAt); 
            account.expires_in = expiredAt;

            var token = new JwtSecurityToken(
                _configuration["JWT:Issuer"],
                _configuration["JWT:Audience"],
                claims,
                expires: expiredTokenDate,
                signingCredentials: credential);
            var tokenGenerated = new JwtSecurityTokenHandler().WriteToken(token);
            account.access_token = tokenGenerated;

            #endregion

            Console.WriteLine("expiredAt " + expiredTokenDate.ToString("O"));

            Console.WriteLine("expiredAt " + expiredTokenDate.ToLocalTime().ToString("O"));

            #region refresh token

            var refreshTokenExpiredAt = int.Parse(_configuration["JWT:RefreshTokenExpiredAt"]);
            var expiredRefreshTokenDate = DateTime.Now.AddMinutes(refreshTokenExpiredAt);
            account.refresh_expires_in = expiredRefreshTokenDate.ToString();
            var refreshToken = new JwtSecurityToken(
                _configuration["JWT:Issuer"],
                _configuration["JWT:RefreshTokenAudience"],
                claims,
                expires: expiredRefreshTokenDate,
                signingCredentials: credential);
            var refreshTokenGenerated = new JwtSecurityTokenHandler().WriteToken(refreshToken);
            account.refresh_token = refreshTokenGenerated;

            #endregion

            account.token_type = "Bearer";
            account.lastLogOn = DateTime.Now.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss.fff zzz");

            return account;
        }

        public ClaimsPrincipal GetPrincipalFromToken(string token, string audience = "JWT:Audience")
        {
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = false,
                ValidateIssuerSigningKey = true,
                ValidIssuer = _configuration["JWT:Issuer"],
                ValidAudience = _configuration[audience],
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Key"])),
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                var principal =
                    tokenHandler.ValidateToken(token, tokenValidationParameters, out SecurityToken securityToken);
                JwtSecurityToken jwtSecurityToken = securityToken as JwtSecurityToken;
                if (jwtSecurityToken == null || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256,
                        StringComparison.InvariantCultureIgnoreCase))
                {
                    return null;
                }

                return principal;
            }
            catch
            {
                return null;
            }
        }

        public string GetValueFromClaimType(ClaimsPrincipal principal,
            string claimType = JwtRegisteredClaimNames.NameId)
        {
            var value = principal.Claims.Where(w => w.Type.Contains(claimType))
                .Select(s => s.Value).FirstOrDefault();
            return value;
        }

        public LDAPLoginResponseContract ClaimToLoginResponse(ClaimsPrincipal principal)
        {
            LDAPLoginResponseContract account = new LDAPLoginResponseContract();
            account.jti = GetValueFromClaimType(principal, JwtRegisteredClaimNames.Jti);
            account.userId = GetValueFromClaimType(principal, JwtRegisteredClaimNames.NameId);
            account.authority = GetValueFromClaimType(principal, "authority");
            account.branchCode = GetValueFromClaimType(principal, "branchCode");
            account.branchTh = GetValueFromClaimType(principal, "branchTh");
            account.channel = GetValueFromClaimType(principal, "channel");
            account.fullName = GetValueFromClaimType(principal, "fullName");
            account.fullNameTh = GetValueFromClaimType(principal, "fullNameTh");
            account.lastLogOn = GetValueFromClaimType(principal, "lastLogOn");
            account.roleCode = GetValueFromClaimType(principal, "roleCode");
            account.roleEn = GetValueFromClaimType(principal, "roleEn");
            account.roleTh = GetValueFromClaimType(principal, "roleTh");
            account.scope = GetValueFromClaimType(principal, "scope");
            account.sex = GetValueFromClaimType(principal, "sex");
            account.tellerId = GetValueFromClaimType(principal, "tellerId");
            return account;
        }
    }
}