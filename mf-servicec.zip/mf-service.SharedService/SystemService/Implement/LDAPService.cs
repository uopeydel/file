﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using mf_service.LDAP.Contract;
using mf_service.LDAP.Repository.Interface;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace mf_service.SharedService.SystemService.Implement
{
    public class LdapServiceImpl : ILDAPService
    {
        private readonly IConfiguration _configuration;
        private readonly ILDAPRepository _ldapRepository;
        private readonly IJwtTokenService _jwtTokenService;

        public LdapServiceImpl(
            IConfiguration configuration,
            ILDAPRepository ldapRepository,
            IJwtTokenService jwtTokenService
        )
        {
            _configuration = configuration;
            _ldapRepository = ldapRepository;
            _jwtTokenService = jwtTokenService;
        }

        public PandaResults<LDAPLoginResponseContract> Login(LoginContract loginContract)
        {
            var host = _configuration["LDAPConnection:Host"];
            var baseConnector = _configuration["LDAPConnection:BaseConnector"];
            var usernameSuffix = _configuration["LDAPConnection:UsernameSuffix"];
            var (result,error) = _ldapRepository.Requester(
                host: host,
                baseConnector: baseConnector,
                usernameSuffix: usernameSuffix,
                userName: loginContract.UserName,
                password: loginContract.Password
            );

            if (result != null)
            {
                (IEnumerable<Claim> claims, LDAPLoginResponseContract loginResponse) =
                    _jwtTokenService.BuildClaims(result);
                var refreshTokenResult = _jwtTokenService.GenerateToken(claims, loginResponse);
                if (refreshTokenResult == null)
                {
                    return PandaResponse.CreateErrorResponse<LDAPLoginResponseContract>(
                        $"Error while generate token for {loginContract.UserName}");
                }

                return PandaResponse.CreateSuccessResponse(refreshTokenResult);
            }
            else
            {
                return PandaResponse.CreateErrorResponse<LDAPLoginResponseContract>(error);
            }
        }


        public PandaResults<Tuple<LDAPLoginResponseContract, string>> RefreshToken(RefreshTokenContract token)
        {
            var accessTokenClaim = _jwtTokenService.GetPrincipalFromToken(token.Token, "JWT:Audience");
            //todo check refresh token in database
            var refreshTokenClaim =
                _jwtTokenService.GetPrincipalFromToken(token.RefreshToken, "JWT:RefreshTokenAudience");
            if (accessTokenClaim == null || refreshTokenClaim == null)
            {
                return PandaResponse.CreateErrorResponse<Tuple<LDAPLoginResponseContract, string>>(
                    "Invalid refresh token");
            }

            var loginResponse = _jwtTokenService.ClaimToLoginResponse(accessTokenClaim);
            var refreshResponse = _jwtTokenService.ClaimToLoginResponse(refreshTokenClaim);
            var isUserIdEqual = loginResponse.userId == refreshResponse.userId;
            var isRefreshExpiredEqual = loginResponse.jti == refreshResponse.jti;
            if (!isRefreshExpiredEqual || !isUserIdEqual)
            {
                return PandaResponse
                    .CreateErrorResponse<Tuple<LDAPLoginResponseContract, string>>("Invalid token data");
            }

            var refreshTokenResult = _jwtTokenService.GenerateToken(accessTokenClaim.Claims, loginResponse);
            return PandaResponse.CreateSuccessResponse(Tuple.Create(refreshTokenResult, loginResponse.userId));
        }
    }
}