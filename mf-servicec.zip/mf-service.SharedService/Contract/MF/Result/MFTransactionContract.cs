﻿using System;
using System.Globalization;
using System.Linq;

namespace mf_service.SharedService.Contract.MF.Result
{

    public class MFTransactionContract
    {
        public string AMOUNT { get; set; }

        public string AmountFormat
        {
            get
            {
                return !string.IsNullOrEmpty(AMOUNT) && double.TryParse(AMOUNT, out _)
                    ? string.Format("{0:n4}", double.Parse(AMOUNT)) : "";
            }
        }

        public string EFFECTIVEDATE { get; set; }
        public string DateEffective { get { return DateTime.Parse(EFFECTIVEDATE).ToString("dd-MMM-yyyy").ToUpper(); } }


        public string FUNDCODE { get; set; }
        public string FUNDNAMEEN { get; set; }
        public string FUNDNAMETH { get; set; }
        public string ORDERID { get; set; }
        public string ORDERSUBTYPECODE { get; set; }
        public string OrderSubTypeName
        {
            get
            {
                return string.IsNullOrEmpty(ORDERSUBTYPECODE) ? "" :
ORDERSUBTYPECODE.Equals("TMB_BUY_REG") ? "ซื้อ" :
ORDERSUBTYPECODE.Equals("TMB_BUY_SWI") ? "สับเปลี่ยนเข้า / Switch In" :
ORDERSUBTYPECODE.Equals("TMB_SELL_REG") ? "ขาย" :
ORDERSUBTYPECODE.Equals("TMB_SELL_SWO") ? "สับเปลี่ยนออก / Switch Out" :
ORDERSUBTYPECODE.Equals("TMB_TRF_POS_IN") ? "โอนเข้า / Transfer In" :
ORDERSUBTYPECODE.Equals("TMB_TRF_POS_OUT") ? "โอนออก / Transfer Out" :
"";

            }
        }

        public string ORDERTYPECODE { get; set; }
        public string PARENTORDERID { get; set; }
        public string PORTFOLIOCODE { get; set; }
        private string price;
        public string PRICE {
            get
            {
                return double.TryParse(this.price, out _) ? string.Format("{0:n4}", double.Parse(price)) : "";
            }
            set
            {
                price = value;
            }
        }
        public string STATUSCODE { get; set; }
        public string Status
        {
            get
            {
                return
                    STATUSCODE == "90" ? "ยืนยัน / Confirm" :
                    (new[] { "0", "21", "22" }).Contains(STATUSCODE) ? "ยกเลิกรายการ  / Cancel" :
                    (new[] { "35", "40" }).Contains(STATUSCODE) ? "รอจัดสรรค์ / Processing" : "";
            }
        }
        public string TRANSACTIONDATE { get; set; }
        public string DateTransaction { get { return DateTime.Parse(TRANSACTIONDATE).ToString("dd-MMM-yyyy").ToUpper(); } }
        public string UNIT { get; set; }
        public string UNIT4
        {
            get
            {
                return double.TryParse(this.UNIT, out _)
                    ? string.Format("{0:n4}", double.Parse(this.UNIT))
                    : "";
            }
        }

    }
}
