using System.Collections.Generic;

namespace mf_service.SharedService.Contract.MF.Result
{
    public class SettlementDateByCustomerResultContract
    { 
       public string PortfolioNumber { get; set; }
       public string TransactionDate { get; set; }
       public string Fund { get; set; }
       public string Amount { get; set; }
       public string FullRedemption { get; set; }
       public string Status { get; set; }
       public string SettlementDate { get; set; }
    }
}