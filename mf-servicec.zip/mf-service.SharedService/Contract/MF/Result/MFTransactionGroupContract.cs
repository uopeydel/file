﻿using System;
using System.Collections.Generic;

namespace mf_service.SharedService.Contract.MF.Result
{
    public class MFTransactionGroupContract
    {
        public List<MFTransactionHeaderContract> Headers { get; set; }
        public List<MFPortNoContract> Keys { get; set; }
        public List<MFTransactionContract> Values { get; set; }
    }
}
