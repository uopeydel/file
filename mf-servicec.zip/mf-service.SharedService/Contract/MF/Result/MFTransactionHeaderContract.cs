﻿using System;
using System.Collections.Generic;

namespace mf_service.SharedService.Contract.MF.Result
{
    public class MFTransactionHeaderContract
    {
        public List<string> FullNames { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }
}
