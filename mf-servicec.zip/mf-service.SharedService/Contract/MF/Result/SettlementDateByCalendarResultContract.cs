using System.Collections.Generic;

namespace mf_service.SharedService.Contract.MF.Result
{
    public class SettlementDateByCalendarPTResultContract
    {
        public string Seq { get; set; }
        public string RedemptionDate { get; set; }
        public string SettlementDate { get; set; } 
    }
    
    public class SettlementDateByCalendarTSPResultContract
    {
        public string RedemptionDate { get; set; }
        public List<ModelSettlementDate> Details{ get; set; } 
    }

    public class ModelSettlementDate
    {
        public string Model { get; set; }
        public string SettlementDate { get; set; }
    }
}