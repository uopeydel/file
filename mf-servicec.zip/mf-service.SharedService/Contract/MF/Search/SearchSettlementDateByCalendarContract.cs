using mf_service.SharedService.Contract.Enums;

namespace mf_service.SharedService.Contract.MF.Search
{
    public class SearchSettlementDateByCalendarContract
    {
        public MFEnums.PortfolioType SearchBy { get; set; }
        public string SearchValue { get; set; }
        public string Year { get; set; }
        public string  Month { get; set; }
    }
}