﻿using System;
namespace mf_service.SharedService.Contract.MF.Search
{
    public class LoginContract
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
