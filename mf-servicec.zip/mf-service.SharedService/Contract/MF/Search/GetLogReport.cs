﻿using System;
using System.Collections.Generic;
using System.Text;

namespace mf_service.SharedService.Contract.MF.Search
{
    public class GetLogReport
    {
        public string dateFile { get; set; }
    }
}
