﻿using System;
namespace mf_service.SharedService.Contract.MF.Search
{
    public class SearchPartialPortNoContract
    {
        public string PORTFOLIONO { get; set; }
    }
}
