﻿using System;
using System.Collections.Generic; 
using mf_service.SharedService.Contract.MF.Result;

namespace mf_service.SharedService.Contract.MF.Search
{
    public class GetTransactionContract
    {
        public string PortfolioNo { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }

    public class GenPDFPortContract
    {
        public List<string> PortfolioList { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; } 
    }

    public class GenPDFPortV2Contract
    {
        public List<MFPortNoContract> PortfolioList { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }

    }

}
