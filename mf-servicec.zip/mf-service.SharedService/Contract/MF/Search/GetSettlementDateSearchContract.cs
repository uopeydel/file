using System.Collections.Generic;

namespace mf_service.SharedService.Contract.MF.Search
{
    public class GetSettlementDateSearchContract
    {
        public List<string> portFolioNo { get; set; }
        public string fundName { get; set; }
        public string asOfDate { get; set; }
    }
}