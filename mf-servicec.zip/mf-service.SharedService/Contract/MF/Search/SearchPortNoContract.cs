﻿using System; 
using mf_service.SharedService.Contract.Enums;

namespace mf_service.SharedService.Contract.MF.Search
{
    public class SearchPortNoContract
    {
        public MFEnums.SearchPortEnums SearchBy { get; set; }
        public string SearchValue { get; set; }
    }
}
