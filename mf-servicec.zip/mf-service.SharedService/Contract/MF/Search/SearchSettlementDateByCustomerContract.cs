using System.Collections.Generic;
using mf_service.SharedService.Contract.Enums;

namespace mf_service.SharedService.Contract.MF.Search
{
    public class SearchSettlementDateByCustomerContract
    {
        public MFEnums.SettlementDate SearchBy { get; set; }
        public List<string> SearchValue { get; set; } 
    }
}