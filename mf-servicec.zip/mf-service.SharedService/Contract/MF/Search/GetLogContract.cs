using System;
using mf_service.SharedService.Contract.Enums;

namespace mf_service.SharedService.Contract.MF.Search
{
    public class GetLogContract
    {
        public string userid { get; set; } 
        public MFEnums.LogType? logType { get; set; }
        public DateTime? from { get; set; }
        public DateTime? to { get; set; }
    }
}