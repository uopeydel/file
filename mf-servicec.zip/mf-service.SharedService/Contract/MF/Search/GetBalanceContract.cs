﻿using System;
namespace mf_service.SharedService.Contract.MF.Search
{
    public class GetBalanceContract
    {
        public string PORTFOLIONO { get; set; }
        public string FROMDATE { get; set; }
    }
}
