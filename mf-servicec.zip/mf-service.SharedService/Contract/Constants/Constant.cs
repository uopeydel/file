using System.Collections.Generic;

namespace mf_service.SharedService.Contract.Constants
{
    public static class Constant
    {
        //public static string AesVi = "ZFoF65qHe8FBYXRDK5odFA==";
        public static string AesIV = "ZFoF65qHe8FBYXRD";
        public static string AesKey = "W1/IKtopDXk8+J3NFUFcyfJk9EJmnz/8";
        //public static string AesKey = "W1/IKtopDXk8+J3NFUFcyfJk9EJmnz/8";

        #region ORDERSUBTYPECODE REPORT 06

        public static readonly List<string> buy = new List<string> { "TMB_BUY_REG", "TMB_BUY_AUTO", "TMB_BUY_AIP", "TMB_BUY_IPO" };
        public static readonly List<string> swiInSwiOut = new List<string> { "TMB_BUY_SWI", "TMB_BUY_AIP_SWI", "TMB_SELL_SWO", "TMB_SELL_AIP_SWO" };
        public static readonly List<string> sell = new List<string> { "TMB_SELL_REG", "TMB_SELL_AUTO", "TMB_SELL_AIP" };
        public static readonly List<string> tranInTranOut = new List<string> { "TMB_TRF_INI_LOAD", "TMB_TRF_POS_IN", "TMB_TRF_POS_OUT" };
        public static readonly List<string> dividend = new List<string> { "TMB_DIVIDEND", "TMB_DIVIDEND_CASH" };

        #endregion


        #region ORDERSUBTYPECODE REPORT 03

        public static readonly List<string> sellRedemption = new List<string> { "TMB_ROBO_SELL_REDEMPTION" };
        public static readonly List<string> buyInjecttion = new List<string> { "TMB_ROBO_BUY_CASH_INJECTION" };
        public static readonly List<string> cashInjecttionRedemption = new List<string>
        {
            "TMB_ROBO_FULL_REDEMPTION", "TMB_ROBO_PARTIAL_REDEMPTION","TMB_ROBO_CASH_INJECTION"
        };

        #endregion


        #region Rebalancing Report 04

        public static readonly List<string> buyRebalancing = new List<string> { "TMB_ROBO_BUY_REBAL" };
        public static readonly List<string> sellRebalancing = new List<string> { "TMB_ROBO_SELL_REBAL" };
        public static readonly List<string> mgmtFee = new List<string> { "TMB_ROBO_FEE_MGMT" };
        
        #endregion

        #region Fund Code  Report 07

        /*public static readonly List<string> ltf = new List<string> { "LTF" };
        public static readonly List<string> rmf = new List<string> { "RMF" }; */
        
        #endregion

        #region sum By Investment Type  Report 01

        public static readonly string sum = "sum";
        public static readonly string sumRegularMutualFund = "sumRegularMutualFund";
        public static readonly string sumMutualFund = "sumMutualFund";
        public static readonly string sumSmartPort = "sumSmartPort";
        
        #endregion

        public static readonly string[] rejectStatusCode = new string[] {"0", "21", "22"};
    }
}