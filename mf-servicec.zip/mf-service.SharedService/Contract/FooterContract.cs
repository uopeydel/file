﻿using System;
namespace mf_service.SharedService.Contract
{
    public class FooterContract
    {
        public int PageNumber { get; set; }
        public int PageNumberAmount { get; set; }

    }
}
