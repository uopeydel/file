using System;

namespace mf_service.SharedService.Contract.UserManagement.Result
{
    public class RoleContract
    {
        public long id { get; set; }
        public string name { get; set; }
        public string code { get; set; }
        public string type { get; set; }
        public bool isActive { get; set; }
        public DateTime created { get; set; }
        public DateTime modified { get; set; }
    }
}