using System.Collections.Generic;

namespace mf_service.SharedService.Contract.UserManagement.Result
{
    public class RoleFeaturesContract
    {
        public long id { get; set; }
        public List<CodeNameContract> features { get; set; }
        public string name { get; set; }
        public string code { get; set; }
        public bool isActive { get; set; }
    }

    public class CodeNameContract
    {
        public string name { get; set; }
        public string code { get; set; }
    }
}