using System.Collections.Generic;
using mf_service.SharedService.Contract.UserManagement.Result;

namespace mf_service.SharedService.Contract.UserManagement.Body
{
    public class RoleCreateContract
    {
        public string roleCode { get; set; }
        public string newRoleCode { get; set; } 
        public List<CodeNameContract> feature { get; set; } 
        public bool roleStatus { get; set; }
    }
}