using mf_service.SharedService.Contract.Enums;

namespace mf_service.SharedService.Contract.UserManagement
{
    public class AdministrationActivityAuditLog
    {
        public string UserId { get; set; }
        public MFEnums.ActivityType Activity { get; set; } 
        public string RoleCode { get; set; }
        public string FeatureCode { get; set; }
    }
}