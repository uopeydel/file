﻿using System;
namespace mf_service.SharedService.Contract.Report.Result
{
    public class MFAPI_SEARCHPORTNOModel
    {
        
    }
}
