﻿using System;
using System.Globalization;
using System.Linq;
using mf_service.SharedService.Mapper;

namespace mf_service.SharedService.Contract.Report.Result
{
    public class MFAPI_GET_LTF_RMF_BALContract
    {
        public string PORTFOLIO { get; set; }
        public string FUND_CODE { get; set; }
        public string FUND_TYPE { get; set; }
        public string FUND_NAME_TH { get; set; }
        public string INVESTMENT_YEAR { get; set; }

        public string MATURITY_YEAR
        {
            get
            {
                var muturityYear = 0;
                var isYear = int.TryParse(INVESTMENT_YEAR, out muturityYear);
                if (isYear)
                {
                    if (muturityYear < 2016)
                    {
                        muturityYear = muturityYear + 5 - 1;
                    }
                    else //If( INVESTMENT_YEAR >= 2016 )

                    {
                        muturityYear = muturityYear + 7 - 1;
                    }
                }

                return muturityYear.ToString();
            }
        }

        public string UNIT { get; set; }
        public string MARKET_PRICE { get; set; }
        
        
        public string AVG_PRICE { get; set; }

        
        public string AVG_COST { get; set; }
        /*public string AverageCost
        {
            get
            {
                decimal unitDecimal = decimal.Zero;
                var unitIsDecimal = !string.IsNullOrEmpty(UNIT) && decimal.TryParse(UNIT, out unitDecimal);

                decimal averagePriceDecimal = decimal.Zero;
                var averagePriceIsDecimal = !string.IsNullOrEmpty(AVG_PRICE) &&
                                            decimal.TryParse(AVG_PRICE, out averagePriceDecimal);


                if (unitIsDecimal && averagePriceIsDecimal)
                {
                    var result = MappingProfile.ConvertToDecimal(
                        (unitDecimal * averagePriceDecimal).ToString(CultureInfo.InvariantCulture), 2);
                    return result;
                }

                return "0.00";
            }
        }*/
        
        
        public string INVESTMENT_VALUE { get; set; }
        /*public string InvestmentValue
        {
            get
            {
                decimal unitDecimal = decimal.Zero;
                var unitIsDecimal = !string.IsNullOrEmpty(UNIT) && decimal.TryParse(UNIT, out unitDecimal);

                decimal marketPriceDecimal = decimal.Zero;
                var averagePriceIsDecimal = !string.IsNullOrEmpty(MARKET_PRICE) &&
                                            decimal.TryParse(MARKET_PRICE, out marketPriceDecimal);

                if (unitIsDecimal && averagePriceIsDecimal)
                {
                    var result = MappingProfile.ConvertToDecimal(
                        (unitDecimal * marketPriceDecimal).ToString(CultureInfo.InvariantCulture), 2);

                    return result;
                }

                return "0.00";
            }
        }*/

        public string GainLossAmount
        {
            get
            {
                decimal investmentValueDecimal = decimal.Zero;
                var investmentValueIsDecimal = !string.IsNullOrEmpty(INVESTMENT_VALUE) &&
                                               decimal.TryParse(INVESTMENT_VALUE, out investmentValueDecimal);


                decimal averageCostDecimal = decimal.Zero;
                var averageCostIsDecimal = !string.IsNullOrEmpty(AVG_COST) &&
                                           decimal.TryParse(AVG_COST, out averageCostDecimal);


                if (investmentValueIsDecimal && averageCostIsDecimal)
                {
                    var result = MappingProfile.ConvertToDecimal(
                        (investmentValueDecimal - averageCostDecimal).ToString(CultureInfo.InvariantCulture), 2);
                    return result;
                }

                return "0.00";
            }
        }


        public string GainLossPercent
        {
            get
            {
                decimal gainLossAmountDecimal = decimal.Zero;
                var gainLossAmountIsDecimal = !string.IsNullOrEmpty(GainLossAmount) &&
                                              decimal.TryParse(GainLossAmount, out gainLossAmountDecimal);
                gainLossAmountIsDecimal = gainLossAmountIsDecimal && gainLossAmountDecimal != decimal.Zero;

                decimal averageCostDecimal = decimal.Zero;
                var averageCostIsDecimal = !string.IsNullOrEmpty(AVG_COST) &&
                                           decimal.TryParse(AVG_COST, out averageCostDecimal);
                averageCostIsDecimal = averageCostIsDecimal && averageCostDecimal != decimal.Zero;

                if (gainLossAmountIsDecimal && averageCostIsDecimal)
                {
                    var result = MappingProfile.ConvertToDecimal(
                        ((gainLossAmountDecimal * 100) / averageCostDecimal).ToString(CultureInfo.InvariantCulture), 2);
                    return result;
                }

                return "0.00";
            }
        }
    }
}