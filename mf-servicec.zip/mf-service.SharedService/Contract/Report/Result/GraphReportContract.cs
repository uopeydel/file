using System.Collections.Generic;

namespace mf_service.SharedService.Contract.Report.Result
{
    public class GraphReportContract
    {
        public List<List<MFAPI_GET_BALANCEContract>> Values { get; set; }

        public List<GraphBodyContract> Graphs { get; set; }
    }

    public class GraphBodyContract
    {
        public string Label { get; set; }
        public decimal Value { get; set; }
        public string Color { get; set; }
        public string NameTh { get; set; }
        public string NameEn { get; set; }
        public int Order { get; set; }
        public decimal Percent { get; set; }
        public string Percen { get; set; }
    }
}