﻿using System;
using System.Globalization;
using System.Runtime.Serialization;
using System.Xml.Schema; 

namespace mf_service.SharedService.Contract.Report.Result
{
    public class MFAPI_GET_BALANCE_PDF_Contract
    {
        public string FUND_NAME { get; set; }
        public string AssetClass { get; set; } 
        public decimal AMOUNT { get; set; }
        public string ASSET_CLASS { get; set; } 
        public decimal GAIN_LOSS { get; set; }
        public decimal GAIN_LOSS_PER { get; set; }
        public decimal INVESTMENT_VAL { get; set; } 
        public DateTime NAV_DATE { get; set; }
        public decimal NAV_PER_UNIT { get; set; }
        public string PORTNAME { get; set; }
        public decimal UNIT { get; set; }
        public decimal WEIGHT { get; set; } 
    }
     
}
