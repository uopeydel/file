using System;

namespace mf_service.SharedService.Contract.Report.Result
{
    public class LogExportContract
    {
        public string UserId { get; set; }
        public DateTime Created { get; set; }
        public string LogType { get; set; }
        public string RoleCode { get; set; }
        public string FeatureCode { get; set; }
        public string Activity { get; set; }
    }
}