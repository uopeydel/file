using System.Collections.Generic;

namespace mf_service.SharedService.Contract.Report.Result
{
    public class GraphReportPDFContract
    {
        public List<List<MFAPI_GET_BALANCE_PDF_Contract>> Values { get; set; }

        public List<GraphBodyContract> Graphs { get; set; }
    }

    
}