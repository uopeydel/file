﻿using System;
using System.Collections.Generic;

namespace mf_service.SharedService.Contract.Report.Result
{
    public class PDFContract<TKey, TValue>
    {
        public PDFHeaderContract Headers { get; set; }
        public List<TKey> Keys { get; set; }
        public TValue Values { get; set; }
    }
}