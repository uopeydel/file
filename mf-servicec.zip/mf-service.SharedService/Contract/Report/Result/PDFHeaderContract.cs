﻿using System;
using System.Collections.Generic;

namespace mf_service.SharedService.Contract.Report.Result
{
    public class PDFHeaderContract
    {
        public List<string> FullNames { get; set; }
        public List<string> PortfolioCode { get; set; }


        public string FromDate { get; set; }

        public string DateFrom
        {
            get { return DateTime.ParseExact(FromDate, "yyyyMMdd", null).ToString("dd MMM yyyy").ToUpper(); }
        }

        public string ToDate { get; set; }

        public string DateTo
        {
            get
            {
                if (string.IsNullOrEmpty(ToDate))
                {
                    return null;
                }

                return DateTime.ParseExact(ToDate, "yyyyMMdd", null).ToString("dd MMM yyyy").ToUpper();
            }
        }

        public string RebalanceDate { get; set; }

        public string QuarterDate { get; set; }

        public string DateQuarter
        {
            get
            {
                if (string.IsNullOrEmpty(QuarterDate))
                {
                    return DateFrom;
                }

                return QuarterDate;
            }
        }

        public List<string> Addresses { get; set; }
    }
}