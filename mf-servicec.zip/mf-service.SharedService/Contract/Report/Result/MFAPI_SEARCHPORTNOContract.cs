﻿using System;
namespace mf_service.SharedService.Contract.Report.Result
{
    public class MFAPI_SEARCHPORTNOContract
    {
        public string ADVISORYTYPECODE { get; set; }
        public string INVESTMENTINLTF { get; set; }
        public string JOINTSTATUSCODE { get; set; }
        public string JOINTTYPECODE { get; set; }
        public string PORTFOLIOCODE { get; set; }
        public string RMID { get; set; }
        public string MAINRMID { get; set; }
    }
}
