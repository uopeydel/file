﻿using System;
using System.Collections.Generic;
using System.Linq;
using mf_service.SharedService.Contract.Report.Result;

namespace mf_service.SharedService.Contract.Report.Search
{
    public class PortfolioSearchContract
    {
        public List<MFAPI_SEARCHPORTNOContract> PortfolioList { get; set; }

        public string JoinPortList
        {
            get { return string.Join(",", PortfolioList.Select(s => s.PORTFOLIOCODE.Trim()).Distinct().ToArray()); }
        }

        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }
}