using System.Collections.Generic;

namespace mf_service.SharedService.Contract.ETE
{ 
    public class APIHeaderContract
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }

    public class APIConfigContract
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public List<APIHeaderContract> GatewayHeaders { get; set; }
    }
}