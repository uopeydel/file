using System.Collections.Generic;

namespace mf_service.SharedService.Contract.ETE
{
    public class GetCustomersContract
    {
        public List<GetCustomersSearchContract> query { get; set; }
    }

    public class GetCustomersSearchContract
    {
        public string customerId { get; set; }
    }
}