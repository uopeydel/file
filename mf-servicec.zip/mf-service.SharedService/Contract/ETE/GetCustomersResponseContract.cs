using System.Collections.Generic;

namespace mf_service.SharedService.Contract.ETE
{
    public class GetCustomersResponseContract
    {
        public List<ETECustomerContract> Customers { get; set; }
    }


    public class ETECustomerContract
    {
        public string CustomerId { get; set; }
        public string Type { get; set; }
        public ETECustomerProfileContract Profile { get; set; }
        public List<ETEAddress> Addresses { get; set; }
        public ETECompanyCustomerContract CompanyProfile { get; set; }
    }

    public class ETECompanyCustomerContract
    {
        public string CompanyName { get; set; }
        public string EnglishName { get; set; }
        public int NumberOfEmployees { get; set; }
    }


    public class ETECustomerProfileContract
    {
        public string nationality { get; set; }
        public string FullName { get; set; }
        public string EnglishFullName { get; set; }

        public string ShowName
        {
            get
            {
                if (string.IsNullOrEmpty(nationality))
                {
                    return !string.IsNullOrEmpty(FullName) ? FullName :
                        !string.IsNullOrEmpty(EnglishFullName) ? EnglishFullName : "";
                }
                else if (nationality.ToUpper().Equals("TH"))
                {
                    return FullName;
                }
                else
                {
                    return EnglishFullName;
                }
            }
        }
    }

    public class ETEAddress
    {
        public string type { get; set; }
        public string subType { get; set; }
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string address3 { get; set; }
        public string city { get; set; }
        public string country { get; set; }
        public string countryName { get; set; }
        public string postalCode { get; set; }
        public string addressIdent { get; set; }
    }
}