namespace mf_service.SharedService.Contract.Enums
{
    public static class MFEnums
    {
        public enum SearchPortEnums
        {
            CODE = 1,
            PORTNUM = 2,
            RMID = 3,
            TMB_CITIZEN_ID = 4,
            TMB_PASSPORT_NO = 5,
            TMB_COMPANY_REG_NO = 6,
            TMB_TAX_ID = 7,
            TMB_OTHERS_ID = 8,
            TMB_WORK_PERMIT = 9,
            TMB_ALIEN_IC = 10,
            TMB_GOVT_ID = 11,
            TMB_FIN_CODE = 12,
            TMB_SWIFT_CODE = 13,
            TMB_OVERSEA_JURISTIC = 14,
            TMB_TEMPORARY_CARD = 15,
        }

        public enum JointTypeCode
        {
            None = 0,
            Single = 10,
            Joint = 20,
            Or = 30,
        }

        public enum SettlementDate
        {
            Portfolio_Number = 1,
            /*Tax_ID =2,
            Others_ID=3,
            Work_Permit=4,
            Alien_Identity_Card=5,
            Government_ID=6,
            Financial_Institutio=7,
            Swift_Code=8,
            Oversea_Juristic_ID=9,
            Temporary_Card=10,
            Citizenship_ID=11,
            Passport=12,
            Register_ID=13,*/
        }

        public enum PortfolioType
        {
            TMBSmartPort = 1,
            RegularMutualFund = 2,
        }

        public enum LogType
        {
            API = 1,
            AdministrationActivityAuditLog = 2,
            AccessActivity = 3
        }

        public enum ActivityType
        {
            Add = 1,
            Change = 2,
            Link = 3,
            Active = 4,
            InActive = 5,
        }
    }
}