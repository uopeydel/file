﻿using System;
using mf_service.SharedService.MfLogProvider.Internal;

namespace mf_service.SharedService.MfLogProvider
{
    public class FileLoggerOptions : BatchingLoggerOptions
    {
        //private int? _fileSizeLimit = 10 * 1024 * 1024;
        private int? _retainedFileCountLimit = 2;
        private string _fileName = "logs-";
        private string _extension = "log";


        /*public int? FileSizeLimit
        {
            get { return _fileSizeLimit; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), $"{nameof(FileSizeLimit)} must be positive.");
                }

                _fileSizeLimit = value;
            }
        }*/

        public int? RetainedFileCountLimit
        {
            get { return _retainedFileCountLimit; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        $"{nameof(RetainedFileCountLimit)} must be positive.");
                }

                _retainedFileCountLimit = value;
            }
        }

        public string FileName
        {
            get { return _fileName; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException(nameof(value));
                }

                _fileName = value;
            }
        }

        public string Extension
        {
            get { return _extension; }
            set { _extension = value?.TrimStart('.'); }
        }

        public PeriodicityOptions Periodicity { get; set; } = PeriodicityOptions.Daily;

        public string LogDirectory { get; set; } = "Logs";
    }
}