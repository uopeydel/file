namespace mf_service.SharedService.MfLogProvider
{
    public enum PeriodicityOptions
    {
        Daily,
        Hourly,
        Minutely,
        Monthly
    }
}