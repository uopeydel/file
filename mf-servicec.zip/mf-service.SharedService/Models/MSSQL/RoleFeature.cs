using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace mf_service.SharedService.Models.MSSQL
{
    public class RoleFeature
    {
        /*[Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long id { get; set; }*/

        [Key]
        [Column("role_id", Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long role_id { get; set; }

        [Key]
        [Column("feature_id", Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long feature_id { get; set; }


        [ForeignKey("feature_id")] public virtual Feature Feature { get; set; }

        [ForeignKey("role_id")] public virtual Role Role { get; set; }


        [Column("is_active")] public bool is_active { get; set; }

        [Column("created", TypeName = "datetime2")]
        public DateTime created { get; set; }

        [Column("modified", TypeName = "datetime2")]
        public DateTime modified { get; set; }
    }
}