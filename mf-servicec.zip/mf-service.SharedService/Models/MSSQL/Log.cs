using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using mf_service.SharedService.Contract.Enums;

namespace mf_service.SharedService.Models.MSSQL
{
    public class Log
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id")]
        public Guid id { get; set; }

        [Column("rquid")] public string rquid { get; set; }
        [Column("userid")] public string userid { get; set; }

        [Column("message")] public string message { get; set; }

        [Column("created", TypeName = "datetime2")]
        public DateTime created { get; set; }

        [Column("logType")]
        public MFEnums.LogType logType { get; set; }
    }
}