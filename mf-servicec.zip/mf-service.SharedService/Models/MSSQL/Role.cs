using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace mf_service.SharedService.Models.MSSQL
{
    public class Role
    {
        public Role()
        {
            RoleFeatures = new HashSet<RoleFeature>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id")]  public long id { get; set; }

        [Column("name")] [StringLength(255)] public string name { get; set; }

        [Column("code")] [StringLength(255)] public string code { get; set; }

        [Column("is_active")] public bool is_active { get; set; }

        [Column("created",TypeName = "datetime2")] public DateTime created { get; set; }

        [Column("modified",TypeName = "datetime2")] public DateTime modified { get; set; }

        public virtual ICollection<RoleFeature> RoleFeatures { get; set; }
    }
}