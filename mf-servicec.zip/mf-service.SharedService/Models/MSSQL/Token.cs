using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace mf_service.SharedService.Models.MSSQL
{
    public class Token
    { 
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public long Id { get; set; }
        [Required]
        public string RefreshToken { get; set; }
        [Required]
        public string Salt { get; set; }
        [Required]
        public string UserId { get; set; }
    }
}