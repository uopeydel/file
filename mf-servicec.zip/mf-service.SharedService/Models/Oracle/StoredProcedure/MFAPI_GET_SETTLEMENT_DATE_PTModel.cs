namespace mf_service.SharedService.Models
{
    public class MFAPI_GET_SETTLEMENT_DATE_PTModel
    {
        public string RED_DATE { get; set; }
        public string SEQ { get; set; }
        public string SETTLEMENT_DATE { get; set; } 
    }
}

 