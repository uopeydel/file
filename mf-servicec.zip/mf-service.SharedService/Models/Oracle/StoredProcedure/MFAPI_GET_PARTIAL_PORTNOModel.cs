﻿using System;
namespace mf_service.SharedService.Models
{
    public class MFAPI_GET_PARTIAL_PORTNOModel
    {
        public string NAME { get; set; }
        public string PORTFOLIOCODE { get; set; }
    }
}
