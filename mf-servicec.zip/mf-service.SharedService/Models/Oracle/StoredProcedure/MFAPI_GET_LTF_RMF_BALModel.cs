﻿using System;

namespace mf_service.SharedService.Models
{
    public class MFAPI_GET_LTF_RMF_BALModel
    { 
        public string AVG_COST { get; set; }
        public string AVG_PRICE { get; set; }
        public string FUND_CODE { get; set; }
        public string FUND_NAME_TH { get; set; }
        public string FUND_TYPE { get; set; }
        public string INVESTMENT_VALUE { get; set; }
        public string INVESTMENT_YEAR { get; set; }
        public string MARKET_PRICE { get; set; }
        public string PORTFOLIO { get; set; }
        public string UNIT { get; set; }
    }
}