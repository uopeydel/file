namespace mf_service.SharedService.Models
{
    public class MFAPI_GET_SETTLEMENT_DATEModel
    {
        public string AMOUNT { get; set; }
        public string EFFECTIVEDATE { get; set; }
        public string FULLREDEMTION { get; set; }
        public string FUNDNAME { get; set; }
        public string MODEL { get; set; }
        public string PORTFOLIOCODE { get; set; }
        public string SETTLEMENT_DATE { get; set; }
        public string STATUSCODE { get; set; }
        public string TRANSACTIONDATE { get; set; }
        public string UNIT { get; set; }
    }
}