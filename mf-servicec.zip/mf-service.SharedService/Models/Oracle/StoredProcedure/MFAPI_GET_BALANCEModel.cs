﻿using System;

namespace mf_service.SharedService.Models
{
    public class MFAPI_GET_BALANCEModel
    {
        public string FUND_NAME { get; set; }
        public string ADV_TYPE { get; set; }
        public string AMOUNT { get; set; }
        public string ASSET_CLASS { get; set; }
        public string FUND_TYPE_CODE { get; set; }
        public string GAIN_LOSS { get; set; }
        public string GAIN_LOSS_PER { get; set; }
        public string INVESTMENT_VAL { get; set; }
        public string IS_LTF { get; set; }
        public DateTime NAV_DATE { get; set; }
        public string NAV_PER_UNIT { get; set; }
        public string PORTNAME { get; set; }
        public string UNIT { get; set; }
        public string WEIGHT { get; set; }
        public string MODEL{ get; set; }
    }
}
