﻿using System;
namespace mf_service.SharedService.Models
{
    public class MFAPI_GET_STMREBALModel
    {
        public double AMOUNT { get; set; }
        public string EFFECTIVEDATE { get; set; }
        public string FUNDCODE { get; set; }
        public string FUNDNAMEEN { get; set; }
        public string FUNDNAMETH { get; set; }
        public string ORDERID { get; set; }
        public string ORDERSUBTYPECODE { get; set; }
        public string ORDERTYPECODE { get; set; }
        public string PARENTORDERID { get; set; }
        public string PORTFOLIOCODE { get; set; }
        public double PRICE { get; set; }
        public string STATUSCODE { get; set; }
        public string TRANSACTIONDATE { get; set; }
        public double UNIT { get; set; }
    }
}
