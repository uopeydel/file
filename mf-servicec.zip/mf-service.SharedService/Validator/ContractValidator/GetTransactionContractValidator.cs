﻿
using System;
using FluentValidation;
using System.Linq;
using mf_service.SharedService.Contract.MF.Search;

namespace mf_service.SharedService.Validator.ContractValidator
{
    public class GetTransactionContractValidator : AbstractValidator<GetTransactionContract>
    {

        public GetTransactionContractValidator()
        {
            RuleFor(x => x.FromDate).NotNull().Length(8);
            RuleFor(x => x.ToDate).NotNull().Length(8);
            RuleFor(x => x.PortfolioNo).NotEmpty();
        }
    }

    public class GenPDFPortContractValidator : AbstractValidator<GenPDFPortContract>
    {

        public GenPDFPortContractValidator()
        {
            RuleFor(x => x.FromDate).NotNull().Length(8);
            RuleFor(x => x.ToDate).NotNull().Length(8);
            RuleFor(x => x.PortfolioList).NotEmpty().NotNull()
                .Must(m => m.All(w => !string.IsNullOrEmpty(w)))
                .WithMessage("Portfolio invalid.");
        }

    }
}

