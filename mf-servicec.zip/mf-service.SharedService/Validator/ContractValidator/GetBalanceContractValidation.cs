﻿using System;
using FluentValidation;
using mf_service.SharedService.Contract.MF.Search;

namespace mf_service.SharedService.Validator.ContractValidator
{
    public class GetBalanceContractValidation : AbstractValidator<GetBalanceContract>
    {
        public GetBalanceContractValidation()
        {
            RuleFor(x => x.FROMDATE).NotNull().Length(8);
            RuleFor(x => x.PORTFOLIONO).NotEmpty().NotNull().MaximumLength(4000);
        }
    }


}
