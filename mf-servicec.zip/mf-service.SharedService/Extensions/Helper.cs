﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Linq; 

namespace mf_service.SharedService.Extensions
{
    public static class Helper
    { 
        public static T DataRowTo<T>(DataRow row) where T : class, new()
        {
            try
            {
                List<T> list = new List<T>();

                T obj = new T();

                foreach (var prop in obj.GetType().GetProperties())
                {
                    try
                    {
                        PropertyInfo propertyInfo = obj.GetType().GetProperty(prop.Name);
                        propertyInfo.SetValue(obj, Convert.ChangeType(row[prop.Name], propertyInfo.PropertyType), null);
                    }
                    catch
                    {
                        continue;
                    }
                } 
                return obj; 
            }
            catch
            {
                return null;
            }
        }
        
        public static string LimitLength(string word ,int length = 250)
        {
            if (string.IsNullOrEmpty(word))
            {
                return null;
            }

            word = word.ToUpper().Replace(" ", "");
            
            if (word.Length > length)
            {
                return word.Substring(0, length);
            }

            return word ;
        }
    }
}
