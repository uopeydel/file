﻿using System;


namespace mf_service.SharedService.Extensions
{
    public static class ConvertStringToEnum
    {
        public static T ToEnum<T>(this string value)
        {
            return (T)Enum.Parse(typeof(T), value, true);
        }
    }

    
}
