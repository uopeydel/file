using System;
using Microsoft.Extensions.Caching.Memory;

namespace mf_service.SharedService.Extensions
{
    public class MemoryCacheWithPolicy
    {
        private readonly IMemoryCache _cache;

        public MemoryCacheWithPolicy(IMemoryCache memoryCache)
        {
            _cache = memoryCache;
        }


        public void Create(string key , string value = null)
        {
            if (_cache.TryGetValue(key, out string item))
            { 
                return;
            }

            var cacheEntryOptions = new MemoryCacheEntryOptions()
                .SetSize(1)
                .SetPriority(CacheItemPriority.High)
                .SetAbsoluteExpiration(TimeSpan.FromMinutes(15));
            _cache.Set(key, string.Empty, cacheEntryOptions);
 
        }

        public bool Get(string key)
        {
            var result = _cache.TryGetValue(key, out string item); 
            return result;
        }

        public void Remove(string key)
        {
            if (_cache.TryGetValue(key, out _))
            {
                _cache.Remove(key);
            }
        }
    }
}