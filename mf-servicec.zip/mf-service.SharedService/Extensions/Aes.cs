using mf_service.SharedService.Requester;
using mf_service.SharedService.SystemService.Interface;
using System;
using System.IO;
using System.Reflection.Metadata;
using System.Security.Cryptography;
using System.Text;

namespace mf_service.SharedService.Extensions
{
    public class AesMf
    { 
        //This is doesn't use by di , cant use logger like this.
        //private static readonly IMFLoggerService _logger;

        public static string EncryptAES(string textToCrypt, byte[] cryptkey, byte[] initVector)
        {
            if (textToCrypt == null || textToCrypt.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (cryptkey == null || cryptkey.Length <= 0)
                throw new ArgumentNullException("Key");
            if (initVector == null || initVector.Length <= 0)
                throw new ArgumentNullException("IV");
            var errorMessage = "";

            try
            {
                using (var rijndaelManaged =
                       new RijndaelManaged { Key = cryptkey, IV = initVector, Mode = CipherMode.CBC })
                using (var memoryStream = new MemoryStream())
                using (var cryptoStream =
                       new CryptoStream(memoryStream,
                           rijndaelManaged.CreateEncryptor(cryptkey, initVector),
                           CryptoStreamMode.Write))
                {
                    using (var ws = new StreamWriter(cryptoStream))
                    {
                        ws.Write(textToCrypt);
                    }
                    return Convert.ToBase64String(memoryStream.ToArray());
                }
            }
            catch //(CryptographicException e)
            {
                errorMessage = " Error while Decrypt ";
                //_logger.LogInfo(" ERROR REQUEST: ", errorMessage + " " + e.Message, typeof(RequesterService).Name);
                return null;
            }
        }

        public static string DecryptAES(string cipherData, byte[] cryptkey, byte[] initVector)
        {
            if (cipherData == null || cipherData.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (cryptkey == null || cryptkey.Length <= 0)
                throw new ArgumentNullException("Key");
            if (initVector == null || initVector.Length <= 0)
                throw new ArgumentNullException("IV");
            var errorMessage = "";

            try
            {
                using (var rijndaelManaged =
                       new RijndaelManaged { Key = cryptkey, IV = initVector, Mode = CipherMode.CBC })
                using (var memoryStream =
                       new MemoryStream(Convert.FromBase64String(cipherData)))
                using (var cryptoStream =
                       new CryptoStream(memoryStream,
                           rijndaelManaged.CreateDecryptor(cryptkey, initVector),
                           CryptoStreamMode.Read))
                {
                    return new StreamReader(cryptoStream).ReadToEnd();
                }
            }
            catch //(CryptographicException e)
            {
                errorMessage = " Error while Encrypt ";
                //_logger.LogInfo(" ERROR REQUEST: ", errorMessage + " " + e.Message, typeof(RequesterService).Name);
                return null;
            }
        }
    }
}