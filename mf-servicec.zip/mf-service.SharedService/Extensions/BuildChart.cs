using System;
using System.Collections.Generic;
using System.Linq;
using mf_service.SharedService.Contract.Report.Result;
using Microsoft.Extensions.Configuration;

namespace mf_service.SharedService.Extensions
{
    public static class BuildChart
    {
        public static List<GraphBodyContract> MapValueToGraph(List<List<MFAPI_GET_BALANCEContract>> values,
            IConfiguration configuration)
        {
            var assetClassNames = new List<GraphBodyContract>();
            for (int i = 0; i < 9; i++)
            {
                var assetName = configuration[$"ASSETCLASS:NAMES:{i}"];
                assetClassNames.Add(new GraphBodyContract
                {
                    Color = configuration[$"ASSETCLASS:{assetName}:COLOR"],
                    NameEn = configuration[$"ASSETCLASS:{assetName}:NAMEEN"],
                    NameTh = configuration[$"ASSETCLASS:{assetName}:NAMETH"],
                    Order = int.Parse(configuration[$"ASSETCLASS:{assetName}:ORDER"]),
                    Label = assetName,
                });
            }

            foreach (var balance in values)
            {
                var assetClass = balance.Select(s => s.ASSET_CLASS).FirstOrDefault();
                if (!string.IsNullOrEmpty(assetClass))
                {
                    var investmentValueSum = balance.Select(s => s.INVESTMENT_VAL).Sum();
                    var weightSum = balance.Select(s => s.WEIGHT).Sum();
                    var objData = assetClassNames
                        .Select((s, i) => new {index = i, obj = s})
                        .FirstOrDefault(w => w.obj.NameEn.Equals(assetClass));

                    objData.obj.Label = assetClass;
                    objData.obj.Value = (decimal) investmentValueSum;
                    objData.obj.Percent = (decimal) weightSum; 
                    objData.obj.Percen = weightSum >= decimal.Parse("0.01") ? string.Format("{0:n2}", weightSum) : "0"; 
                    assetClassNames[objData.index] = objData.obj;
                }
            }

            return assetClassNames.OrderBy(o => o.Order).ToList();
        }
    }
}