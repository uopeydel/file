﻿using System;
using AutoMapper;
using FluentValidation;
using mf_report.Server.ViewModel;
using mf_reportservice.Server.ViewModel;
using mf_service.LDAP.Repository.Implement;
using mf_service.LDAP.Repository.Interface;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.Mapper;
using mf_service.SharedService.Requester;
using mf_service.SharedService.SystemService.Implement;
using mf_service.SharedService.SystemService.Interface;
using mf_service.SharedService.Validator.ContractValidator;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Xml;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace mf_report.Server.SystemService
{
    public static class ServiceExtensions
    {
        public static void AddIoc(this IServiceCollection services, IConfiguration Configuration)
        {
            #region Transient

            services.AddTransient<IValidator<GetTransactionContract>, GetTransactionContractValidator>();
            services.AddTransient<IValidator<GenPDFPortContract>, GenPDFPortContractValidator>();
            services.AddTransient<IValidator<GetBalanceContract>, GetBalanceContractValidation>();
            services.AddTransient<IJwtTokenService, JwtTokenServiceImpl>();

            services.AddSingleton<IMemoryCache, MemoryCache>();
            services.AddSingleton<MemoryCacheWithPolicy>();
            services.AddMemoryCache();

            #endregion


            #region Scoped

            services.AddScoped<IMFLoggerService, MFLoggerServiceImpl>();

            services.AddScoped<ILDAPService, LdapServiceImpl>();
            services.AddScoped<ILDAPRepository, LDAPRepository>();

            services.AddScoped<RequesterService>();
            services.AddScoped<Report01ViewModel>();
            services.AddScoped<Report02ViewModel>();
            services.AddScoped<Report03ViewModel>();
            services.AddScoped<Report04ViewModel>();
            services.AddScoped<Report05ViewModel>();
            services.AddScoped<Report06ViewModel>();
            services.AddScoped<Report07ViewModel>();
            services.AddScoped<MutualFundViewModel>();
            services.AddScoped<FeatureViewModel>();
            services.AddScoped<RoleViewModel>();
            services.AddScoped<LDAPViewModel>();

            #endregion


            #region Singleton

            var mappingConfig = new MapperConfiguration(mc => { mc.AddProfile(new MappingProfile(Configuration)); });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            #endregion

            services.AddHttpClient();
        }
    }
}