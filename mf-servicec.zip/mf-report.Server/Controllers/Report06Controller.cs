﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_report.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace mf_report.Server.Controllers
{
    [Route("api/v1/r06")]
    public class Report06Controller : BaseController
    {
        public Report06Controller(Report06ViewModel report06ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy) : base(
            report06ViewModel, logger, cacheWithPolicy)
        {
        }

        [Authorize]
        [HttpPost("")]
        public async Task<IActionResult> Index([FromBody] PortfolioSearchContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" CREATE REPORT ", searchBody, typeof(Report06Controller).Name);
            var result = await _report06ViewModel.GetReport06(searchBody);
            if (result.IsError())
            {
                _logger.LogObj(" GET REPORT 6 DATA ERROR ", result, typeof(Report06Controller).Name,
                    LogLevel.Error);
                return StatusCode(500, result);
            }

            var fileList = await BuildPdfByte(result, "Report06");
            if (fileList.IsError())
            {
                _logger.LogObj(" BUILD PDF REPORT 6 ERROR ", fileList.Errors, typeof(Report06Controller).Name,
                    LogLevel.Error);
                return StatusCode(500, fileList);
            }

            var mergResponse = PdfMerger.MergeFiles(fileList.Data);
            return File(
                fileContents: mergResponse,
                contentType: "application/pdf",
                fileDownloadName: $"mfreport06_{DateTime.Now.ToLocalTime().ToString("dd_MM_yyyy___hh_mm_ss")}.pdf");
        }

        [AllowAnonymous]
        //Not for frontend call, But add it for generate html add patial header
        [HttpGet("Header")]
        public IActionResult Header([FromQuery] PDFHeaderContract header)
        {
            return View("Header", header);
        }

        [AllowAnonymous]
        //Not for frontend call, But add it for generate html add patial header
        [HttpGet("Footer")]
        public IActionResult Footer()
        {
            return View("Footer");
        }
    }
}