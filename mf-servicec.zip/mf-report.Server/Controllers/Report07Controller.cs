﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_report.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace mf_report.Server.Controllers
{
    [Route("api/v1/r07")]
    public class Report07Controller : BaseController
    {
        public Report07Controller(Report07ViewModel report07ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy) : base(
            report07ViewModel, logger, cacheWithPolicy)
        {
        }

        [Authorize]
        [HttpPost("")]
        public async Task<IActionResult> Index([FromBody] PortfolioSearchContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" CREATE REPORT ", searchBody, typeof(Report07Controller).Name);
            var result = await _report07ViewModel.GetReport07(searchBody);
            if (result.IsError())
            {
                _logger.LogObj(" GET REPORT 7 DATA ERROR ", result, typeof(Report07Controller).Name,
                    LogLevel.Error);
                return StatusCode(500, result);
            }

            var fileList = await BuildPdfByte(result, "Report07");
            if (fileList.IsError())
            {
                _logger.LogObj(" BUILD PDF REPORT 7 ERROR ", fileList.Errors, typeof(Report07Controller).Name,
                    LogLevel.Error);
                return StatusCode(500, fileList);
            }

            var mergResponse = PdfMerger.MergeFiles(fileList.Data);
            return File(
                fileContents: mergResponse,
                contentType: "application/pdf",
                fileDownloadName: $"mfreport07_{DateTime.Now.ToLocalTime().ToString("dd_MM_yyyy___hh_mm_ss")}.pdf");
        }

        [AllowAnonymous]
        //Not for frontend call, But add it for generate html add patial header
        [HttpGet("Header")]
        public IActionResult Header([FromQuery] PDFHeaderContract header)
        {
            return View("Header", header);
        }

        [AllowAnonymous]
        //Not for frontend call, But add it for generate html add patial header
        [HttpGet("Footer")]
        public IActionResult Footer()
        {
            return View("Footer");
        }
    }
}