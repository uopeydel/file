using System.Threading.Tasks;
using mf_report.Server.Controllers;
using mf_reportservice.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace mf_reportservice.Server.Controllers
{
    [Authorize]
    [Route("api/v1/feature")]
    public class FeatureController : BaseController
    {
        public FeatureController(FeatureViewModel viewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy) : base(viewModel, logger, cacheWithPolicy)
        {
        }

        [HttpPost("")]
        public async Task<IActionResult> GetAll()
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GETALLFEATURE ", default, typeof(FeatureController).Name);
            var result = await _featureViewModel.GetFeatures();
            return Ok(result);
        }

        [HttpPost("create")]
        public async Task<IActionResult> AddFeatures([FromBody] FeatureContract feature)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj($" ADDFEATURE ", feature, typeof(FeatureController).Name);
            var result = await _featureViewModel.AddFeatures(feature);
            return Ok(result);
        }
    }
}