﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_report.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace mf_report.Server.Controllers
{
    [Route("api/v1/r05")]
    public class Report05Controller : BaseController
    {
        public Report05Controller(Report05ViewModel report05ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy) : base(
            report05ViewModel, logger, cacheWithPolicy)
        {
        }

        [Authorize]
        [HttpPost("")]
        public async Task<IActionResult> Index([FromBody] PortfolioSearchContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" CREATE REPORT ", searchBody, typeof(Report05Controller).Name);
            var result = await _report05ViewModel.GetReport05(searchBody);
            if (result.IsError())
            {
                _logger.LogObj(" GET REPORT 5 DATA ERROR ", result, typeof(Report05Controller).Name,
                    LogLevel.Error);
                return StatusCode(500, result);
            }

            var fileList = await BuildPdfByte(result, "Report05");
            if (fileList.IsError())
            {
                _logger.LogObj(" BUILD PDF REPORT 5 ERROR ", fileList.Errors, typeof(Report05Controller).Name,
                    LogLevel.Error);
                return StatusCode(500, fileList);
            }

            var mergResponse = PdfMerger.MergeFiles(fileList.Data);
            
            _logger.LogObj(" FILE REPORT05 REPORT SIZE ",fileList.Data.Select(s=> s.Length).Sum(), typeof(Report05Controller).Name,
                LogLevel.Information);
            
            return File(
                fileContents: mergResponse,
                contentType: "application/pdf",
                fileDownloadName: $"mfreport05_{DateTime.Now.ToLocalTime().ToString("dd_MM_yyyy___hh_mm_ss")}.pdf");
        }

        [AllowAnonymous]
        //Not for frontend call, But add it for generate html add patial header
        [HttpGet("Header")]
        public IActionResult Header([FromQuery] PDFHeaderContract header)
        {
            return View("Header", header);
        }

        [AllowAnonymous]
        //Not for frontend call, But add it for generate html add patial header
        [HttpGet("Footer")]
        public IActionResult Footer()
        {
            return View("Footer");
        }
    }
}