﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using mf_report.Server.ViewModel;
using mf_reportservice.Server.ViewModel;
using mf_service.LDAP.Contract;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.Middlewares;
using mf_service.SharedService.Models.MSSQL;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Rotativa.AspNetCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;

namespace mf_report.Server.Controllers
{
    public class BaseController : Controller
    {
        protected readonly MemoryCacheWithPolicy _cacheWithPolicy;
        protected readonly IMFLoggerService _logger;
        protected readonly Report01ViewModel _report01ViewModel;

        public BaseController(Report01ViewModel report01ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
        {
            _logger = logger;
            _report01ViewModel = report01ViewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }


        protected readonly Report02ViewModel _report02ViewModel;

        public BaseController(Report02ViewModel report02ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
        {
            _logger = logger;
            _report02ViewModel = report02ViewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }

        protected readonly Report03ViewModel _report03ViewModel;

        public BaseController(Report03ViewModel report03ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
        {
            _logger = logger;
            _report03ViewModel = report03ViewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }

        protected readonly Report04ViewModel _report04ViewModel;

        public BaseController(Report04ViewModel report04ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
        {
            _logger = logger;
            _report04ViewModel = report04ViewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }

        protected readonly Report05ViewModel _report05ViewModel;

        public BaseController(Report05ViewModel report05ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
        {
            _logger = logger;
            _report05ViewModel = report05ViewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }

        protected readonly Report06ViewModel _report06ViewModel;

        public BaseController(Report06ViewModel report06ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
        {
            _logger = logger;
            _report06ViewModel = report06ViewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }

        protected readonly Report07ViewModel _report07ViewModel;

        public BaseController(Report07ViewModel report07ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
        {
            _logger = logger;
            _report07ViewModel = report07ViewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }

        protected readonly IConfiguration _configuration;
        protected readonly MutualFundViewModel _mutualFundViewModel;

        public BaseController(
            IMFLoggerService logger,
            MutualFundViewModel mutualFundViewModel,
            IConfiguration configuration,
            MemoryCacheWithPolicy cacheWithPolicy
        )
        {
            _logger = logger;
            _configuration = configuration;
            _mutualFundViewModel = mutualFundViewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }


        protected readonly RoleViewModel _roleViewModel;

        public BaseController(RoleViewModel viewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
        {
            _logger = logger;
            _roleViewModel = viewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }

        protected readonly FeatureViewModel _featureViewModel;

        public BaseController(FeatureViewModel viewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
        {
            _logger = logger;
            _featureViewModel = viewModel;
            _cacheWithPolicy = cacheWithPolicy;
        }

        protected readonly LDAPViewModel _ldapViewModel;

        public BaseController(
            LDAPViewModel ldapViewModel,
            IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy
        )
        {
            _logger = logger;
            _ldapViewModel = ldapViewModel;
            _cacheWithPolicy = cacheWithPolicy;
            //_logger.SetLogDesc(LogDesc);
        }

        protected LogDesc LogDesc
        {
            get
            {
                var logDesc = (LogDesc) HttpContext.Items["logDesc"];
                logDesc.Jti = Jti;
                logDesc.UserId = UserId;
                logDesc.UserRole = UserRoles;
                return logDesc;
            }
        }

        protected string UserRoles
        {
            get
            {
                if (User?.Identity == null)
                {
                    return "";
                }

                var authority = User.Claims.Where(w => w.Type.Contains("authority"))
                    .Select(s => s.Value).FirstOrDefault();
                return authority;
            }
        }

        protected string UserId
        {
            get
            {
                if (User?.Identity == null)
                {
                    return "";
                }

                var authority = User.Claims.Where(w => w.Type.Contains(JwtRegisteredClaimNames.NameId))
                    .Select(s => s.Value).FirstOrDefault();
                return authority;
            }
        }

        protected string Jti
        {
            get
            {
                if (User?.Identity == null)
                {
                    return "";
                }

                var authority = User.Claims.Where(w => w.Type.Contains(JwtRegisteredClaimNames.Jti))
                    .Select(s => s.Value).FirstOrDefault();
                return authority;
            }
        }


        protected IActionResult BaseError()
        {
            if (!ModelState.IsValid)
            {
                var result = StatusCode(400,
                    PandaResponse.CreateErrorResponse<IActionResult>(ModelState.Values
                        .SelectMany(s => s.Errors.Select(ss => ss.ErrorMessage)).ToArray()));
                return result;
            }

            if (_cacheWithPolicy.Get(UserId + Jti))
            {
                return StatusCode(401, PandaResponse.CreateErrorResponse<bool>("Auth Error"));
            }

            return null;
        }

        protected async Task<PandaResults<List<byte[]>>> BuildPdfByte<TKey, TValue>(
            PandaResults<List<PDFContract<TKey, TValue>>> pdfData,
            string controllerName
        )
        {
            if (pdfData.IsError())
            {
                return PandaResponse.CreateErrorResponse<List<byte[]>>(pdfData.Errors.ToArray());
            }

            var pdfResult = new List<byte[]>();
            var excs = new List<string>();

            _logger.LogInfo(" BUILD PDF START ", " Start Generate pdf. Set count : " + pdfData.Data.Count(),
                typeof(BaseController).Name);

            int pdfSet = 0;
            foreach (var pdf in pdfData.Data)
            {
                pdfSet++;
                _logger.LogInfo(" BUILD PDF INITIAL PAGE ", " Number of set " + pdfSet,
                    typeof(BaseController).Name);

                try
                {
                    _logger.LogInfo(" BUILD PDF SET PROTOCOL ", " ",
                        typeof(BaseController).Name);
                    var protocol = "http";
                    if (HttpContext.Request.IsHttps)
                    {
                        protocol = "https";
                    }

                    _logger.LogInfo(" BUILD PDF SET FOOTER ", " ",
                        typeof(BaseController).Name);
                    var urlActionFooter = Url.Action(action: "Footer", controller: controllerName, values: new { },
                        protocol: protocol);
                    _logger.LogInfo(" BUILD PDF SET HEADER ", " ",
                        typeof(BaseController).Name);
                    var urlActionHeader = Url.Action(action: "Header", controller: controllerName, values: pdf.Headers,
                        protocol: protocol);
                    _logger.LogInfo(" BUILD PDF SET CUSTOM SWITCHES ", " ",
                        typeof(BaseController).Name);
                    string customSwitches = $" --margin-left 3 --margin-right 3  --header-html {urlActionHeader}";
                    _logger.LogInfo(" CONFIG CUSTOM SWITCH ", " ",
                        typeof(BaseController).Name);
                    string startPangenumberAt = "0";
                    customSwitches += $" --header-spacing {pdf.Headers.FullNames.Distinct().Count()}  ";
                    customSwitches +=
                        $" --page-offset {startPangenumberAt}  --footer-html {urlActionFooter} --disable-smart-shrinking";
                    _logger.LogInfo(" VIEW AS PDF ", " ",
                        typeof(BaseController).Name);
                    var view = new ViewAsPdf("Index", pdf.Values)
                    {
                        PageSize = Rotativa.AspNetCore.Options.Size.A4,
                        CustomSwitches = customSwitches,
                    };
                    _logger.LogInfo(" BUILD FILE PDF ", view.WkhtmlPath,
                        typeof(BaseController).Name);
                    var buildFile = await view.BuildFile(this.ControllerContext);
                    _logger.LogInfo($" FILE {pdfSet} SIZE {buildFile.Length} ", " ",
                        typeof(BaseController).Name);
                    _logger.LogInfo(" ADD BUILD FILE TO LIST ", " ",
                        typeof(BaseController).Name);
                    pdfResult.Add(buildFile);
                }
                catch (Exception e)
                {
                    _logger.LogInfo(" BUILD EXCEPTION ", e.ToString(),
                        typeof(BaseController).Name, LogLevel.Error);
                    var inner = e.InnerException?.Message;
                    _logger.LogInfo(" BUILD ERROR ", inner,
                        typeof(BaseController).Name, LogLevel.Error);
                    var errorMessage = PandaResponse.CreateErrorResponse<bool>("", e);

                    excs.Add(string.Join(",", errorMessage.Errors));
                }
            }

            if (excs.Count == pdfData.Data.Count)
            {
                excs.Insert(0, " ERROR WHILE GENERATE PDF ");
                _logger.LogInfo(" EXCEPTION ", string.Join(" , ", excs),
                    typeof(BaseController).Name, LogLevel.Error);
                return PandaResponse.CreateErrorResponse<List<byte[]>>(excs.ToArray());
            }

            return PandaResponse.CreateSuccessResponse(pdfResult);
        }
    }
}