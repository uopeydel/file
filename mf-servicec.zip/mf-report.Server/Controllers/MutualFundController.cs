﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_report.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.MF.Result;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.Requester;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Org.BouncyCastle.Bcpg;

namespace mf_report.Server.Controllers
{
    [Authorize]
    [Route("api/mutualfund")]
    public class MutualFundController : BaseController
    {
        public MutualFundController(
            IMFLoggerService logger,
            MutualFundViewModel mutualFundViewModel,
            IConfiguration configuration,
            MemoryCacheWithPolicy cacheWithPolicy)
            : base(logger, mutualFundViewModel, configuration, cacheWithPolicy)
        {
        }


        [HttpPost("searchportno")]
        public async Task<IActionResult> SearchPortNo([FromBody] SearchPortNoContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" SEARCH PORT NO ", searchBody, typeof(MutualFundController).Name);
            var result = await _mutualFundViewModel.SearchPortNo(searchBody);
            if (result.IsError())
            {
                return StatusCode(500, result);
            }

            return Ok(result);
        }


        [HttpPost("searchpartialportno")]
        public async Task<IActionResult> SearchPartialPortNo([FromBody] SearchPartialPortNoContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" SEARCH PATIAL PORT NO ", searchBody, typeof(MutualFundController).Name);
            var result = await _mutualFundViewModel.SearchPartialPortNo(searchBody);
            if (result.IsError())
            {
                _logger.LogObj(" SEARCH PATIAL PORT NO ", result, typeof(MutualFundController).Name, LogLevel.Error);
                return StatusCode(500, result);
            }

            return Ok(result);
        }


        [HttpPost("getsettlementdate/calendar/pt")]
        public async Task<IActionResult> GetSettlementDateCalendarPT(
            [FromBody] SearchSettlementDateByCalendarContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GETSETTLEMENT DATE CALENDAR PT ", searchBody, typeof(MutualFundController).Name);
            PandaResults<List<SettlementDateByCalendarPTResultContract>> result =
                await _mutualFundViewModel.GetSettlementDateCalendarPT(searchBody);
            if (result.IsError())
            {
                _logger.LogObj(" GETSETTLEMENT DATE CALENDAR PT ERROR ", result, typeof(MutualFundController).Name);
                return StatusCode(500, result);
            }

            return Ok(result);
        }


        [HttpPost("getsettlementdate/calendar/tsp")]
        public async Task<IActionResult> GetSettlementDateCalendarTSP(
            [FromBody] SearchSettlementDateByCalendarContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GETSETTLEMENT DATE CALENDAR TSP ", searchBody, typeof(MutualFundController).Name);
            PandaResults<List<SettlementDateByCalendarTSPResultContract>> result =
                await _mutualFundViewModel.GetSettlementDateCalendarTSP(searchBody);
            if (result.IsError())
            {
                _logger.LogObj(" GETSETTLEMENT DATE CALENDAR TSP ERROR ", result, typeof(MutualFundController).Name,
                    LogLevel.Error);
                return StatusCode(500, result);
            }

            return Ok(result);
        }


        [HttpPost("getsettlementdate/customer")]
        public async Task<IActionResult> GetSettlementDateCustomer(
            [FromBody] SearchSettlementDateByCustomerContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET SETTLEMENT DATE CUSTOMER ", searchBody, typeof(MutualFundController).Name);
            PandaResults<List<SettlementDateByCustomerResultContract>> result =
                await _mutualFundViewModel.GetSettlementDateCustomer(searchBody);
            if (result.IsError())
            {
                _logger.LogObj(" GET SETTLEMENT DATE CUSTOMER ", result, typeof(MutualFundController).Name,
                    LogLevel.Error);
                return StatusCode(500, result);
            }

            return Ok(result);
        }
         
        [HttpPost("exportlog")]
        public async Task<IActionResult> ExportLog([FromBody] GetLogContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }
            
            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET LOG ", searchBody, typeof(MutualFundController).Name);
            var result =
                await _mutualFundViewModel.ExportLog(searchBody);
            if (result.IsError())
            {
                _logger.LogObj(" Export Log Error ", result, typeof(MutualFundController).Name,
                    LogLevel.Error);
                return StatusCode(500, result);
            }
            return File(
                fileContents: result.Data,
                contentType: "application/CSV",
                fileDownloadName: $"activity-log-{DateTime.Now.ToLocalTime().ToString("dd_MM_yyyy___hh_mm_ss")}.csv");
        }
    }
}