﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_report.Server.ViewModel;
using mf_service.LDAP.Contract;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Org.BouncyCastle.Bcpg;
using System.Text;


namespace mf_report.Server.Controllers
{
    [Route("api/ldap")]
    public class LDAPController : BaseController
    {
        public LDAPController(
            LDAPViewModel ldapViewModel,
            IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy)
            : base(ldapViewModel, logger, cacheWithPolicy)
        {
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginContract loginContract)
        {
            var logDesc = LogDesc;
            logDesc.UserId = loginContract.UserName;
            _logger.SetLogDesc(logDesc);
            var loginResult = await _ldapViewModel.Login(loginContract);
            if (loginResult.IsError())
            {
                _logger.LogObj($" LOGIN ERROR ", loginResult, typeof(LDAPController).Name, LogLevel.Error);
                return StatusCode(401, loginResult);
            }
            else
            {
                var encryptPassword = AesMf.EncryptAES(
                    loginContract.Password,
                    Encoding.UTF8.GetBytes(mf_service.SharedService.Contract.Constants.Constant.AesKey),
                    Encoding.UTF8.GetBytes(mf_service.SharedService.Contract.Constants.Constant.AesIV)
                );

                var resultLogin = loginResult.Data.userId + " access token : " + encryptPassword;
                _logger.LogInfo(" LOGIN DONE ", resultLogin, typeof(LDAPController).Name);
                return StatusCode(200, loginResult);
            }
        }

        [AllowAnonymous]
        [HttpPost("refresh")]
        public async Task<IActionResult> RefreshToken([FromBody] RefreshTokenContract token)
        {
            _logger.SetLogDesc(LogDesc);
            var refreshResult = await _ldapViewModel.RefreshToken(token);
            if (refreshResult.IsError())
            {
                _logger.LogObj(" REFRESH ERROR ", refreshResult, typeof(LDAPController).Name, LogLevel.Error);
                return StatusCode(401, refreshResult);
            }
            else
            {
                _logger.LogInfo(" REFRESH DONE ", refreshResult.Data.userId, typeof(LDAPController).Name);
                return StatusCode(200, refreshResult);
            }
        }

        [Authorize]
        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            var logDesc = LogDesc;
            logDesc.UserId = UserId;
            _logger.SetLogDesc(logDesc);
            var logoutResult = await _ldapViewModel.Logout(new LoginContract {UserName = UserId});
            if (logoutResult.IsError())
            {
                _logger.LogObj($" LOGOUT ERROR ", logoutResult, typeof(LDAPController).Name, LogLevel.Error);
                return StatusCode(401, logoutResult);
            }
            else
            {
                _cacheWithPolicy.Create(UserId + Jti);
                _logger.LogObj(" LOGOUT DONE ", logoutResult.Data, typeof(LDAPController).Name);
                return StatusCode(200, logoutResult);
            }
        }
    }
}