using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using mf_report.Server.Controllers;
using mf_reportservice.Server.ViewModel;
using mf_service.SharedService.Contract.UserManagement.Body;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace mf_reportservice.Server.Controllers
{
    [Authorize]
    [Route("api/v1/role")]
    public class RoleController : BaseController
    {
        public RoleController(RoleViewModel viewModel, IMFLoggerService logger, MemoryCacheWithPolicy cacheWithPolicy) :
            base(viewModel, logger, cacheWithPolicy)
        {
        }


        [HttpPost("")]
        public async Task<IActionResult> GetAll()
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET ALL ROLE ", default, typeof(RoleController).Name);
            var result = await _roleViewModel.GetRoles();
            return Ok(result);
        }

        [HttpPost("code")]
        public async Task<IActionResult> GetFeaturesByRole([FromBody] RoleCreateContract roleCode)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET BY CODE ", roleCode, typeof(RoleController).Name);
            var result = await _roleViewModel.GetFeaturesByRole(roleCode);
            return Ok(result);
        }

#if DEBUG
        [AllowAnonymous]
#endif
        [HttpPost("all")]
        public async Task<IActionResult> GetAllFeaturesRoles()
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" GET ALL ", default, typeof(RoleController).Name);
            var result = await _roleViewModel.GetAllFeaturesRoles();

            return File(
                fileContents: result.Data,
                contentType: "application/CSV",
                fileDownloadName: $"feature-role-{DateTime.Now.ToLocalTime().ToString("dd_MM_yyyy___hh_mm_ss")}.csv");
        }

#if DEBUG
        [AllowAnonymous]
#endif
        [HttpPost("inactive")]
        public async Task<IActionResult> InactiveRole([FromBody] RoleContract role)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" INACTIVE BY CODE ", role, typeof(RoleController).Name);
            var result = await _roleViewModel.InactiveRole(role);
            return Ok(result);
        }


        [HttpPost("create")]
        public async Task<IActionResult> AddRole([FromBody] List<RoleCreateContract> role)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" ADD ROLE ", role, typeof(RoleController).Name);
            var result = await _roleViewModel.AddRole(role);
            return Ok(result);
        }
    }
}