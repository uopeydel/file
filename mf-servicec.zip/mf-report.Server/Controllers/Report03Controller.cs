﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mf_report.Server.ViewModel;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Extensions;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace mf_report.Server.Controllers
{
    [Route("api/v1/r03")]
    public class Report03Controller : BaseController
    {
        public Report03Controller(Report03ViewModel report03ViewModel, IMFLoggerService logger,
            MemoryCacheWithPolicy cacheWithPolicy) : base(
            report03ViewModel, logger, cacheWithPolicy)
        {
        }

        [Authorize]
        [HttpPost("")]
        public async Task<IActionResult> Index([FromBody] PortfolioSearchContract searchBody)
        {
            var baseError = BaseError();
            if (baseError != null)
            {
                return baseError;
            }

            _logger.SetLogDesc(LogDesc);
            _logger.LogObj(" CREATE REPORT ", searchBody, typeof(Report03Controller).Name);
            var result = await _report03ViewModel.GetReport03(searchBody);
            if (result.IsError())
            {
                _logger.LogObj(" GET REPORT 3 DATA ERROR ", result, typeof(Report03Controller).Name,
                    LogLevel.Error);
                return StatusCode(500, result);
            }

            var fileList = await BuildPdfByte(result, "Report03");
            if (fileList.IsError())
            {
                _logger.LogObj(" BUILD PDF REPORT 3 ERROR ", fileList.Errors, typeof(Report03Controller).Name,
                    LogLevel.Error);
                return StatusCode(500, fileList);
            }

            var mergResponse = PdfMerger.MergeFiles(fileList.Data);
            return File(
                fileContents: mergResponse,
                contentType: "application/pdf",
                fileDownloadName: $"mfreport03_{DateTime.Now.ToLocalTime().ToString("dd_MM_yyyy___hh_mm_ss")}.pdf");
        }

        [AllowAnonymous]
        //Not for frontend call, But add it for generate html add patial header
        [HttpGet("Header")]
        public IActionResult Header([FromQuery] PDFHeaderContract header)
        {
            return View("Header", header);
        }

        [AllowAnonymous]
        //Not for frontend call, But add it for generate html add patial header
        [HttpGet("Footer")]
        public IActionResult Footer()
        {
            return View("Footer");
        }
    }
}