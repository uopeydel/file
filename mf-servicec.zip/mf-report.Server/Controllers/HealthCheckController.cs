﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace mf_report.Server.Controllers
{
    [Route("api/healthcheck")]
    public class HealthCheckController : Controller
    {
        [AllowAnonymous]
        [HttpGet]
        public IActionResult Get()
        {
            return Ok("OK " + HttpContext.Request.IsHttps);
        }
    }
}