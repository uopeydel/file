﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Requester;
using mf_service.SharedService.SystemService.Interface;

namespace mf_report.Server.ViewModel
{
    public class Report07ViewModel
    {
        private readonly RequesterService _requester;
        private readonly IMFLoggerService _logger;

        public Report07ViewModel(RequesterService requesterService, IMFLoggerService logger)
        {
            _requester = requesterService;
            _logger = logger;
        }

        public async Task<
                PandaResults<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_LTF_RMF_BALContract>>>>>
            GetReport07(PortfolioSearchContract searchBody)
        {
            var result = await _requester.Request<
                PortfolioSearchContract,
                PandaResults<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_LTF_RMF_BALContract>>>>
            >("mf-reportservice-report07", searchBody);
            if (result.IsError())
            {
                _logger.LogInfo(" REPORT 7 ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(Report07ViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<
                            List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_LTF_RMF_BALContract>>>>
                        (result.Errors.ToArray());
            }

            return result.Data;
        }
    }
}