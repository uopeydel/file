using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Body;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.Requester;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Internal;
using Microsoft.EntityFrameworkCore.Internal;

namespace mf_reportservice.Server.ViewModel
{
    public class RoleViewModel
    {
        private readonly RequesterService _requester;
        private readonly IMFLoggerService _logger;

        public RoleViewModel(RequesterService requesterService, IMFLoggerService logger)
        {
            _requester = requesterService;
            _logger = logger;
        }

        public async Task<PandaResults<List<RoleContract>>> GetRoles()
        {
            var result = await _requester.Request<
                object,
                PandaResults<List<RoleContract>>
            >("mf-user-manage-get-role", new object());
            if (result.IsError())
            {
                _logger.LogInfo(" GET ROLE ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(RoleViewModel).Name);
                return PandaResponse.CreateErrorResponse<List<RoleContract>>(result.Errors.ToArray());
            }

            return result.Data;
        }

        public async Task<PandaResults<byte[]>> GetAllFeaturesRoles()
        {
            var result = await _requester.Request<
                object,
                PandaResults<List<RoleFeaturesContract>>
            >("mf-user-manage-get-all-feature-role", new object());
            if (result.IsError() || result.Data.IsError())
            {
                _logger.LogInfo(" GET ALL FEATURE ROLE ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(RoleViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<byte[]>(result.Errors.ToArray());
            }

            if (!result.Data.Data.Any())
            {
                _logger.LogInfo(" GET ALL FEATURE ROLE NULL DATA ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(RoleViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<byte[]>("null");
            }

            Console.ForegroundColor = ConsoleColor.Green;
            byte[] bytes = null;

            var roleCodes = result.Data.Data.Select(s => s.code.ToUpper()).Distinct().OrderBy(o => o).ToList();
            var header = "Feature," + string.Join(",", roleCodes) + "\n";

            var featureNames = result.Data.Data.SelectMany(s => s.features.Select(ss => ss.name)).Distinct()
                .Where(w => !string.IsNullOrEmpty(w))
                .OrderBy(o => o).ToList();

            using (var ms = new MemoryStream())
            {
                TextWriter tw = new StreamWriter(ms, Encoding.UTF8);
                ms.Position = 0;
                tw.Write(header);
                tw.Flush();

                foreach (var feature in featureNames)
                {
                    var roleCodeForThisFeature = result.Data.Data
                        .Where(w => w.isActive)
                        .Where(w => w.features.Where(ww => ww != null).Any(a =>
                            !string.IsNullOrEmpty(a.name) && a.name.ToUpper().Equals(feature)))
                        .Where(w => !string.IsNullOrEmpty(w.code))
                        .Select(s => s.code).OrderBy(o => o).ToList();
                    var roleCodesForReplace = roleCodes;
                    roleCodesForReplace = roleCodesForReplace.Select(s =>
                    {
                        var isContain = roleCodeForThisFeature.Contains(s);
                        s = isContain ? "x" : " ";
                        return s;
                    }).ToList();

                    var line = feature + "," + string.Join(",", roleCodesForReplace) + "\n";
                    tw.Write(line);
                    Console.WriteLine(string.Format(line));
                    tw.Flush();
                }

                bytes = ms.ToArray();
            }

            #region legacy

            /*using (var ms = new MemoryStream())
            {
                TextWriter tw = new StreamWriter(ms);
                ms.Position = 0;
                tw.Write(string.Format("{0},{1},{2} \n", "role id", "role code", "feature name"));
                tw.Flush();
                foreach (var role in result.Data.Data)
                {
                    foreach (var feature in role.features)
                    {
                        tw.Write(string.Format("{0},{1},{2} \n", role.id, role.code, feature.name));
                        Console.WriteLine(string.Format("'{0}',  '{1}',  '{2}' ", role.id, role.code, feature.code,
                            feature.name));
                        tw.Flush();
                    }
                }

                bytes = ms.ToArray();
            }*/

            #endregion


            Console.ResetColor();

            return PandaResponse.CreateSuccessResponse(bytes);
            //return result.Data;
        }

        public async Task<PandaResults<List<RoleFeaturesContract>>> GetFeaturesByRole(RoleCreateContract roleCode)
        {
            var result = await _requester.Request<
                RoleCreateContract,
                PandaResults<List<RoleFeaturesContract>>
            >("mf-user-manage-get-feature-role", roleCode);
            if (result.IsError())
            {
                _logger.LogInfo(" GET FEATURE ROLE ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(RoleViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<List<RoleFeaturesContract>>(result.Errors.ToArray());
            }

            return result.Data;
        }

        public async Task<PandaResults<List<CodeNameContract>>> AddRole(List<RoleCreateContract> role)
        {
            var result = await _requester.Request<
                List<RoleCreateContract>,
                PandaResults<List<CodeNameContract>>
            >("mf-user-manage-add-role", role);
            if (result.IsError())
            {
                _logger.LogInfo(" ADD ROLE ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(RoleViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<List<CodeNameContract>>(result.Errors.ToArray());
            }

            return result.Data;
        }

        public async Task<PandaResults<bool>> InactiveRole(RoleContract role)
        {
            var result = await _requester.Request<
                RoleContract,
                PandaResults<bool>
            >("mf-user-manage-inactive-role", role);
            if (result.IsError())
            {
                _logger.LogInfo(" INACTIVE ROLE ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(RoleViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<bool>(result.Errors.ToArray());
            }

            return result.Data;
        }
    }
}