﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Requester;
using mf_service.SharedService.SystemService.Interface;

namespace mf_report.Server.ViewModel
{
    public class Report03ViewModel
    {
        private readonly RequesterService _requester;
        private readonly IMFLoggerService _logger;

        public Report03ViewModel(RequesterService requesterService, IMFLoggerService logger)
        {
            _requester = requesterService;
            _logger = logger;
        }

        public async Task<
                PandaResults<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>>>
            GetReport03(PortfolioSearchContract searchBody)
        {
            var result = await _requester.Request<
                PortfolioSearchContract,
                PandaResults<List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>>
            >("mf-reportservice-report03", searchBody);
            if (result.IsError())
            {
                _logger.LogInfo(" REPORT 3 ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(Report03ViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<
                            List<PDFContract<MFAPI_SEARCHPORTNOContract, List<MFAPI_GET_TRANSACTIONContract>>>>
                        (result.Errors.ToArray());
            }

            return result.Data;
        }
    }
}