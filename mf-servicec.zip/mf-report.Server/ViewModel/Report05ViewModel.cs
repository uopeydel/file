﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Requester;
using mf_service.SharedService.SystemService.Interface;

namespace mf_report.Server.ViewModel
{
    public class Report05ViewModel
    {
        private readonly RequesterService _requester;
        private readonly IMFLoggerService _logger;

        public Report05ViewModel(RequesterService requesterService, IMFLoggerService logger)
        {
            _logger = logger;
            _requester = requesterService;
        }

        public async Task<
                PandaResults<List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>>>>
            GetReport05(PortfolioSearchContract searchBody)
        {
            var result = await _requester.Request<
                PortfolioSearchContract,
                PandaResults<List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>>>
            >("mf-reportservice-report05", searchBody);
            if (result.IsError())
            {
                _logger.LogInfo(" REPORT 5 ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(Report05ViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<
                            List<PDFContract<MFAPI_SEARCHPORTNOContract, GraphReportPDFContract>>>
                        (result.Errors.ToArray());
            }

            return result.Data;
        }
    }
}