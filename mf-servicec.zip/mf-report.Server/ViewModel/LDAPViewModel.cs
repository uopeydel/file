using System;
using System.Threading.Tasks;
using mf_service.LDAP.Contract;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.Requester;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Mvc;

namespace mf_report.Server.ViewModel
{
    public class LDAPViewModel
    {
        private readonly RequesterService _requester;
        private readonly IMFLoggerService _logger;

        public LDAPViewModel(RequesterService requesterService, IMFLoggerService logger)
        {
            _requester = requesterService;
            _logger = logger;
        }

        public async Task<PandaResults<LDAPLoginResponseContract>> Login(LoginContract loginContract)
        {
            var result = await _requester.Request<
                LoginContract,
                PandaResults<LDAPLoginResponseContract>
            >("mf-login", loginContract);
            if (result.IsError())
            {
                _logger.LogInfo(" LOGIN ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(LDAPViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<LDAPLoginResponseContract>
                        (result.Errors.ToArray());
            }

            return result.Data;
        }

        public async Task<PandaResults<LDAPLoginResponseContract>> RefreshToken(RefreshTokenContract token)
        {
            var result = await _requester.Request<
                RefreshTokenContract,
                PandaResults<LDAPLoginResponseContract>
            >("mf-refresh", token);
            if (result.IsError())
            {
                _logger.LogInfo(" REFRESH ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(LDAPViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<LDAPLoginResponseContract>
                        (result.Errors.ToArray());
            }

            return result.Data;
        }

        public async Task<PandaResults<bool>> Logout(LoginContract logout)
        {
            var result = await _requester.Request<
                LoginContract,
                PandaResults<bool>
            >("mf-logout", logout);
            if (result.IsError())
            {
                _logger.LogInfo(" LOGOUT ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(LDAPViewModel).Name);
                return PandaResponse
                    .CreateErrorResponse<bool>
                        (result.Errors.ToArray());
            }

            return result.Data;
        }
    }
}