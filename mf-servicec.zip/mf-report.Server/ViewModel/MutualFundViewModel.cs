using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.Enums;
using mf_service.SharedService.Contract.MF.Result;
using mf_service.SharedService.Contract.MF.Search;
using mf_service.SharedService.Contract.Report.Result;
using mf_service.SharedService.Contract.Report.Search;
using mf_service.SharedService.Models;
using mf_service.SharedService.Requester;

namespace mf_report.Server.ViewModel
{
    public class MutualFundViewModel
    {
        private readonly RequesterService _requester;

        public MutualFundViewModel(RequesterService requesterService)
        {
            _requester = requesterService;
        }


        public async Task<PandaResults<List<MFPortNoContract>>> SearchPortNo(SearchPortNoContract searchBody)
        {
            var result = await _requester.Request<
                SearchPortNoContract,
                PandaResults<List<MFPortNoContract>>
            >("mf-search-port-no", searchBody);
            if (result.IsError())
            {
                return PandaResponse.CreateErrorResponse<List<MFPortNoContract>>
                    (result.Errors.ToArray());
            }

            return result.Data;
        }


        public async Task<PandaResults<List<MFAPI_GET_PARTIAL_PORTNOModel>>> SearchPartialPortNo(
            SearchPartialPortNoContract searchBody)
        {
            var result = await _requester.Request<
                SearchPartialPortNoContract,
                PandaResults<List<MFAPI_GET_PARTIAL_PORTNOModel>>
            >("mf-search-partial-port-no", searchBody);
            if (result.IsError())
            {
                return PandaResponse
                    .CreateErrorResponse<List<MFAPI_GET_PARTIAL_PORTNOModel>>(result.Errors.ToArray());
            }

            return result.Data;
        }


        public async Task<PandaResults<List<SettlementDateByCustomerResultContract>>> GetSettlementDateCustomer(
            SearchSettlementDateByCustomerContract searchBody)
        {
            var searchObj = new GetSettlementDateSearchContract
            {
                portFolioNo = searchBody.SearchValue,
            };
            var result = await _requester.Request<
                GetSettlementDateSearchContract,
                PandaResults<List<SettlementDateByCustomerResultContract>>
            >("mf-get-settlement-date", searchObj);
            if (result.IsError())
            {
                return PandaResponse.CreateErrorResponse<List<SettlementDateByCustomerResultContract>>
                    (result.Errors.ToArray());
            }

            return result.Data;
        }


        public async Task<PandaResults<List<SettlementDateByCalendarPTResultContract>>> GetSettlementDateCalendarPT(
            SearchSettlementDateByCalendarContract searchBody)
        {
            var searchObj = new GetSettlementDateSearchContract
            {
                fundName = searchBody.SearchValue,
                asOfDate = $"{searchBody.Year}{searchBody.Month}01",
            };

            var result = await _requester.Request<
                GetSettlementDateSearchContract,
                PandaResults<List<SettlementDateByCalendarPTResultContract>>
            >("mf-get-settlement-date-pt", searchObj);
            if (result.IsError())
            {
                return PandaResponse.CreateErrorResponse<List<SettlementDateByCalendarPTResultContract>>
                    (result.Errors.ToArray());
            }

            return result.Data;
        }

        public async Task<PandaResults<List<SettlementDateByCalendarTSPResultContract>>> GetSettlementDateCalendarTSP(
            SearchSettlementDateByCalendarContract searchBody)
        {
            var searchObj = new GetSettlementDateSearchContract
            {
                asOfDate = $"{searchBody.Year}{searchBody.Month}01",
            };

            var result = await _requester.Request<
                GetSettlementDateSearchContract,
                PandaResults<List<SettlementDateByCalendarTSPResultContract>>
            >("mf-get-settlement-date-tsp", searchObj);
            if (result.IsError())
            {
                return PandaResponse.CreateErrorResponse<List<SettlementDateByCalendarTSPResultContract>>
                    (result.Errors.ToArray());
            }

            return result.Data;
        }

        public async Task<PandaResults<byte[]>> ExportLog(GetLogContract searchBody)
        {
            var result = await _requester.Request<
                GetLogContract,
                PandaResults<List<LogExportContract>>
            >("mf-get-export-log", searchBody);
            if (result.IsError())
            {
                return PandaResponse.CreateErrorResponse<byte[]>
                    (result.Errors.ToArray());
            }
            byte[] bytes = null;
            using (var ms = new MemoryStream())
            {
                TextWriter tw = new StreamWriter(ms);
                ms.Position = 0;
                tw.Write($"{nameof(LogExportContract.UserId)},{nameof(LogExportContract.Created)},{nameof(LogExportContract.LogType)},{nameof(LogExportContract.RoleCode)},{nameof(LogExportContract.FeatureCode)},{nameof(LogExportContract.Activity)}"+ "\n");
                tw.Flush();

                foreach (var log in result.Data.Data)
                { 
                    var line =   $"{log.UserId},{log.Created},{log.LogType},{log.RoleCode},{log.FeatureCode},{log.Activity}"+ "\n"; 
                    tw.Write(line);
                    Console.WriteLine(string.Format(line));
                    tw.Flush();
                }

                bytes = ms.ToArray();
            }
            return PandaResponse.CreateSuccessResponse(bytes); 
        }
        
    }
}