using System.Collections.Generic;
using System.Threading.Tasks;
using mf_service.SharedService.Contract;
using mf_service.SharedService.Contract.UserManagement.Result;
using mf_service.SharedService.Requester;
using mf_service.SharedService.SystemService.Interface;
using Microsoft.AspNetCore.Internal;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace mf_reportservice.Server.ViewModel
{
    public class FeatureViewModel
    {
        private readonly RequesterService _requester;
        private readonly IMFLoggerService _logger;

        public FeatureViewModel(RequesterService requesterService, IMFLoggerService logger)
        {
            _requester = requesterService;
            _logger = logger;
        }

        public async Task<PandaResults<List<FeatureContract>>> GetFeatures()
        {
            var result = await _requester.Request<
                object,
                PandaResults<List<FeatureContract>>
            >("mf-user-manage-get-feature", new object());
            if (result.IsError())
            {
                _logger.LogInfo(" GET FEATURE ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(FeatureViewModel).Name);
                return PandaResponse.CreateErrorResponse<List<FeatureContract>>(result.Errors.ToArray());
            }

            return result.Data;
        }

        public async Task<PandaResults<FeatureContract>> AddFeatures(FeatureContract feature)
        {
            var result = await _requester.Request<
                FeatureContract,
                PandaResults<FeatureContract>
            >("mf-user-manage-add-feature", feature);
            if (result.IsError())
            {
                _logger.LogInfo(" ADD FEATURE ERROR ", string.Join(" , ", result.Errors.ToArray()),
                    typeof(FeatureViewModel).Name);
                return PandaResponse.CreateErrorResponse<FeatureContract>(result.Errors.ToArray());
            }

            return result.Data;
        }
    }
}