﻿using System;
namespace mf_service.LDAP.Contract
{
    public class RefreshTokenContract
    {
        public string Token { get; set; }
        public string RefreshToken { get; set; }
    }
}
