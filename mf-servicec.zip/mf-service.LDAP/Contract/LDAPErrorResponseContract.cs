﻿using System;
namespace mf_service.LDAP.Contract
{
    public class LDAPErrorResponseContract
    {
        public string error { get; set; }
        public string error_description { get; set; }
    }
}