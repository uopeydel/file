﻿using System;
namespace mf_service.LDAP.Contract
{
    public class LDAPLoginResponseContract
    {
        public string access_token { get; set; }
        public string token_type { get; set; }
        public string refresh_token { get; set; }
        public int expires_in { get; set; }
        public string refresh_expires_in { get; set; }
        public string lastLogOn { get; set; } 
        public string jti { get; set; } 

        public string scope { get; set; }   //  TODO: read write ,
        public string fullNameTh { get; set; }
        public string sex { get; set; }
        public string roleEn { get; set; }
        public string channel { get; set; }   // TODO:  Branch ,
        public string fullName { get; set; }
        public string branchTh { get; set; }
        public string userId { get; set; }
        public string branchCode { get; set; }
        public string tellerId { get; set; }   //TODO: 0013473D , 
        public string roleCode { get; set; }
        public string authority { get; set; }   // TODO:  F2F_BR_MAKER , ,,memberOfvalue
        public string roleTh { get; set; }

    }
}
