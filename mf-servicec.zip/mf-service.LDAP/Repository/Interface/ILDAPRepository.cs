﻿using System;
using System.Threading.Tasks;
using mf_service.LDAP.Contract;

namespace mf_service.LDAP.Repository.Interface
{
    public interface ILDAPRepository
    {
        Tuple<LDAPLoginResponseContract, string> Requester(
            string host,
            string baseConnector,
            string usernameSuffix,
            string userName,
            string password);
    }
}