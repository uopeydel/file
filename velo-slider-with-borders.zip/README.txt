A Pen created at CodePen.io. You can find this one at http://codepen.io/StephenScaff/pen/dWmJxj.

 A slider interaction thing using Velocity and Velocity effects (UI Pack) to enhance the animation.  Animation is triggered via arrow keys, nav click, or scrolling jack.
This version includes borders as part of the interaction.